//
//  main.cpp
//  3Sum Closest
//
//  Created by yangjingyi on 4/23/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int threeSumClosest(vector<int>& nums, int target)
    {
        int result;
        
        
        if(nums.size()<3)
        {
            return result;
        }
        result=nums[0]+nums[1]+nums[2];
        int i,j,tar1,tar2,m,n;
        
        sort(nums.begin(),nums.end());
        for(i=0;i<nums.size()-2;i++)
        {
            cout<<i<<endl;
            if(i>0&&nums[i]==nums[i-1])
            {
                //cout<<"wrong"<<endl;
                continue;
            }
            
            for(m=i+1;m<nums.size()-1;m++)
            {
                if(nums[m]==nums[m-1]&&m>i+1)
                    continue;
                tar1=nums[i]+nums[m];
                if(tar1+nums[m+1]>target)
                {
                    result=abs(tar1+nums[m+1]-target)<(result-target)?tar1+nums[m+1]:result;
                }
                if(tar1+nums[nums.size()-1]<target)
                    
                {
                    cout<<i<<" "<<m<<endl;
                    cout<<tar1+nums[nums.size()-1]<<endl;
                    cout<<result<<endl;
                    result=abs(tar1+nums[nums.size()-1]-target)<abs(result-target)?tar1+nums[nums.size()-1]:result;
                    cout<<result<<endl;
                }
                if(tar1+nums[m+1]==target||tar1+nums[nums.size()-1]==target)
                {
                    return target;
                }
                for(n=m+1;n<nums.size();n++)
                {
                    if(nums[n]==nums[n-1]&&n>m+1)
                        continue;
                    //flag=false;
                    
                    if(target-tar1==nums[n])
                        return target;
                    else if(n<nums.size()-1&&nums[n]<target-tar1&&target-tar1<nums[n+1])
                    {
                        tar2=abs(target-tar1-nums[n])<abs(target-tar1-nums[n+1])?tar1+nums[n]:tar1+nums[n+1];
                        result=abs(tar2-target)<abs(result-target)?tar2:result;
                        cout<<i<<" "<<m<<" "<<n<<endl;
                        continue;
                    }
                    
                }
            }
            
        }
        return result;
    };
};

    


int main()
{
    int ina[5]={-3,-2,-5,3,-4};
    vector<int> inv(ina,ina+5);
    Solution a;
    cout<<a.threeSumClosest(inv,-1)<<endl;
    
}
