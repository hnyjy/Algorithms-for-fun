//
//  main.cpp
//  3Sum
//
//  Created by yangjingyi on 4/23/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <map>
using namespace std;
void quicksort(vector<int> &vec, int low, int high)
{
    if(low<high)
    {
        int l = low;
        int r= high;
        int key = vec[l];
        while(l<r)
        {
            while(l<r&&key<=vec[r])
                --r;
            vec[l]=vec[r];
            while(l<r&&key>=vec[l])
                ++l;
            vec[r]=vec[l];
            
        }
        vec[l]=key;
        quicksort(vec,low,l-1);
        quicksort(vec,r+1,high);
    }
}
class Solution
{
public:
    vector<vector<int> > threeSum(vector<int> &num)
    {
        vector<vector<int> > result;
        //bool flag=false;
        if(num.size()<3)
        {
            return result;
        }
        vector<int> re;
        //map<int,int> umap;
        int i,j,tar1,tar2,m,n,nums,nume;
        /*for(i=0;i<num.size();i++)
        {
            umap.insert(pair<int,int> (i,num[i]));
        }*/
        sort(num.begin(),num.end());
        for(i=0;i<num.size();i++)
        {
            if(i>0&&num[i]==num[i-1])
            {
                //cout<<"wrong"<<endl;
                continue;
            }
            tar1=0-num[i];
            for(m=i+1;m<num.size();m++)
            {
                if(num[m]==num[m-1]&&m>i+1)
                    continue;
                tar2=tar1-num[m];
                for(n=m+1;n<num.size();n++)
                {
                    if(num[n]==num[n-1]&&n>m+1)
                        continue;
                    //flag=false;
                    if(num[n]==tar2)
                    {
                        //flag=true;
                        re.push_back(num[i]);
                        re.push_back(num[m]);
                        re.push_back(num[n]);
                        result.push_back(re);
                        re.clear();
                        
                    }
                }
            }
            
        }
        /*for(i=0;i<result.size();i++)
        {
            cout<<i<<endl;
            for(j=0;j<result[i].size();j++)
            {
                cout<<result[i][j]<<" ";
            }
            cout<<endl;
        }*/
        /*if(result.size()>1)
        {for(i=0;i<result.size()-1;i++)
        {
            if(result[i][0]==result[i+1][0]&&result[i][1]==result[i+1][1])
            {
                result.erase(result.begin()+i);
                i--;
                //cout<<i<<endl;
            }
        }
        }*/
        
        return result;
    };
};

int main() {
    int ina[6]={-1,0,1,2,-1,4};
    vector<int> inv(ina,ina+6);
    int i,j;
    vector<vector<int> >outv;
    Solution a;
    outv=a.threeSum(inv);
    
    for(i=0;i<outv.size();i++)
    {
        cout<<i<<endl;
        for(j=0;j<outv[i].size();j++)
        {
            
            cout<<outv[i][j]<<" ";
        }
        cout<<endl;
    }
}
