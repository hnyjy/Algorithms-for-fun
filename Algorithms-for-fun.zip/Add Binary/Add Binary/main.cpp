//
//  main.cpp
//  Add Binary
//
//  Created by yangjingyi on 12/12/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    string addBinary(string a,string b)
    {
        string ret="";
        int carry=0;
        for(int i=a.size()-1,j=b.size()-1;i>=0||j>=0;i--,j--)
        {
            int m=(i>=0&&a[i]=='1');
            int n=(j>=0&&b[j]=='1');
            ret=to_string((m+n+carry)&0x1)+ret;
            carry=(m+n+carry)>>1;
        }
        return carry?'1'+ret:ret;
    }
};


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
