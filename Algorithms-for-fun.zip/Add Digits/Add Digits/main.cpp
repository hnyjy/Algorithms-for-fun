//
//  main.cpp
//  Add Digits
//
//  Created by yangjingyi on 1/27/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    int addDigits(int num)
    {
        return 1+(num-1)%9;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
