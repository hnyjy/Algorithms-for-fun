//
//  main.cpp
//  Add Two Numbers
//
//  Created by yangjingyi on 4/9/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;

struct ListNode
{
    int val;
    ListNode *next;
    ListNode(int x) : val(x), next(NULL) {}
};

class Solution
{
public:
    ListNode *addTwoNumbers(ListNode *l1, ListNode *l2)
    {
        ListNode *result=new ListNode((l1->val+l2->val)%10);
        int temp=(l1->val+l2->val)/10;
        l1=l1->next;
        l2=l2->next;
        ListNode *adding=result;
        while(l1&&l2 )
        {
            
            ListNode *tempNode=new ListNode((l1->val+l2->val+temp)%10);
            temp=(l1->val+l2->val+temp)/10;
            adding->next=tempNode;
            adding=adding->next;
            l1=l1->next;
            l2=l2->next;
            
        }
        while(l1)
        {
            ListNode *tempNode=new ListNode((l1->val+temp)%10);
            temp=(l1->val+temp)/10;
            adding->next=tempNode;
            adding=adding->next;
            l1=l1->next;
        }
        while(l2)
        {
            ListNode *tempNode=new ListNode((l2->val+temp)%10);
            temp=(l2->val+temp)/10;
            adding->next=tempNode;
            adding=adding->next;
            l2=l2->next;
        }
        while (temp)
        {
            ListNode *tempNode=new ListNode(temp);
            adding->next=tempNode;
            adding=adding->next;
            temp=temp/10;
            
        }
        return result;
    }
    
};

int main() {
    ListNode* l1=new ListNode(1);
    ListNode* l2=new ListNode(0);
    Solution a;
    ListNode* out=a.addTwoNumbers(l1,l2);
    while(out)
    {
        cout <<out->val<<" ";
        out=out->next;
    }
}
