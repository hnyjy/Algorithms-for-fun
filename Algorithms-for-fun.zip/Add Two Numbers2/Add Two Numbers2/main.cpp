//
//  main.cpp
//  Add Two Numbers2
//
//  Created by yangjingyi on 3/13/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
};
class Solution
{
public:
    ListNode *addTwoNumbers(ListNode *l1,ListNode* l2)
    {
        ListNode* result=new ListNode(0);
        int tmp=0;
        ListNode* add=result;
        if(!l1&&!l2)
        {
            return result;
        }
        while(l1&&l2)
        {
            add->next=new ListNode((l1->val+l2->val+tmp)%10);
            add=add->next;
           
            tmp=(l1->val+l2->val+tmp)/10;
            //cout<<"right"<<endl;
            l1=l1->next;
            l2=l2->next;
        }
        while(l1)
        {
            add->next=new ListNode((l1->val+tmp)%10);
            tmp=(l1->val+tmp)/10;
            add=add->next;
            l1=l1->next;
        }
        while(l2)
        {
            add->next=new ListNode((l2->val+tmp)%10);
            tmp=(l2->val+tmp)/10;
            add=add->next;
            l2=l2->next;
        }
        while(tmp>0)
        {
            add->next=new ListNode(tmp);
            tmp=tmp/10;
        }
        return result->next;
        
    }
};

int main(int argc, const char * argv[]) {
    ListNode* l1=new ListNode(0);
    ListNode* l2=new ListNode(0);
    Solution a;
    ListNode* out=a.addTwoNumbers(l1,l2);
    while(out)
    {
        cout <<out->val<<" ";
        out=out->next;
    }
    
    return 0;
}
