//
//  main.cpp
//  Add and Search Word-Data structure design
//
//  Created by yangjingyi on 1/4/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
using namespace std;
class TrieNode
{
public:
    TrieNode(bool end=false)
    {
        isEnd=end;
    }
    unordered_map<char,TrieNode*> branches;
    bool isEnd;
    
};
class WordDictionary
{
public:
    TrieNode *root;
    WordDictionary()
    {
        root=new TrieNode;
    }
    ~WordDictionary()
    {
        destroy(root);
    }
    void destroy(TrieNode* node)
    {
        for(auto entry:node->branches)
        {
            destroy(entry.second);
        }
        delete node;
    }
    void addWord(string word)
    {
        TrieNode* node=root;
        int i;
        for(i=0;i<word.size();i++)
        {
            if(node->branches.find(word[i])==node->branches.end())
            {
                
                break;
            }
            else
            {
                
                node=node->branches[word[i]];
                node->isEnd=((i==word.size()-1)?true:node->isEnd);
                
            }
            
        }
        for(;i<word.size();i++)
        {
            
            node->branches[word[i]]=new TrieNode(i==word.size()-1?true:false);
            node=node->branches[word[i]];
        }

    }
    bool search(string word)
    {
        TrieNode* node=root;
        return find(word, root)||word.size()==0;
        
    }
    bool find(string word, TrieNode* node)
    {
        
        
        if(word.size()!=0&&node->branches.empty())
        {
            
            return false;
        }
        if(word.size()==0&&node->isEnd)
        {
            return true;
        }
        if(word.size()==0&&(!node->isEnd))
        {
            return false;
        }
           
        bool flag=false;
        if(word[0]=='.')
        {
            //cout<<"right"<<endl;
          
            
            
                cout<<"0"<<endl;
                for(auto it=node->branches.begin();it!=node->branches.end();it++)
                {
                    flag=find(word.substr(1),it->second);
                    
                    if(flag==true)
                    {
                        cout<<"2"<<endl;
                        return true;
                    }
                    else
                    {
                        cout<<"3"<<endl;
                        continue;
                    }
                }
                return false;
            
            
        }
        else
        {
            
            if(node->branches.find(word[0])==node->branches.end())
            {
                cout<<"4"<<endl;
                
                return false;
            }
            else
            {
                cout<<"5"<<endl;
                
                flag=find(word.substr(1),node->branches[word[0]]);
                return flag;
            }
        }
    }
};

int main(int argc, const char * argv[]) {
    WordDictionary a;
    a.addWord("at");
    a.addWord("and");
    a.addWord("an");
    a.addWord("add");
    a.addWord("bat");
    bool out;
    out=a.search("b.");
    if(out)
    {
        cout<<"True"<<endl;
    }
    else
    {
        cout<<"False"<<endl;
    }
    out=a.search(".");
    if(out)
    {
        cout<<"True"<<endl;
    }
    else
    {
        cout<<"False"<<endl;
    }
    /*out=a.search("a.");
    if(out)
    {
        cout<<"True"<<endl;
    }
    else
    {
        cout<<"False"<<endl;
    }
    out=a.search(".a");
    if(out)
    {
        cout<<"True"<<endl;
    }
    else
    {
        cout<<"False"<<endl;
    }
    out=a.search(".b");
    if(out)
    {
        cout<<"True"<<endl;
    }
    else
    {
        cout<<"False"<<endl;
    }
    out=a.search("ab.");
    if(out)
    {
        cout<<"True"<<endl;
    }
    else
    {
        cout<<"False"<<endl;
    }
    out=a.search(".");
    if(out)
    {
        cout<<"True"<<endl;
    }
    else
    {
        cout<<"False"<<endl;
    }
    out=a.search("..");
    if(out)
    {
        cout<<"True"<<endl;
    }
    else
    {
        cout<<"False"<<endl;
    }*/
    return 0;
}
