//
//  main.cpp
//  Additive Number
//
//  Created by yangjingyi on 2/16/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    bool isAdditiveNumber(string num)
    {
        if(num.size()<3)
        {
            return false;
        }
        for(int i=0;i<num.size()-2;i++)
        {
            if(num[0]=='0')
            {
                if(help(0,0,num,1,0))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            if(help(i,atoi(num.substr(0,i+1).c_str()),num,1,atoi(num.substr(0,i+1).c_str())))
            {
                return true;
            }
        }
        return false;
    }
    bool help(int index, int sum, string num,int count,int pre)
    {
        if(sum==atoi(num.substr(index+1).c_str())&&num[index+1]!='0'&&count>1)
        {
            return true;
        }
        if((num[index+1]=='0'&&count>1)||(to_string(sum)!=num.substr(index+1,to_string(sum).size())&&count>1))
        {
            //cout<<"false"<<endl;
            return false;
        }
        else if(count==1)
        {
            //cout<<pre<<","<<endl;
            if(num[index+1]!='0')
            {for(int i=1;i<num.size()-1-index;i++)
            {
                //cout<<i<<endl;
                if(help(index+i,pre+atoi(num.substr(index+1,i).c_str()),num,count+1,atoi(num.substr(index+1,i).c_str())))
                {
                    return true;
                }
                //--count;
            }
            }
            else
            {
                if(help(index+1,pre,num,count+1,0))
                {
                    return true;
                }
                return false;
            }

        }
        else
        {
            //cout<<pre<<endl;
            if(help(index+to_string(sum).size(),pre+sum,num,count+1,sum))
            {
                return true;
            }
        }
        //cout<<"wrong"<<endl;
        return false;
        
        
    }
};

int main(int argc, const char * argv[]) {
    string in="0235813";
    Solution a;
    bool out=a.isAdditiveNumber(in);
    if(out)
    {
        cout<<"True"<<endl;
    }
    else
    {
        cout<<"False"<<endl;
    }
    return 0;
}
