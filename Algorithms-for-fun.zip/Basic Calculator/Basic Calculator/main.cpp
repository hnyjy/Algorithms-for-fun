//
//  main.cpp
//  Basic Calculator
//
//  Created by yangjingyi on 1/14/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int calculate(string s)
    {
        int res=0;
        if(s.size()==0)
        {
            return 0;
        }
        
        int par=0;
        vector<char> sign;
        string num="";
        for(int i=0;i<s.size();i++)
        {
            if(s[i]==' ')
            {
                if(num.size()==0)
                {
                    continue;
                }
                else if(sign.size()==0)
                {
                    res=res+atoi(num.c_str());
                }
                else if(sign[0]=='+')
                {
                    res=res+atoi(num.c_str());
                    sign.pop_back();
                }
                else
                {
                    res=res-atoi(num.c_str());
                    sign.pop_back();
                }
                num="";
                
            }
            else if(s[i]=='+'||s[i]=='-')
            {
                if(num.size()==0)
                {
                    
                    
                }
                else if(sign.size()==0)
                {
                    res=res+atoi(num.c_str());
                }
                else if(sign[0]=='+')
                {
                    res=res+atoi(num.c_str());
                    sign.pop_back();
                }
                else
                {
                    res=res-atoi(num.c_str());
                    sign.pop_back();
                }
                num="";
              
                sign.push_back(s[i]);
            }
            
            else if(s[i]=='(')
            {
                //cout<<"i="<<i<<endl;
                par++;
                int j;
                for(j=i+1;j<s.size()&&par>0;j++)
                {
                    if(s[j]=='(')
                    {
                        par++;
                    }
                    else if(s[j]==')')
                    {
                        par--;
                    }
                    else
                    {
                        continue;
                    }
                }
                if(sign.size()==0)
                {
                    res=res+calculate(s.substr(i+1,j-i-2));
                }
                else if(sign[0]=='+')
                {
                    res=res+calculate(s.substr(i+1,j-i-2));
                    sign.pop_back();
                }
                else
                {
                    res=res-calculate(s.substr(i+1,j-i-2));
                    sign.pop_back();
                }
                
                i=j-1;
            }
            else
            {
                num=num+s[i];
            }
            
                
            
        }
        if(num.size()==0)
        {
            
            
        }
        else if(sign.size()==0)
        {
            res=res+atoi(num.c_str());
        }
        else if(sign[0]=='+')
        {
            res=res+atoi(num.c_str());
            sign.pop_back();
        }
        else
        {
            res=res-atoi(num.c_str());
            sign.pop_back();
        }

        return res;
    }
    
};

int main(int argc, const char * argv[]) {
    string in="(1+(4+5+2)-3)+(6+8)+9+10";
    Solution a;
    int out=a.calculate(in);
    cout<<out<<endl;
}
