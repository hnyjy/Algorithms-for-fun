//
//  main.cpp
//  Basic CalculatorII
//
//  Created by yangjingyi on 1/14/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <stack>
#include <sstream>
using namespace std;
class Solution
{
public:
    int calculate(string s)
    {
        istringstream in('+'+s+'+');
        long long total=0,term=0,n;
        char op;
        while(in >>op)
        {
            if(op=='+'||op=='-')
            {
                total+=term;
                in>>term;
                term*=op=='+'?1:-1;
                
            }
            else
            {
                in>>n;
                if(op=='*')
                {
                    term *=n;
                }
                else
                {
                    term/=n;
                }
            }
        }
        return total;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
