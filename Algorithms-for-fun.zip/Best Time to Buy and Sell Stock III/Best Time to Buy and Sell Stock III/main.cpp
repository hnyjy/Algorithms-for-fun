//
//  main.cpp
//  Best Time to Buy and Sell Stock III
//
//  Created by yangjingyi on 12/21/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>
using namespace std;
class Solution
{
public:
    int maxProfit(vector<int> & prices)
    {
        int release1=0,release2=0;
        int hold1=INT_MIN,hold2=INT_MIN;
        for(int i=0;i<prices.size();i++)
        {
            release2=max(release2,hold2+prices[i]);
            cout<<"release2="<<release2<<endl;
            hold2=max(hold2,release1-prices[i]);
            cout<<"hold2="<<hold2<<endl;
            release1=max(release1,hold1+prices[i]);
            cout<<"release1="<<release1<<endl;
            hold1=max(hold1,-prices[i]);
            cout<<"hold1="<<hold1<<endl;
        }
        return release2;
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in={2,1,2,0,1};
    Solution a;
    cout<<a.maxProfit(in);
    return 0;
}
