//
//  main.cpp
//  Best Time to Buy and Sell Stock with Cooldown
//
//  Created by yangjingyi on 2/17/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;
class Solution
{
public:
    int maxProfit(vector<int>& prices)
    {
        int buy(INT_MIN),sell(0),prev_sell(0),prev_buy;
        for(int price: prices)
        {
            prev_buy=buy;
            buy=max(prev_sell-price,buy);
            prev_sell=sell;
            sell=max(prev_buy+price,sell);
        }
        return sell;
    }
};


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
