//
//  main.cpp
//  Best Time to Buy and Sell StockII
//
//  Created by yangjingyi on 12/20/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <climits>
#include <vector>
using namespace std;
class Solution
{
public:
    int maxProfit(vector<int>& prices)
    {
        int total=0;
        for(int i=0;i<prices.size()-1;i++)
        {
            if(prices[i+1]>prices[i])
            {
                total=prices[i+1]-prices[i]+total;
            }
        }
        return total;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
