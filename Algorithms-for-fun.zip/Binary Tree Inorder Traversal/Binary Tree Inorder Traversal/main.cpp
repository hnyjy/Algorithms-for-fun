//
//  main.cpp
//  Binary Tree Inorder Traversal
//
//  Created by yangjingyi on 12/17/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <stack>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
        vector<int> inorderTraversal(TreeNode* root)
    {
        vector<int> result;
        TreeNode* curr=root;
        stack<TreeNode*> stk;
        if(!root)
        {
            return result;
        }
        else
        {
            while(root||stk.size()==0)
            {
                while(root)
                {
                    
                    stk.push(root);
                    root=root->left;
                }
                root=stk.top();
                result.push_back(root->val);
                root=root->right;
            }
        }
        return result;
    
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
