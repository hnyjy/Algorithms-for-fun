//
//  main.cpp
//  Binary Tree Level Order Traversal
//
//  Created by yangjingyi on 12/19/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <stack>

using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    void level(vector<TreeNode*>& rootv, vector<vector<int>>& result)
    {
        int n=rootv.size();
        vector<int> temp;
        if(n==0)
        {
            return;
        }
        for(int i=0;i<n;i++)
        {
            temp.push_back(rootv[0]->val);
            
            if(rootv[0]->left)
            {
                rootv.push_back(rootv[0]->left);
            }
            if(rootv[0]->right)
            {
                rootv.push_back(rootv[0]->right);
            }
            rootv.erase(rootv.begin());
        }
        result.push_back(temp);
        level(rootv, result);
        
    }
    vector<vector<int> >levelOrder(TreeNode* root)
    {
        vector<vector<int> > result;
        vector<TreeNode* > rootv;
        if(!root)
        {
            return result;
        }
        rootv.push_back(root);
        level(rootv, result);
        return result;
        
    }
};
int main(int argc, const char * argv[]) {
    // insert code here...
    TreeNode* root=new TreeNode (1);
    root->left=new TreeNode (4);
    root->right=new TreeNode (5);
    root->left->left=new TreeNode (-7);
    root->left->right=new TreeNode(-6);
    root->left->left->left=new TreeNode(-7);
    root->left->right->left=new TreeNode(-5);
    root->left->right->left->right=new TreeNode(-4);
    Solution a;
    vector<vector<int> > out;
    out=a.levelOrder(root);
    for(int i=0;i<out.size();i++)
    {
        for(int j=0;j<out[i].size();j++)
        {
            cout<<out[i][j]<<",";
        }
        cout<<endl;
    }
    
    return 0;
}
