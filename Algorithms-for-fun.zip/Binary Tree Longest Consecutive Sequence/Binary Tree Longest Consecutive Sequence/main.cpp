//
//  main.cpp
//  Binary Tree Longest Consecutive Sequence
//
//  Created by yangjingyi on 2/12/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    int longestConsecutive(TreeNode * root)
    {
        return longest(root, NULL,0);
    }
private:
    int longest(TreeNode* now, TreeNode* parent, int len)
    {
        if(!now)
        {
            return len;
        }
        len=(parent&&now->val==parent->val+1)?len+1:1;
        return max(len,max(longest(now->left,now,len),longest(now->right,now,len)));
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
