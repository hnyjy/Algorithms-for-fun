//
//  main.cpp
//  Binary Tree Maximum Path Sum
//
//  Created by yangjingyi on 12/21/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <climits>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    int maxToRoot(TreeNode* root, int &re)
    {
        if(!root)
        {
            return 0;
        }
        int l=maxToRoot(root->left,re);
        int r=maxToRoot(root->left,re);
        if(l<0)
        {
            l=0;
        }
        if(r<0)
        {
            r=0;
        }
        if(l+r+root->val>re)
        {
            re=l+r+root->val;
        }
        return root->val+=max(l,r);
    }
    int maxPathSum(TreeNode* root)
    {
        int max=INT_MAX;
        maxToRoot(root, max);
        return max;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
