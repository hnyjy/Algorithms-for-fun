//
//  main.cpp
//  Binary Tree Paths
//
//  Created by yangjingyi on 1/27/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    vector<string> binaryTreePaths(TreeNode* root)
    {
        vector<string> result;
        string tmp="";
        generate(result, tmp, root);
        return result;
    }
    void generate(vector<string>& result, string tmp,TreeNode* root)
    {
        if(!root)
        {
            return;
        }
        if(!root->right&&!root->left)
        {
            tmp+=to_string(root->val);
            result.push_back(tmp);
            return;
        }
        tmp+=to_string(root->val);
        generate(result,tmp+"->",root->left);
        generate(result,tmp+"->",root->right);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
