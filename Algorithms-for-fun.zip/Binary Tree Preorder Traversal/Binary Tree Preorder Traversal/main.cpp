//
//  main.cpp
//  Binary Tree Preorder Traversal
//
//  Created by yangjingyi on 12/24/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <stack>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    vector<int> preorderTraversal(TreeNode* root)
    {
        stack<TreeNode*> stk;
        vector<int> result;
        if(!root)
        {
            return result;
        }
        stk.push(root);
        while(!stk.empty())
        {
            TreeNode *tmp=stk.top();
            result.push_back(tmp->val);
            stk.pop();
            if(tmp->right)
            {
                stk.push(tmp->right);
            }
            if(tmp->left)
            {
                stk.push(tmp->left);
            }
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
