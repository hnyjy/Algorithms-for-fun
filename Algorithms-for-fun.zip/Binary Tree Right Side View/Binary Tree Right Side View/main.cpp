//
//  main.cpp
//  Binary Tree Right Side View
//
//  Created by yangjingyi on 1/1/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <stack>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    void level(vector<TreeNode*>& node,vector<int>tmp,vector<vector<int> >& res)
    {
        int n=node.size();
        if(node.size()==0)
        {
            return;
        }
        else
        {
            
            for(int i=0;i<n;i++)
            {
                tmp.push_back(node[0]->val);
                if(node[0]->left)
                {
                    node.push_back(node[0]->left);
                }
                if(node[0]->right)
                {
                    node.push_back(node[0]->right);
                }
                node.erase(node.begin());
                
                
            }
            res.push_back(tmp);
            tmp.clear();
            level(node,tmp,res);
        }
    }
    vector<int> rightSideView(TreeNode* root)
    {
        vector<int> tmp;
        if(!root)
        {
            return tmp;
        }
        vector<TreeNode*> node;
        node.push_back(root);
        
        vector<vector<int> > res;
        level(node,tmp,res);
                for(int i=0;i<res.size();i++)
        {
            tmp.push_back(res[i][(res[i].size()-1)]);
        }
        return tmp;
    }
};

int main(int argc, const char * argv[]) {
    TreeNode * root=new TreeNode(1);
    root->left=new TreeNode(2);
    root->right=new TreeNode(3);
    Solution a;
    vector<int> out=a.rightSideView(root);
    for(int i=0;i<out.size();i++)
    {
        cout<<out[i]<<" ";
    }
    return 0;
}
