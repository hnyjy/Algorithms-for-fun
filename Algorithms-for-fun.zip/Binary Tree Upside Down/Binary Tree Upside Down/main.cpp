//
//  main.cpp
//  Binary Tree Upside Down
//
//  Created by yangjingyi on 12/27/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode * left;
    TreeNode * right;
    TreeNode(int x): val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    
    TreeNode* upSideDownBinaryTree(TreeNode *root)
    {
        TreeNode* node=root,*parent=NULL,*right=NULL;
        while(node)
        {
            TreeNode* left=node->left;
            node->left=right;
            right=node->right;
            node->right=parent;
            parent=node;
            node=left;
        }
        return parent;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
