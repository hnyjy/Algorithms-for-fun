//
//  main.cpp
//  Binary Tree Vertical Order Traversal
//
//  Created by yangjingyi on 2/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <map>
#include <queue>
#include <vector>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x), left(NULL),right(NULL){}
};
class Solution
{
public:
    vector<vector<int> > verticalOrder(TreeNode* root)
    {
        map<int,vector<int> > mp;
        queue<pair<int,TreeNode*> >q;
        vector<vector<int> >ret;
        if(root)
        {
            q.push({0,root});
        }
        while(!q.empty())
        {
            auto p=q.front();
            q.pop();
            mp[p.first].push_back(p.second->val);
            if(p.second->left)
            {
                q.push({p.first-1,p.second->left});
                
            }
            if(p.second->right)
            {
                q.push({p.first+1,p.second->right});
            }
        }
        for(auto it=mp.begin();it!=mp.end();++it)
        {
            ret.push_back(it->second);
        }
        return ret;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
