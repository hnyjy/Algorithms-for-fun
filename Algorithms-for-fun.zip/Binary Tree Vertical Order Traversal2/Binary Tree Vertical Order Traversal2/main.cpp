//
//  main.cpp
//  Binary Tree Vertical Order Traversal2
//
//  Created by yangjingyi on 2/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
#include <vector>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    vector<vector<int> > verticalOrder(TreeNode* root)
    {
        queue<pair<int,TreeNode*> >q;
        vector<vector<int> > left;
        vector<vector<int> >right;
        vector<int> mid;
        if(!root)
        {
            return left;
        }
        q.push({0,root});
        while(!q.empty())
        {
            auto p=q.front();
            q.pop();
            if(p.first==0)
            {
                mid.push_back(p.second->val);
            }
            else if(p.first>0)
            {
                if(p.first>right.size())
                {
                    right.push_back(vector<int> ());
                }
                right[p.first-1].push_back(p.second->val);
            }
            else
            {
                if(0-p.first>left.size())
                {
                    left.push_back(vector<int>());
                }
                left[-1-p.first].push_back(p.second->val);
            }
            
        }
        int r=right.size();
        reverse(left.begin(),left.end());
        left.push_back(mid);
        for(int i=0;i<r;i++)
        {
            left.push_back(right[i]);
            
            
        }
        return left;

    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
