//
//  main.cpp
//  Binary Tree Zigzag Level Order Traversal
//
//  Created by yangjingyi on 12/19/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x), left(NULL),right(NULL){}
};
class Solution
{
public:
    void zigzag(vector<TreeNode* >& rootv, vector<vector<int> >& result, int& level)
    {
        int n=rootv.size();
        vector<int>temp;
        if(n==0)
        {
            return;
        }
        for(int i=0;i<n;i++)
        {
            if(level%2!=0)
            {
                temp.push_back(rootv[n-1-i]->val);
                //cout<<n-1-i<<" ="<<rootv[n-1-i]->val<<endl;
                if(rootv[n-1-i]->right)
                {
                    //cout<<level<<"level right"<<endl;
                    rootv.push_back(rootv[n-1-i]->right);
                  
                }
                if(rootv[n-1-i]->left)
                {
                    //cout<<level<<"level left"<<endl;
                    rootv.push_back(rootv[n-1-i]->left);
                }
                rootv.erase(rootv.begin()+n-1-i);
            }
            else
            {
                temp.push_back(rootv[n-1-i]->val);
                //cout<<"n-1-i"<<" ="<<rootv[n-1-i]->val<<endl;
                if(rootv[n-1-i]->left)
                {
                    //cout<<level<<"level left"<<endl;
                    rootv.push_back(rootv[n-1-i]->left);
                }
                if(rootv[n-1-i]->right)
                {
                    //cout<<level<<"level right"<<endl;
                    rootv.push_back(rootv[n-1-i]->right);
                }
                rootv.erase(rootv.begin()+n-1-i);
                
            }
            
        }
        level=level+1;
        result.push_back(temp);
        //cout<<"right"<<endl;
        zigzag(rootv,result,level);
    }
    vector<vector<int> > zigzagLevelOrder(TreeNode *root)
    {
        int level=0;
        vector<vector<int> >result;
        vector<TreeNode* > rootv;
        if(!root)
        {
            return result;
        }
        rootv.push_back(root);
        zigzag(rootv,result,level);
        return result;
        
    }
};

int main(int argc, const char * argv[]) {
    TreeNode* root=new TreeNode (1);
    root->left=new TreeNode (2);
    root->right=new TreeNode (3);
    root->left->left=new TreeNode (4);
    root->left->right=new TreeNode(5);
    root->right->left=new TreeNode (6);
    root->right->right=new TreeNode(7);
    root->left->left->left=new TreeNode(8);
    root->left->right->left=new TreeNode(9);
    //root->left->right->left->right=new TreeNode(-4);
    Solution a;
    vector<vector<int> > out;
    out=a.zigzagLevelOrder(root);
    for(int i=0;i<out.size();i++)
    {
        for(int j=0;j<out[i].size();j++)
        {
            cout<<out[i][j]<<",";
        }
        cout<<endl;
    }

    return 0;
}
