//
//  main.cpp
//  Binary Tree postorder Traversal
//
//  Created by yangjingyi on 12/24/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <stack>
#include <unordered_map>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    vector<int> postorderTraversal(TreeNode* root)
    {
        stack<TreeNode*> stk;
        vector<int> result;
        if(!root)
        {
            return result;
        }
        stk.push(root);
        unordered_map<TreeNode*,int> hash;
        
        while(!stk.empty())
        {
            root=stk.top();
            while((root->left||root->right)&&hash.find(root)==hash.end())
            {
                hash[root]=1;
            if(root->right)
            {
                stk.push(root->right);
            }
            if(root->left)
            {
                stk.push(root->left);
            }
                root=stk.top();
            }
            root=stk.top();
            result.push_back(root->val);
            stk.pop();
            
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    TreeNode* root=new TreeNode(1);
    root->left=new TreeNode(2);
    Solution a;
    vector<int> out=a.postorderTraversal(root);
    for(int i=0;i<out.size();i++)
    {
        cout<<out[i]<<"  ";
    }
    return 0;
}
