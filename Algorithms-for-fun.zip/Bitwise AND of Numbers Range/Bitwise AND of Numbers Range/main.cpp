//
//  main.cpp
//  Bitwise AND of Numbers Range
//
//  Created by yangjingyi on 1/1/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    int rangeBitwiseAnd(int m, int n)
    {
        return (n>m)?rangeBitwiseAnd(m/2,n/2):m;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
