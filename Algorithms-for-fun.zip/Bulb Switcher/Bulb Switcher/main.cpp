//
//  main.cpp
//  Bulb Switcher
//
//  Created by yangjingyi on 2/24/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    int bulbSwitch(int n)
    {
        int counts=0;
        for(int i=1;i*i<=n;i++)
        {
            counts++;
        }
        return counts;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
