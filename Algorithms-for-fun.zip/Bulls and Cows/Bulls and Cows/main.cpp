//
//  main.cpp
//  Bulls and Cows
//
//  Created by yangjingyi on 2/12/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
using namespace std;
class Solution
{
public:
    string getHint(string secret, string guess)
    {
        string s;
        if(secret.size()==0)
        {
            return s;
        }
        unordered_map<char, int> hash;
        int count1=0,count2=0;
        for(int i=0;i<secret.size();i++)
        {
            if(guess[i]==secret[i])
            {
                count1++;
                hash[secret[i]]++;
            }
            else
            {
                hash[secret[i]]++;
            }
        }
        for(int i=0;i<guess.size();i++)
        {
            if(hash.find(guess[i])!=hash.end()&&hash[guess[i]]!=0)
            {
                count2++;
                hash[guess[i]]--;
            }
        }
        s=to_string(count1)+"A"+to_string(count2-count1)+"B";
        return s;
        
        
    }
};

int main(int argc, const char * argv[]) {
    string in1="1807",in2="7810";
    Solution a;
    string out=a.getHint(in1, in2);
    cout<<out<<endl;
    return 0;
}
