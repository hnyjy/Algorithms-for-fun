//
//  main.cpp
//  Burst Balloons
//
//  Created by yangjingyi on 2/20/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int maxCoins(vector<int>& nums)
    {
        int num[nums.size()+2];
        int n=1;
        for(int x:nums)
        {
            num[n++]=x;
        }
        num[0]=num[n++]=1;
        int dp[n][n]={};
        for(int k=2;k<n;k++)
        {
            for(int left=0;left+k<n;left++)
                
            {
                int right=left+k;
                for(int i=left+1;i<right;i++)
                {
                    dp[left][right]=max(dp[left][right],dp[left][i]+dp[i][right]+num[left]*num[i]*num[right]);
                }
            }
        }
        return dp[0][n-1];
           
    
                                    
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
