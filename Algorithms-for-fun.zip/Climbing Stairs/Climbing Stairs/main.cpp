//
//  main.cpp
//  Climbing Stairs
//
//  Created by yangjingyi on 12/13/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    int climbStairs(int n)
    {
        int a=1,b=1;
        while(n--)
        {
            b=b+a;
            a=b-a;
        }
        return a;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
