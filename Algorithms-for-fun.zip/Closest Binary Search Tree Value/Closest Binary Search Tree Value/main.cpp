//
//  main.cpp
//  Closest Binary Search Tree Value
//
//  Created by yangjingyi on 2/1/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <climits>
#include <cmath>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    int closestValue(TreeNode* root, double target)
    {
        if(!root)
        {
            return INT_MAX;
        }
        int a=root->val;
        auto kid=target<a?root->left:root->right;
        if(!kid)
        {
            return a;
        }
        int b=closestValue(kid,target);
        return abs(a-target)<abs(b-target)?a:b;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
