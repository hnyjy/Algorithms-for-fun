//
//  main.cpp
//  Closest Binary Search Tree ValueII
//
//  Created by yangjingyi on 2/2/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
#include <vector>
#include <cmath>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* right;
    TreeNode* left;
    TreeNode(int x):val(x), left(NULL),right(NULL){}
};
class Solution
{
private:
    priority_queue<pair<double,int> > pq;
public:
    vector<int> closestKValues(TreeNode* root, double target, int k)
    {
        vector<int> res;
        traverse(root, target, k);
        while(pq.size())
        {
            res.push_back(pq.top().second);
            pq.pop();
        }
        return res;
    }
    void traverse(TreeNode* root, double target, int k)
    {
        if(!root)
        {
            return ;
        }
        double diff=abs(root->val-target);
        if(pq.size()<k)
        {
            pq.push(make_pair(diff,root->val));
        }
        else
        {
            pq.push(make_pair(diff,root->val));
            pq.pop();
        }
        traverse(root->right,target,k);
        traverse(root->left,target,k);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
