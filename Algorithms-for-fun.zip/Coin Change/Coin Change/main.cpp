//
//  main.cpp
//  Coin Change
//
//  Created by yangjingyi on 2/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;
class Solution
{
public:
    int coinChange(vector<int>& coins, int amount)
    {
        vector<int> dp(amount+1,-1);
        dp[0]=0;
        for(int i=1;i<=amount;i++)
        {
            for(auto &c:coins)
            {
                if(i-c>=0&&dp[i-c]!=-1)
                {
                    dp[i]=dp[i]>0?min(dp[i],dp[i-c]+1):dp[i-c]+1;
                }
            }
        }
        return dp[amount];
    }
};
int main(int argc, const char * argv[]) {
    vector<int> in1={1,2,5};
    int in2=100;
    Solution a;
    int out=a.coinChange(in1, in2);
    cout<<out<<endl;
    return 0;
}
