//
//  main.cpp
//  Combination Sum
//
//  Created by yangjingyi on 12/8/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    void Sum(vector<int>& can,vector<int>& tmpres, int tar,vector<vector<int> >& vecres,int start)
    {
        if(tar==0)
        {
            vecres.push_back(tmpres);
            return;
        }
        else
        {
            for(int i=start;i<can.size()&&tar>=can[i];i++)
            {
                tmpres.push_back(can[i]);
                Sum(can,tmpres,tar-can[i],vecres,i);
                tmpres.pop_back();
            }
        }
        
    }
    vector<vector<int> > combinationSum(vector<int>& candidates, int target)
    {
        sort(candidates.begin(),candidates.end());
        vector<int> vec;
        vector<vector<int> > res;
        Sum(candidates, vec,target,res,0);
        return res;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
