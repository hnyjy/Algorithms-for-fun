//
//  main.cpp
//  Combination SumII
//
//  Created by yangjingyi on 12/8/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    void Sum2(vector<vector<int> >& resv, vector<int>& tmpv, int target, int start, vector<int>& can)
    {
        if(target==0)
        {
            resv.push_back(tmpv);
            return;
        }
        for(int i=start;i<can.size()&&target>=can[i];i++)
        {
            if(i==start||can[i]!=can[i-1])
            {
                tmpv.push_back(can[i]);
                Sum2(resv,tmpv, target-can[i],i+1,can);
                tmpv.pop_back();
            }
        }
    }
    vector<vector<int> > combinationSum2(vector<int>& candidates,int target)
    {
        vector<vector<int> > res;
        vector<int> tmpv;
        sort(candidates.begin(),candidates.end());
        Sum2(res,tmpv,target,0,candidates);
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
