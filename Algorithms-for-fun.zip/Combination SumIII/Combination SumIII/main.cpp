//
//  main.cpp
//  Combination SumIII
//
//  Created by yangjingyi on 1/10/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    void find(int k, int n, int start, vector<int> tmp, vector<vector<int> >&res)
    {
        
        if(k==1&&n<=9&&n>=start)
        {
            tmp.push_back(n);
            res.push_back(tmp);
            return;
        }
        else if(k==1&&(n>9||n<start))
        {
            return;
        }
        else
        {
            for(int i=start;i<=9;i++)
            {
                //cout<<"i="<<i<<endl;
                tmp.push_back(i);
                find(k-1,n-i,i+1,tmp,res);
                tmp.pop_back();
            }
        }
    }
    vector<vector<int> > combinationSum3(int k, int n)
    {
        vector<vector<int>> res;
        vector<int> tmp;
        for(int i=1;i<=10-k;i++)
        {
            tmp.push_back(i);
            find(k-1,n-i,i+1,tmp,res);
            tmp.pop_back();
        }
        return res;
        
    }
};
int main(int argc, const char * argv[]) {
    int k=2,n=6;
    Solution a;
    vector<vector<int> >out=a.combinationSum3(k,n);
    for(int i=0;i<out.size();i++)
    {
        for(int j=0;j<out[i].size();j++)
        {
            cout<<out[i][j]<<" ";
        }
        cout<<endl;
    }
}
