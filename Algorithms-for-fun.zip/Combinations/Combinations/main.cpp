//
//  main.cpp
//  Combinations
//
//  Created by yangjingyi on 12/14/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    void combine(vector<vector<int> >& res, vector<int>& temp, int start,int num, int n, int k)
    {
        if(num==k)
        {
            res.push_back(temp);
            return;
        }
        else
        {
            for(int i=start;i<n;i++)
            {
                temp.push_back(i+1);
                combine(res,temp,i+1,num+1,n,k);
                temp.pop_back();
            }
        }
    }
    vector<vector<int> > combine(int n, int k)
    {
        vector<vector<int> > res;
        if(n<k)
            return res;
        vector<int> temp(0,k);
        combine(res,temp,0,0,n,k);
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
