//
//  main.cpp
//  Compare Version Numbers
//
//  Created by yangjingyi on 12/28/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int compareVersion(string version1, string version2)
    {
        vector<int> v1;
        vector<int> v2;
        int i=0;
        
        while(i<version1.size())
        {
            if(i==version1.size()-1)
            {
                v1.push_back(atoi(version1.substr(i).c_str()));
                break;
            }
            for(int j=i+1;j<version1.size();j++)
            {
                if(version1[j]=='.')
                {
                    v1.push_back(atoi(version1.substr(i,j).c_str()));
                    i=j+1;
                    break;
                    
                }
                if(j==version1.size()-1)
                {
                    v1.push_back(atoi(version1.substr(i).c_str()));
                    i=version1.size();
                    break;
                }
            }
        }
        /*for(int k=0;k<v1.size();k++)
        {
            cout<<v1[k]<<endl;
        }*/
        i=0;
        while(i<version2.size())
        {
            if(i==version2.size()-1)
            {
                v2.push_back(atoi(version2.substr(i).c_str()));
                break;
            }
            for(int j=i+1;j<version2.size();j++)
            {
                if(version2[j]=='.')
                {
                    v2.push_back(atoi(version2.substr(i,j).c_str()));
                    i=j+1;
                    break;
                }
                if(j==version2.size()-1)
                {
                    v2.push_back(atoi(version2.substr(i).c_str()));
                    i=version2.size();
                    break;
                }
            }
        }
        /*for(int k=0;k<v2.size();k++)
        {
            cout<<v2[k]<<endl;
        }*/
        i=0;
        for(;i<min(v1.size(),v2.size());i++)
        {
            if(v1[i]>v2[i])
            {
                return 1;
            }
            else if(v1[i]<v2[i])
            {
                return -1;
            }
        }
        if(v1.size()>v2.size())
        {
            int sum=0;
            for(int k=v2.size();k<v1.size();k++)
            {
                sum +=v1[k];
            }
            if(sum==0)
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        if(v2.size()>v1.size())
        {
            int sum=0;
            for(int k=v1.size();k<v2.size();k++)
            {
                sum +=v2[k];
            }
            if(sum==0)
            {
                return 0;
            }
            else
            {
                return -1;
            }
        }
        return 0;
    }
};

int main(int argc, const char * argv[]) {
    string version1="1";
    string version2="1.10";
    Solution a;
    int out=a.compareVersion(version1, version2);
    cout<<out<<endl;
    return 0;
}
