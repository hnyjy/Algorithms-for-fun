//
//  main.cpp
//  Construct Binary Tree from Inorder and Postorder Traversal
//
//  Created by yangjingyi on 12/19/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public: TreeNode* buildTree(vector<int>& inorder, vector<int>& postorder)
    {
        return helper(inorder,0,inorder.size(),postorder,0,postorder.size());
    }
private:
    TreeNode* helper(vector<int>& inorder, int i, int j,vector<int>& postorder, int ii, int jj)
    {
        if(i>=j||ii>=jj)
        {
            return NULL;
        }
        int mid=postorder[jj-1];
        auto f=find(inorder.begin()+i,inorder.begin()+j,mid);
        int dis=f-inorder.begin()-i;
        TreeNode* root=new TreeNode(mid);
        root->left=helper(inorder,i,i+dis,postorder,ii,ii+dis);
        root->right=helper(inorder,i+dis+1,j,postorder,ii+dis,jj-1);
        return root;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
