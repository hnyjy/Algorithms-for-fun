//
//  main.cpp
//  Construct Binary Tree from Preorder and Inorder Traversal
//
//  Created by yangjingyi on 12/19/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x), left(NULL),right(NULL){}
};
class Solution
{
public:
    TreeNode* buildTree(vector<int>& preorder, vector<int>& inorder)
    {
        if(preorder.size()==0||inorder.size()==0)
        {
            TreeNode* root;
            return root;
        }
        if(preorder.size()==1&&inorder.size()==1)
        {
            TreeNode* root=new TreeNode(preorder[0]);
            return root;
        }
        else
        {
            
            vector<int>::iterator it=find(inorder.begin(),inorder.end(),preorder[0]);
            if(it==inorder.begin())
            {
                TreeNode* root=new TreeNode(preorder[0]);
                vector<int> preorderr(preorder.begin()+1,preorder.end());
                vector<int> inorderr(inorder.begin()+1,inorder.end());
                root->right=buildTree(preorderr,inorderr);
                return root;
                
            }
            else if(it==inorder.end())
            {
                TreeNode* root=new TreeNode(preorder[0]);
                vector<int> preorderl(preorder.begin()+1,preorder.end());
                vector<int> inorderl(inorder.begin(),inorder.end()-1);
                root->left=buildTree(preorderl,inorderl);
                return root;
            }
            else
            {
                int leftcount=distance(inorder.begin(),it);
                int rightcount=distance(it,inorder.end())-1;
                TreeNode* root=new TreeNode(preorder[0])-1;
                vector<int> preorderl(preorder.begin()+1,preorder.begin()+1+leftcount);
                vector<int> inorderl(inorder.begin(),inorder.begin()+leftcount);
                vector<int> preorderr(preorder.begin()+leftcount+1,preorder.end());
                vector<int> inorderr(inorder.begin()+leftcount+1,inorder.begin());
                root->left=buildTree(preorderl,inorderl);
                root->right=buildTree(preorderr,inorderr);
                return root;
            }
        }
    
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in1, in2;
    Solution a;
    TreeNode* out=a.buildTree(in1, in2);
    
    return 0;
}
