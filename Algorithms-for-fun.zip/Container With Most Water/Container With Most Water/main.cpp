//
//  main.cpp
//  Container With Most Water
//
//  Created by yangjingyi on 4/22/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int maxArea(vector<int> &height)
    {
        int i=0;
        int j=height.size()-1;
        int result=0;
        int m,n;
        vector<int> tmp1,tmp2;
        if(height.size()>2)
        {
            for(m=0;m<height.size()-1;m++)
        {
            tmp1.push_back(height[m]);
        }
        for(n=0;n<height.size()-1;n++)
        {
            tmp2.push_back(height[n+1]);
        }
            
            result=height[i]>=height[j] ? max(height[j]*(j-i),maxArea(tmp1)):max(height[i]*(j-i),maxArea(tmp2));
                                                                                                                
        }
        else
        {
            result=height[0]>=height[1]?height[0]:height[1];
        }
            
        return result;
    };
};

int main()
{
    int ina[8]={3,8,6,2,16,2,9,4};
    vector<int> inv(ina,ina+8);
    Solution a;
    cout<<a.maxArea(inv)<<endl;;
}
