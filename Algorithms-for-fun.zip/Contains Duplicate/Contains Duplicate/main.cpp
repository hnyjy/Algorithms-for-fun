//
//  main.cpp
//  Contains Duplicate
//
//  Created by yangjingyi on 1/10/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;
class Solution
{
public:
    bool containsDuplicate(vector<int>& nums)
    {
        unordered_map<int,int> hash;
        for(int i=0;i<nums.size();i++)
        {
            if(hash.find(nums[i])==hash.end())
            {
                hash[nums[i]]=1;
            }
            else
            {
                return true;
            }
               
        }
        return false;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
