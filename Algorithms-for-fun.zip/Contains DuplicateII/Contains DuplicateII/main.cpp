//
//  main.cpp
//  Contains DuplicateII
//
//  Created by yangjingyi on 1/12/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;
class Solution
{
public:
    bool containsNearbyDuplicate(vector<int>& nums, int k)
    {
        unordered_map<int,int> hash;
        vector<int> check;
        for(int i=0;i<nums.size();i++)
        {
            if(hash.find(nums[i])==hash.end())
            {
                hash[nums[i]]=i;
            }
            else if(i-hash[nums[i]]>k)
            {
                continue;
            }
            else
            {
                check.push_back(i-hash[nums[i]]);
                hash[nums[i]]=i;
                
            }
        }
        return !check.empty();
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
