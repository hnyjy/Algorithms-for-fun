//
//  main.cpp
//  Contains DuplicateIII
//
//  Created by yangjingyi on 1/12/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <set>
#include <unordered_map>
#include <math.h>
using namespace std;
class Solution
{
public:
    bool containsNearbyAlmostDuplicate(vector<int>& nums, int k, int t)
    {
        set<int> record;
        for(int i=0;i<nums.size();i++)
        {
            if(i>k)
            {
                record.erase(nums[i-k-1]);
            }
            auto pos=record.lower_bound(nums[i]-t);
            if(pos!=record.end()&&abs(nums[i]-*pos)<=t)
            {
                return true;
            }
            record.insert(nums[i]);
        }
        return false;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
