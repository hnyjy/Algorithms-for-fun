//
//  main.cpp
//  Contains DuplicateIII2
//
//  Created by yangjingyi on 3/15/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <set>
using namespace std;
class Solution
{
public:
    bool containsNearbyAlmostDuplicate(vector<int>& nums, int k,int t)
    {
        set<int> record;
        for(int i=0;i<nums.size();i++)
        {
            if(i>k)
            {
                record.erase(nums[i-k-1]);
            }
            auto pos=record.lower_bound(nums[i]-t);
            if(pos!=record.end()&&abs(nums[i]-*pos)<t)
            {
                cout<<*pos<<endl;
                return true;
            }
            record.insert(nums[i]);
        }
        return false;
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in={4,2};
    Solution a;
    bool out=a.containsNearbyAlmostDuplicate(in, 2, 1);
    if(out==true)
    {
        cout<<"True"<<endl;
        
    }
    else
    {
        cout<<"False"<<endl;
    }
    return 0;
}
