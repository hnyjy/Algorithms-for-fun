//
//  main.cpp
//  Convert Sorted Array to Binary Search Tree
//
//  Created by yangjingyi on 12/19/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    TreeNode* sortedArrayToBST(vector<int>& nums)
    {
        if(nums.size()==0)
        {
           
            return NULL;
        }
        if(nums.size()==1)
        {
            TreeNode* root=new TreeNode(nums[0]);
            return root;
        }
        if(nums.size()==2)
        {
            TreeNode* root=new TreeNode(nums[1]);
            root->left=new TreeNode(nums[0]);
            return root;
            
        }
        else
        {
            int mid=nums.size()/2;
            TreeNode* root=new TreeNode(nums[mid]);
            vector<int> numsl(nums.begin(),nums.begin()+mid);
            vector<int> numsr(nums.begin()+mid+1,nums.end());
            root->left=sortedArrayToBST(numsl);
            root->right=sortedArrayToBST(numsr);
            return root;
            
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    vector<int> test={1,2,3,4,5,6,7};
    int mid=test.size()/2;
    vector<int> l(test.begin(),test.begin()+mid);
    vector<int> r(test.begin()+mid+1,test.begin()+mid+2);
    for(int i=0;i<l.size();i++)
    {
        cout<<l[i]<<",";
    }
    cout<<endl;
    for(int i=0;i<r.size();i++)
    {
        cout<<r[i]<<",";
    }
    cout<<distance(test.begin(),test.begin()+mid)<<endl;
    return 0;
}
