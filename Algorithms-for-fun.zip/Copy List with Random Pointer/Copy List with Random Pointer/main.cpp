//
//  main.cpp
//  Copy List with Random Pointer
//
//  Created by yangjingyi on 12/23/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
using namespace std;
struct RandomListNode
{
    int label;
    RandomListNode *next, *random;
    RandomListNode(int x):label(x),next(NULL),random(NULL){}
};
class Solution
{
public:
    unordered_map<RandomListNode*, RandomListNode*> hash;
    RandomListNode *copyRandomList(RandomListNode *head)
    {
        if(!head)
        {
            return head;
        }
        
        if(hash.find(head)==hash.end())
        {
            hash[head]=new RandomListNode(head->label);
            if(head->next)
            {
                hash[head]->next=copyRandomList(head->next);;
                
            }
            if(head->random)
            {
                hash[head]->random=copyRandomList(head->random);
            }
        }
        return hash[head];
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
