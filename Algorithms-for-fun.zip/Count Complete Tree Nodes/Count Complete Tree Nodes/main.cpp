//
//  main.cpp
//  Count Complete Tree Nodes
//
//  Created by yangjingyi on 1/14/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <math.h>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL) {}
};
class Solution
{
public:
    int countNodes(TreeNode* root)
    {
        if(!root)
        {
            return 0;
        }
        int hl=0,hr=0;
        TreeNode *l=root,*r=root;
        while(l)
        {
            hl++;
            l=l->left;
        }
        while(r)
        {
            hr++;
            r=r->right;
        }
        if(hl==hr)
        {
            return pow(2,hl)-1;
        }
        return 1+countNodes(root->left)+countNodes(root->right);
    }
 
};


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
