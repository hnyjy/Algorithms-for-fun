//
//  main.cpp
//  Count Primes
//
//  Created by yangjingyi on 1/1/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <math.h>
using namespace std;
class Solution
{
public:
    int countPrimes(int n)
    {
        if(n<=2)
        {
            return 0;
        }
        vector<bool> prim(n,false);
        int sum=1;
        int upper=sqrt(n);
        for(int i=3;i<n;i+=2)
        {
            if(!prim[i])
            {
                sum++;
                if(i>upper)
                {
                    continue;
                }
                for(int j=i*i;j<n;j+=i)
                {
                    prim[j]=true;
                }
            }
        }
        return sum;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
