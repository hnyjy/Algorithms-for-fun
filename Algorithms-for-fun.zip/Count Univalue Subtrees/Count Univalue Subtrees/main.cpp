//
//  main.cpp
//  Count Univalue Subtrees
//
//  Created by yangjingyi on 1/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    int countUnivalSubtrees(TreeNode* root)
    {
        if(root==NULL)
        {
            return result;
        }
        if(same(root,root->val))
        {
            ++result;
        }
        countUnivalSubtrees(root->left);
        countUnivalSubtrees(root->right);
        return result;
    }
private:
    int result=0;
    bool same(TreeNode* root,int val)
    {
        if(root==NULL)
        {
            return true;
        }
        return root->val==val&&same(root->left,val)&&same(root->right,val);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
