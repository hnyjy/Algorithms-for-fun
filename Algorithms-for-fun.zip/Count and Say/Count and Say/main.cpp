//
//  main.cpp
//  Count and Say
//
//  Created by yangjingyi on 12/7/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    long int say(int n)
    {
        long int res;
        string result="";
        long int count=1;
        //int start=0;
        long int i=10;
        vector<long int> tmp;
        while(n>0)
        {
            tmp.push_back((n%i)*10/i);
            n=n-n%i;
            i=i*10;
            
        }
        if(tmp.size()==1)
            result="1"+to_string(tmp[0]);
        for(int j=tmp.size()-2;j>=0;j--)
        {
            if(tmp[j]==tmp[j+1])
            {
                count++;
                if(j==0)
                {
                    result=result+to_string(count)+to_string(tmp[j]);
                    
                }
            }
            else
            {
                if(j==0)
                {
                    result=result+to_string(count)+to_string(tmp[j+1]);
                    result=result+"1"+to_string(tmp[j]);
                    break;
                }
                result=result+to_string(count)+to_string(tmp[j+1]);
                count=1;
            }
        }
        //cout<<result<<endl;
        res=atoi(result.c_str());
        //cout<<res<<endl;
        return res;
        
    }
    string countAndSay(long int n)
    {
        //cout<<say(1)<<endl;
        string res;
        long int tmp=1;
        if(n==1)
            return "1";
        for(int i=0;i<n-1;i++)
        {
            cout<<"right"<<endl;
            
            //cout<<"wrong"<<endl;
            //cout<<res<<endl;
            tmp=say(tmp);
        }
        
        
        return to_string(tmp);
        
    }
};

int main()
{
    Solution a;
    cout<<a.countAndSay(8)<<endl;
}
