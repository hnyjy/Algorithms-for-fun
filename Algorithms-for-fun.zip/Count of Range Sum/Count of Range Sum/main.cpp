//
//  main.cpp
//  Count of Range Sum
//
//  Created by yangjingyi on 3/4/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <set>
using namespace std;
class Solution
{
public:
    int countRangeSum(vector<int>& nums, int lower, int upper)
    {
        multiset<long long> pSum;
        int res=0,i;
        long long left, right,sum=0;
        for(i=0,pSum.insert(0);i<nums.size();i++)
        {
            sum+=nums[i];
            res+=distance(pSum.lower_bound(sum-upper),pSum.upper_bound(sum-lower));
            pSum.insert(sum);
        }
        return res;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
