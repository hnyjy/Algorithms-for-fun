//
//  main.cpp
//  Count of Smaller Numbers After Self
//
//  Created by yangjingyi on 2/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<int> countSmaller(vector<int>& nums)
    {
        int size=nums.size();
        vector<int> res;
        vector<int> temp;
        for(int i=size-1;i>=0;i--)
        {
            res.push_back(insert(temp,nums[i]));
        }
        reverse(res.begin(),res.end());
        return res;
        
    }
    int insert(vector<int>& temp,int num)
    {
        int size=temp.size();
        int res=distance(temp.begin(),lower_bound(temp.begin(),temp.end(),num));
        temp.insert(temp.begin()+res,num);
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
