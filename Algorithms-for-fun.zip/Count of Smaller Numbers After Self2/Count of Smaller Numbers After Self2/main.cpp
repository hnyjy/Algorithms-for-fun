//
//  main.cpp
//  Count of Smaller Numbers After Self2
//
//  Created by yangjingyi on 3/19/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <set>
using namespace std;
class Solution
{
public:
    vector<int> countSmaller(vector<int>& nums)
    {
        int size=nums.size();
        vector<int> res;
        multiset<int> temp;
        for(int i=size-1;i>=0;i--)
        {
            res.push_back(count(temp,nums[i]));
        }
        reverse(res.begin(),res.end());
        return res;
    }
    int count(multiset<int>& temp, int num)
    {
        int size=temp.size();
        int res=distance(temp.begin(),lower_bound(temp.begin(),temp.end(),num));
        temp.insert(num);
        return res;
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in={6,4,1,8,7,5,2,9};
    Solution a;
    vector<int> out=a.countSmaller(in);
    for(auto num:out)
    {
        cout<<num<<" ";
    }
    return 0;
}
