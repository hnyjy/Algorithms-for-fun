//
//  main.cpp
//  Course Schedule
//
//  Created by yangjingyi on 1/2/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_set>
using namespace std;
class Solution
{
public:
    bool canFinish(int numCourses, vector<pair<int,int> >& prerequisites)
    {
        vector<unordered_set<int> > matrix(numCourses);
        for(int i=0;i<prerequisites.size();++i)
        {
            matrix[prerequisites[i].second].insert(prerequisites[i].first);
        }
        vector<int> d(numCourses,0);
        for(int i=0;i<numCourses;i++)
        {
            for(auto it=matrix[i].begin();it!=matrix[i].end();++it)
            {
                ++d[*it];
            }
        }
        for(int j=0,i;j<numCourses;++j)
        {
            for(i=0;i<numCourses&&d[i]!=0;++i);
            if(i==numCourses)
            {
                return false;
            }
            d[i]=-1;
            for(auto it=matrix[i].begin();it!=matrix[i].end();++it)
            {
                --d[*it];
            }
           
        }
        return true;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
