//
//  main.cpp
//  Course ScheduleII
//
//  Created by yangjingyi on 1/4/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <set>
#include <unordered_map>
using namespace std;
class Solution
{
public:
    void order(vector<set<int> >& matrix,vector<int>& d,vector<int> tmp,vector<vector<int> >res,int numCourses,int courseNo)
    {
        
        vector<int> copy=tmp;
        if(tmp.size()==numCourses)
        {
            res.push_back(tmp);
            return;
        }
        else
        {
            for(auto it=matrix[courseNo].begin();it!=matrix[courseNo].end();++it)
            {
                --d[*it];
            }
            for(int j=0,i;j<numCourses;j++)
            {
                for(i=0;i<numCourses&&d[i]!=0;++i)
                {
                    
                }
                tmp.push_back(i);
                d[i]=-1;
                order(matrix,d,tmp,res,numCourses,i);
                tmp.pop_back();
            }
        }
        
    }
    vector<int> findOrder(int numCourses, vector<pair<int,int>>& prerequisites)
    {
        vector<set<int> >matrix(numCourses);
        for(int i=0;i<prerequisites.size();i++)
        {
            matrix[prerequisites[i].second].insert(prerequisites[i].first);
        }
        vector<int> d(numCourses,0);
        for(int i=0;i<numCourses;i++)
        {
            for(auto it=matrix[i].begin();it!=matrix[i].end();++it)
            {
                d[*it]++;
            }
        }
        vector<vector<int> > res;
        vector<int> tmp;
        for(int j=0,i;j<numCourses;++j)
        {
            for(i=0;i<numCourses&&d[i]!=0;++i);
            if(i==numCourses)
            {
                tmp.clear();
                return tmp;
            }
            d[i]=-1;
            tmp.push_back(i);
            for(auto it=matrix[i].begin();it!=matrix[i].end();it++)
            {
                --d[*it];
            }
            
        }
        return tmp;
        
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
