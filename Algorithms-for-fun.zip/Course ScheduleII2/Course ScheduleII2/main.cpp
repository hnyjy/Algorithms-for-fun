//
//  main.cpp
//  Course ScheduleII2
//
//  Created by yangjingyi on 3/20/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
#include <set>
using namespace std;
class Solution
{
public:
    vector<int> findOrder(int numCourses, vector<pair<int,int> >&prerequisites)
    {
        vector<set<int> >matrix(numCourses);
        for(int i=0;i<numCourses;i++)
        {
            matrix[prerequisites[i].second].insert(prerequisites[i].first);
        }
        vector<int> d(numCourses,0);
        for(int i=0;i<numCourses;i++)
        {
            for(auto it=matrix[i].begin();it!=matrix[i].end();it++)
            {
                d[*it]++;
            }
        }
        vector<vector<int> >res;
        vector<int> tmp;
        for(int i=0,j;i<numCourses;i++)
        {
            for(i=0;i<numCourses&&d[i]!=0;i++);
            if(i==numCourses)
            {
                tmp.clear();
                return tmp;
            }
            d[i]=-1;
            tmp.push_back(i);
            for(auto it=matrix[i].begin();it!=matrix[i].end();it++)
            {
                --d[*it];
            }
            
        }
        return tmp;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
