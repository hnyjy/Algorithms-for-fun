//
//  main.cpp
//  Delete Node in a Linked List
//
//  Created by yangjingyi on 1/17/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
};
class Solution
{
public:
    void deleteNode(ListNode* node)
    {
        node=node->next;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
