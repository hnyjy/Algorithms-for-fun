//
//  main.cpp
//  Distinct Subsequences
//
//  Created by yangjingyi on 12/20/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int numDistinct(string s, string t)
    {
        int m=t.size();
        int n=s.size();
        if(m>n)
        {
            return 0;
        }
        vector<vector<int> >path(m+1,vector<int>(n+1,0));
        for(int k=0;k<=n;k++)
        {
            path[0][k]=1;
        }
        for(int j=1;j<=n;j++)
        {
            for(int i=1;i<=m;i++)
            {
                path[i][j]=path[i][j-1]+(t[i-1]==s[j-1]?path[i-1][j-1]:0);
            }
        }
        return path[m][n];
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
