//
//  main.cpp
//  Divide Two Intergers
//
//  Created by yangjingyi on 10/19/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    int divide(int dividend, int divisor)
    {
        if(divisor ==0)
        {
            return dividend<0?INT_MIN:INT_MAX;
        }
        if(divisor == INT_MIN)
        {
            return dividend<0?dividend==INT_MIN:0;
        }
        unsigned int div[32],a=dividend<0?-dividend:dividend,b=divisor<0?-divisor:divisor,index=0,ret=0;
        if(a<b) return 0;
        div[0]=divisor;
        while(a>=b)
        {
            a-=b;
            ret+=(1<<index);
            div[index++]=b;
            b<<=1;
        }
        while((int)a>=div[0])
        {
            if(a>=div[--index])
            {
                a-=div[index];
                ret+=(1<<index);
            }
        }
        return (dividend^divisor)<0?-ret:(ret>INT_MAX?INT_MAX:ret);
    }
};

int main(int argc, const char * argv[]) {
    int b=8;
    b<<=1;
    cout<<b<<endl;
}
