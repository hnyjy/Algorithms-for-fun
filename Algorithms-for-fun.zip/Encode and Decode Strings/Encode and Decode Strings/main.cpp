//
//  main.cpp
//  Encode and Decode Strings
//
//  Created by yangjingyi on 2/2/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Codec
{
public:
    string encode(vector<string>& strs)
    {
        string encoded="";
        for(string &str:strs)
        {
            int len=str.size();
            encoded +=to_string(len)+"@"+str;
        }
        return encoded;
    }
    vector<string> decode(string s)
    {
        vector<string> r;
        int head=0;
        while(head<s.size())
        {
            int at_pos=s.find_first_of('@',head);
            int len=stoi(s.substr(head,at_pos-head));
            head=at_pos+1;
            r.push_back(s.substr(head,len));
            head+=len;
        }
        return r;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
