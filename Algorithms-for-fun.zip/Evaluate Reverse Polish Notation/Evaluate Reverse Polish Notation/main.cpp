//
//  main.cpp
//  Evaluate Reverse Polish Notation
//
//  Created by yangjingyi on 12/26/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int evalRPN(vector<string>& tokens)
    {
        string s=tokens.back();
        tokens.pop_back();
        if(s=="*"||s=="/"||s=="+"||s=="-")
        {
            int r2=evalRPN(tokens);
            int r1=evalRPN(tokens);
            if(s=="*")
                return r1*r2;
            if(s=="/")
                return r1/r2;
            if(s=="+")
                return r1+r2;
            if(s=="-")
                return r1-r2;
        }
        else
            return atoi(s.c_str());
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
