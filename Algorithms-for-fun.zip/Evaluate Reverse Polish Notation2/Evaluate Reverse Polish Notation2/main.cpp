//
//  main.cpp
//  Evaluate Reverse Polish Notation2
//
//  Created by yangjingyi on 12/26/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <stack>
using namespace std;
class Solution
{
public:
    int evalRPN(vector<string>& tokens)
    {
        
        stack<string> stk;
        for(int i=0;i<tokens.size();i++)
        {
            string s=tokens.back();
            tokens.pop_back();
            if(s=="*"||s=="/"||s=="+"||s=="-")
            {
                int r1=atoi(stk.top().c_str());
                stk.pop();
                int r2=atoi(stk.top().c_str());
                stk.pop();
                string tmp;
                if(s=="*")
                {
                    tmp=to_string(r1*r2);
                }
                if(s=="/")
                {
                    tmp=to_string(r1/r2);
                }
                if(s=="+")
                {
                    tmp=to_string(r1+r2);
                }
                if(s=="-")
                {
                    tmp=to_string(r1-r2);
                }
                stk.push(tmp);
            }
            else
            {
                stk.push(s);
            }
        }
        return atoi(stk.top().c_str());
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
