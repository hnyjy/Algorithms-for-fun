//
//  main.cpp
//  Excel Sheet Column Number
//
//  Created by yangjingyi on 12/28/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    int titleToNumber(string s)
    {
        int result=0;
        for(int i=0;i<s.size();result=result*26+(s.at(i)-'A'+1),i++);
        return result;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
