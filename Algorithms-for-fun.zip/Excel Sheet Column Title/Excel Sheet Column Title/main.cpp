//
//  main.cpp
//  Excel Sheet Column Title
//
//  Created by yangjingyi on 12/28/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    string convertToTitle(int n)
    {
        return n==0?"":convertToTitle((n-1)/26)+(char)((n-1)%26+'A');
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
