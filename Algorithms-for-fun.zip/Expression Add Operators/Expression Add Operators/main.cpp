//
//  main.cpp
//  Expression Add Operators
//
//  Created by yangjingyi on 2/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<string> addOperators(string num, int target)
    {
        vector<string> ret;
        if(num.length()==0)
        {
            return ret;
        }
        help(num,target,ret,num[0]-'0',num.substr(0,1),1,1);
        return ret;
    }
    void help(const string num, int target, vector<string>& v, long long last, string s, int index, int left)
    {
        if(target==last*left&&index==num.length())
        {
            v.push_back(s);
            return;
        }
        else if(index==num.length())
        {
            return;
        }
        else
        {
            if(last!=0)
            {
                help(num,target,v,last*10+num[index]-'0',s+num.substr(index,1),index+1,left);
            }
            help(num,target,v,num[index]-'0',s+'*'+num.substr(index,1),index+1,left*last);
            help(num,target-left*last,v,num[index]-'0',s+'+'+num.substr(index,1),index+1,1);
            help(num,target-left*last,v,num[index]-'0',s+'-'+num.substr(index,1),index+1,-1);
        }
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
