//
//  main.cpp
//  FInd Minimum in Rotated Sorted ArrayII
//
//  Created by yangjingyi on 12/27/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int findMin(vector<int>& nums)
    {
        int left=0;
        int right=nums.size()-1;
        int mid;
        while(left<right)
        {
            mid=left+(right-left)/2;
            if(nums[mid]<nums[right])
            {
                right=mid;
            }
            else if(nums[mid]>nums[right])
            {
                left=mid+1;
            }
            else
            {
                right--;
            }
        
        }
        return nums[left];
    }
};
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
