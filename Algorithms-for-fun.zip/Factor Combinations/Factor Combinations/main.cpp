//
//  main.cpp
//  Factor Combinations
//
//  Created by yangjingyi on 1/26/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<vector<int> > getFactors(int n)
    {
        vector<int> sol;
        vector<vector<int> > res;
        generate(n,2,sol,res);
        res.pop_back();
        return res;
    }
    void generate(int n, int idx, vector<int> &sol, vector<vector<int> >& res)
    {
        for(int i=idx;i<=n/i;i++)
            
        {
            if(n%i)
            {
                continue;
            }
            sol.push_back(i);
            generate(n/i,i,sol,res);
            sol.pop_back();
        }
        sol.push_back(n);
        res.push_back(sol);
        sol.pop_back();
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
