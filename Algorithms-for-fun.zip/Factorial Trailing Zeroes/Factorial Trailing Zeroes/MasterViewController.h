//
//  MasterViewController.h
//  Factorial Trailing Zeroes
//
//  Created by yangjingyi on 12/28/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;

@interface MasterViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;


@end

