//
//  main.cpp
//  Fatorial Trailing Zeroes
//
//  Created by yangjingyi on 12/28/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    int trailingZeroes(int n)
    {
        int result=0;
        for(long long i=5;n/i>0;i*=5)
        {
            result +=(n/i);
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
