//
//  main.cpp
//  Find Minimum in Rotated Sorted Array
//
//  Created by yangjingyi on 12/27/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int findMin(vector<int>& nums)
    {
        int left=0;
        int right=nums.size()-1;
        int mid;
        if(nums.size()==1)
        {
            return nums[0];
        }
        while(right>left)
        {
            if(nums[left]<nums[right])
            {
                return nums[left];
            }
            if(right==left)
            {
                return nums[left];
            }
            mid=left+(right-left)/2;
            if(nums[mid]>=nums[left])
            {
                left=mid+1;
            }
            else
            {
                right=mid;
            }
        }
        return nums[left];
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
