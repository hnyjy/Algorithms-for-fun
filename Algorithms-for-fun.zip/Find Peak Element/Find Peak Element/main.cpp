//
//  main.cpp
//  Find Peak Element
//
//  Created by yangjingyi on 12/27/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int findPeakElement(vector<int>& nums)
    {
        int low=0,high=nums.size()-1;
        while(low<high-1)
        {
            int mid=(low+high)/2;
            if(nums[mid]>nums[mid-1]&&nums[mid]>nums[mid+1])
            {
                return mid;
            }
            else if(nums[mid]>nums[mid+1])
            {
                high=mid-1;
            }
            else
                low=mid+1;
        }
        return nums[low]>nums[high]?low:high;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
