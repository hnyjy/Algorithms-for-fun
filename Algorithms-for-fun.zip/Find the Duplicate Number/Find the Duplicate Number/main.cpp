//
//  main.cpp
//  Find the Duplicate Number
//
//  Created by yangjingyi on 2/9/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int findDuplicate(vector<int>& nums)
    {
        if(nums.size()>1)
        {
            int slow=nums[0];
            int fast=nums[nums[0]];
            while(slow!=fast)
            {
                slow=nums[slow];
                fast=nums[nums[fast]];
                
            }
            fast=0;
            while(fast!=slow)
            {
                fast=nums[fast];
                slow=nums[slow];
            }
            return slow;
        }
        return -1;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
