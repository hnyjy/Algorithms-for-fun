//
//  main.cpp
//  Find the Duplicate Number2
//
//  Created by yangjingyi on 2/9/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int findDuplicate(vector<int>& nums)
    {
        int n=nums.size()-1;
        int low=1,high=n;
        int mid=0;
        while(low<high)
        {
            mid=low+(high-low)/2;
            int count=0;
            for(auto num:nums)
            {
                if(num<=mid)
                {
                    ++count;
                }
            }
            if(count<=mid)
            {
                low=mid+1;
                
            }
            else
            {
                high=mid-1;
            }
        }
        return low;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
