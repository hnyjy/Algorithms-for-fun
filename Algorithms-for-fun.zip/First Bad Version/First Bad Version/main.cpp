//
//  main.cpp
//  First Bad Version
//
//  Created by yangjingyi on 2/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
bool isBadVersion(int version);
class Solution
{
public:
    int firstBadVersion(int n)
    {
        int first=0;
        int last=n-1;
        
        while(last>first)
        {
            int mid=first+(last-first)/2;
            if(isBadVersion(mid))
            {
                last=mid;
            }
            else
            {
                first=mid+1;
            }
        }
        return first;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
