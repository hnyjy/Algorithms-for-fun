//
//  main.cpp
//  First Missing Positive
//
//  Created by yangjingyi on 12/8/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int firstMissingPositive(vector<int>& nums)
    {
        for(int i=0;i<nums.size();i++)
        {
            while(nums[i]>0&&nums[i]<=nums.size()&&nums[nums[i]-1]!=nums[i])
            {
                swap(nums[i],nums[nums[i]-1]);
                
            }
        }
        for(int i=0;i<nums.size();i++)
        {
            if(nums[i]!=i+1)
                return i+1;
        }
        return nums.size()+1;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
