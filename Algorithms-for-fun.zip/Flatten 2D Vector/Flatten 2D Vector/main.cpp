//
//  main.cpp
//  Flatten 2D Vector
//
//  Created by yangjingyi on 1/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Vector2D
{
    vector<vector<int> >::iterator i,iEnd;
    int j=0;
public:
    Vector2D(vector<vector<int> >& vec2d)
    {
        i=vec2d.begin();
        iEnd=vec2d.end();
    }
    int next()
    {
        hasNext();
        return (*i)[j++];
    }
    bool hasNext()
    {
        while(i!=iEnd&&j==(*i).size())
        {
            i++;
            j=0;
        }
        return i!=iEnd;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
