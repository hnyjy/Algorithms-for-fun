//
//  main.cpp
//  Flatten Binary Tree to Linked List
//
//  Created by yangjingyi on 12/19/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <stack>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    void flatten(TreeNode* root)
    {
        stack<TreeNode*> stk;
        vector<int> result;
        //TreeNode fh(0);
        TreeNode* froot=root;
        
        if(!root)
        {
            return;
        }
        else
        {
            while(root||!stk.empty())
            {
                while(root)
                {
                    result.push_back(root->val);
                    stk.push(root);
                    root=root->left;
                    
                }
               
                root=stk.top();
                stk.pop();
                root=root->right;
            }
            for(int i=1;i<result.size();i++)
            {
                froot->left=NULL;
                
                froot->right=new TreeNode(result[i]);
                froot=froot->right;
                
            }
            
            //cout<<"wrong"<<fh.right->val<<endl;
            //cout<<"wrong"<<fh.right->right->val<<endl;
            //root=fh.right;
            //cout<<root->val<<endl;
            //cout<<root->right->val<<endl;
            //return;
        }
        
    }
};
int main(int argc, const char * argv[]) {
    TreeNode* root=new TreeNode(1);
    root->left=new TreeNode(2);
    Solution a;
    a.flatten(root);
    while(root)
    {
        cout<<root->val<<endl;
        root=root->right;
    }
    return 0;
}
