//
//  main.cpp
//  Flip Game
//
//  Created by yangjingyi on 2/11/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<string> generatePossibleNextMoves(string s)
    {
        vector<string> moves;
        int n=s.length();
        for(int i=0;i<n-1;i++)
        {
            if(s[i]=='+'&&s[i+1]=='+')
            {
                s[i]=s[i+1]='-';
                moves.push_back(s);
                s[i]=s[i+1]='+';
            }
        }
        return moves;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
