//
//  main.cpp
//  Flip GameII
//
//  Created by yangjingyi on 2/11/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    bool canWin(string s)
    {
        for(int i=0;i<s.length()-1;i++)
        {
            if(s[i]=='+'&&s[i+1]=='+'&&!canWin(s.substr(0,i)+"--"+s.substr(i+2)))
            {
                return true;
            }
        }
        return false;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
