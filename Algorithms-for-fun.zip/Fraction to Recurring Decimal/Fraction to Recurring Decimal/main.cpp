//
//  main.cpp
//  Fraction to Recurring Decimal
//
//  Created by yangjingyi on 12/28/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
#include <math.h>
using namespace std;
class Solution
{
public:
    string fractionToDecimal(int64_t n, int64_t d)
    {
        if(n==0)
            return "0";
        string res;
        if(n<0^d<0)
        {
            res +='-';
        }
        n=abs(n),d=abs(d);
        res +=to_string(n/d);
        if(n%d==0)
        {
            return res;
        }
        res +='.';
        unordered_map<int,int> map;
        for(int64_t r=n%d;r;r%=d)
        {
            if(map.count(r)>0)
            {
                res.insert(map[r],1,'(');
                res +=')';
                break;
            }
            map[r]=res.size();
            r *=10;
            res +=to_string(r/d);
        }
        return res;
    }
};


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
