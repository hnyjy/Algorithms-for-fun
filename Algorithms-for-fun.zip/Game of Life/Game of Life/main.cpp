//
//  main.cpp
//  Game of Life
//
//  Created by yangjingyi on 2/9/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
     void gameOfLife(vector<vector<int> >& board)
    {
        int m=board.size(),n=m?board[0].size():0;
        for(int i=0;i<m;++i)
        {
            for(int j=0;j<n;j++)
            {
                int count=0;
                for(int I=max(i-1,0);I<min(i+2,m);++I)
                {
                    for(int J=max(j-1,0);J<min(j+2,n);++J)
                    {
                        count +=board[I][J]&1;
                    }
                }
                if(count==3||count-board[i][j]==3)
                {
                    board[i][j]|=2;
                }
            }
        }
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<n;j++)
            {
                board[i][j]>>=1;
            }
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
