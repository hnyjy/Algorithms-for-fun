//
//  main.cpp
//  Gas Station
//
//  Created by yangjingyi on 12/23/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int canCompleteCircuit(vector<int>& gas, vector<int>& cost)
    {
        int start=gas.size()-1;
        int end=0;
        int sum=gas[start]-cost[start];
        while(start>end)
        {
            if(sum>=0)
            {
                sum+=gas[end]-cost[end];
                end++;
            }
            else
            {
                start--;
                sum+=gas[start]-cost[start];
            }
        }
        return sum>=0?start:-1;
    }
    
};

int main(int argc, const char * argv[]) {
    vector<int> in1={1,2,3,3};
    vector<int> in2={2,1,5,1};
    Solution a;
    int out=a.canCompleteCircuit(in1,in2);
    cout<<out<<endl;
    return 0;
}
