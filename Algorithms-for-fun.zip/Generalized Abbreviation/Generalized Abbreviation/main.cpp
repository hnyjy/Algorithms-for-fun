//
//  main.cpp
//  Generalized Abbreviation
//
//  Created by yangjingyi on 2/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<string> generateAbbreviations(string word)
    {
        vector<string> result;
        generateAbbreviationsHelper(word,"",0,result,false);
        return result;
    }
    void generateAbbreviationsHelper(string& word, string abbr, int i, vector<string>& result, bool preNum)
    {
        if(i==word.length())
        {
            result.push_back(abbr);
            return;
        }
        generateAbbreviationsHelper(word, abbr+word[i],i+1,result,false);
        if(!preNum)
        {
            for(int len=1;i+len<=word.length();++len)
            {
                generateAbbreviationsHelper(word, abbr+to_string(len),i+len,result, true);
            }
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
