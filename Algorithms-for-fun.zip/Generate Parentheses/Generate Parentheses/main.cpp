//
//  main.cpp
//  Generate Parentheses
//
//  Created by yangjingyi on 9/4/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    void dfs(vector<string> &res, string cur, int lleft, int rleft)
    {
        if(lleft<=0)
            res.push_back(cur+string(rleft,')'));
        else
        {
            dfs(res,cur+"(", lleft-1,rleft);
            if(lleft<rleft)
                dfs(res,cur+")",lleft,rleft-1);
            
        }
    }
    vector<string> generateParenthesis(int n)
    {
        vector<string> result;
        dfs(result,"",n,n);
        return result;
    }
};

int main()
{
    
}
