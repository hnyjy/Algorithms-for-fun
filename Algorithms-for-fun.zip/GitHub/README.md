#Algorithms-for-fun
