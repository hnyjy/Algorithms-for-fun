//
//  main.cpp
//  Google Demo
//
//  Created by yangjingyi on 3/7/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int solution(vector<int>& A)
    {
        if(A.size()==0)
        {
            return 0;
        }
        vector<int> sum(A.size()+1,0);
        for(int i=1;i<A.size()+1;i++)
        {
            sum[i]=sum[i-1]+A[i-1];
        }
        if(sum[sum.size()-2]==0)
        {
            return A.size()-1;
        }
        for(int i=1;i<sum.size()-1;i++)
        {
            if(sum[i]==sum[sum.size()-1]-sum[i]-A[i])
            {
                return i;
            }
        }
        return -1;
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in={-1,3,-4,5,1,-6,2,1};
    Solution a;
    int out=a.solution(in);
    cout<<out<<endl;
    return 0;
}
