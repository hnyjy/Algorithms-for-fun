//
//  main.cpp
//  3Sum Smaller2
//
//  Created by yangjingyi on 5/3/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <climits>
#include <vector>
using namespace std;
class Solution
{
public:
    int threeSumSmaller(vector<int>& nums, int target)
    {
        sort(nums.begin(),nums.end());
        int res=0;
        for(int i=0;i<nums.size()-2;i++)
        {
            for(int j=i+1;j<nums.size()-1;j++)
            {auto it=lower_bound(nums.begin()+j+1,nums.end(),target-nums[i]-nums[j]);
            int dis=distance(nums.begin(),it);
            cout<<"i="<<i<<" j="<<j<<" dis="<<dis<<endl;
                res+=dis-j-1;}
            
        }
        return res;
    }
};
int main(int argc, const char * argv[]) {
    vector<int> in={-2,0,1,-1,3};
    int target=2;
    Solution a;
    int out=a.threeSumSmaller(in , target);
    cout<<out<<endl;
    return 0;
}
