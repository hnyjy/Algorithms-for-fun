//
//  main.cpp
//  Add and Search Word - Data structure design3
//
//  Created by yangjingyi on 4/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;
struct TrieNode
{
    bool isEnd=false;
    unordered_map<char,TrieNode*> children;
};
class WordDictionary
{
public:
    TrieNode* root;
    WordDictionary()
    {
        root=new TrieNode();
    }
    void addWord(string word)
    {
        TrieNode* curr=root;
        for(char w:word)
        {
            if(curr->children.find(w)!=curr->children.end())
            {
                curr=curr->children[w];
            }
            //TrieNode* newNode=new TrieNode();
            else
            {
                curr->children[w]=new TrieNode();
                curr=curr->children[w];
            }
        }
        curr->isEnd=true;
    }
    bool search(string word,TrieNode* node)
    {
        if(word.size()==0)
        {
            return node->isEnd;
        }
        else if(word[0]=='.')
        {
            for(auto it=node->children.begin();it!=node->children.end();it++)
            {
                if(search(word.substr(1),it->second))
                {
                    return true;
                }
            }
            return false;
        }
        else
        {
            if(node->children.find(word[0])!=node->children.end())
            {
                return search(word.substr(1),node->children[word[0]]);
            }
            else
            {
                return false;
            }
        }
    }
    bool search(string word)
    {
        TrieNode* node=root;
        return search(word,node);
    }
};

int main(int argc, const char * argv[]) {
    WordDictionary wd;
    wd.addWord("bad");
    wd.addWord("dad");
    wd.addWord("mad");
    wd.addWord("phgf");
    wd.addWord("pji");
    
    bool out1=wd.search("pji");
    if(out1)
    {
        cout<<"true"<<endl;
    }
    else
    {
        cout<<"false"<<endl;
    }
    bool out2=wd.search("bad");
    if(out2)
    {
        cout<<"true"<<endl;
    }
    else
    {
        cout<<"false"<<endl;
    }
    bool out3=wd.search(".ad");
    if(out3)
    {
        cout<<"true"<<endl;
    }
    else
    {
        cout<<"false"<<endl;
    }
    bool out4=wd.search("b..");
    if(out4)
    {
        cout<<"true"<<endl;
    }
    else
    {
        cout<<"false"<<endl;
    }
    return 0;
}
