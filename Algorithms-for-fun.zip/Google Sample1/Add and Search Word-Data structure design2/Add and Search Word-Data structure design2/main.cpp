//
//  main.cpp
//  Add and Search Word-Data structure design2
//
//  Created by yangjingyi on 3/20/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
using namespace std;
class TreeNode
{
public:
    TreeNode(bool end=false)
    {
        isEnd=end;
    }
    unordered_map<char, TreeNode*> branches;
    bool isEnd;
};
class WordDictionary
{
public:
    TreeNode* root;
    WordDictionary()
    {
        root=new TreeNode;
    }
    ~WordDictionary()
    {
        destroy(root);
    }
    void destroy(TreeNode* node)
    {
        for(auto entry:node->branches)
        {
            destroy(entry.second);
        }
        delete node;
    }
    void addWord(string word)
    {
        TreeNode* node=root;
        int i;
        for(i=0;i<word.size();i++)
        {
            if(node->branches.find(word[i])==node->branches.end())
            {
                break;
            }
            else
            {
                node=node->branches[word[i]];
                node->isEnd=((i==word.size()-1)?true:false);
            }
        }
        for(;i<word.size();i++)
        {
            node->branches[word[i]]=new TreeNode(i==word.size()-1?true:false);
            node=node->branches[word[i]];
        }
    }
    bool search(string word)
    {
        TreeNode* node=root;
        return find(word,root)||word.size()==0;
    }
    bool find(string word, TreeNode* node)
    {
        if(word.size()!=0&&node->branches.empty())
        {
            return false;
        }
        if(word.size()==0&&node->isEnd)
        {
            return true;
        }
        if(word.size()==0&&(!node->isEnd))
        {
            return false;
        }
        bool flag=false;
        if(word[0]=='.')
        {
            for(auto it=node->branches.begin();it!=node->branches.end();it++)
            {
                flag=find(word.substr(1),it->second);
                if(flag==true)
                {
                    return true;
                    
                }
                else
                {
                    continue;
                }
            }
            return false;
        }
        else
        {
            if(node->branches.find(word[0])==node->branches.end())
            {
                   return false;
            }
            else
            {
                flag=find(word.substr(1),node->branches[word[0]]);
                return flag;
            }
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
