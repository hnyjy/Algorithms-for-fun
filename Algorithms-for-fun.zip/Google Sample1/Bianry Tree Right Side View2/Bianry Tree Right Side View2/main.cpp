//
//  main.cpp
//  Bianry Tree Right Side View2
//
//  Created by yangjingyi on 3/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    vector<int> rightSideView(TreeNode* root)
    {
        vector<int> res;
        vector<vector<int> >temp;
        int level=1;
        DFS(temp,root,level);
        for(auto t:temp)
        {
            int size=t.size()-1;
            //cout<<size<<endl;
            res.push_back(t[size]);
        }
        return res;
    }
    void DFS(vector<vector<int> >& temp, TreeNode* node,int level)
    {
        if(!node)
        {
            return;
        }
        if(level>temp.size())
        {
            temp.push_back(vector<int> ());
        }
        temp[level-1].push_back(node->val);
        if(node->left) DFS(temp,node->left, level+1);
        if(node->right) DFS(temp,node->right,level+1);
        return;
    }
};

int main(int argc, const char * argv[]) {
    TreeNode* root=new TreeNode(1);
    root->left=new TreeNode(2);
    //root->right=new TreeNode(3);
    root->left->left=new TreeNode(4);
    root->left->right=new TreeNode(5);
    Solution a;
    vector<int> out=a.rightSideView(root);
    for(int i=0;i<out.size();i++)
    {
        cout<<out[i]<<endl;
    }
    return 0;
}
