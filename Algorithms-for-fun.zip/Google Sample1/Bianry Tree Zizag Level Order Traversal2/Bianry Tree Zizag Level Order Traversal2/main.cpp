//
//  main.cpp
//  Bianry Tree Zizag Level Order Traversal2
//
//  Created by yangjingyi on 3/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    void zigzag(vector<TreeNode*>& rootv,vector<vector<int> >& result,int& level)
    {
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
