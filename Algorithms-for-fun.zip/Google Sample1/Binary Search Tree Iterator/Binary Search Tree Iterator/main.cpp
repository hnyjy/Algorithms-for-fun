//
//  main.cpp
//  Binary Search Tree Iterator
//
//  Created by yangjingyi on 3/20/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <stack>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class BSTIterator
{
    stack<TreeNode*> treeStack;
public:
    BSTIterator(TreeNode* root)
    {
        pushLeft(root);
    }
    bool hasNext()
    {
        return !treeStack.empty();
    }
    int next()
    {
        TreeNode *tmpNode=treeStack.top();
        treeStack.pop();
        pushLeft(tmpNode->right);
        return tmpNode->val;
    }
private:
    void pushLeft(TreeNode * node)
    {
        for(;node!=NULL;treeStack.push(node),node=node->left);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
