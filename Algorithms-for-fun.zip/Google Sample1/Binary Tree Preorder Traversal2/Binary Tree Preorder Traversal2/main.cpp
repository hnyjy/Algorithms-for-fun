//
//  main.cpp
//  Binary Tree Preorder Traversal2
//
//  Created by yangjingyi on 5/3/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <stack>
#include <vector>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* right;
    TreeNode* left;
    TreeNode(int x):val(x),right(NULL),left(NULL){}
};
class Solution
{
public:
    vector<int> preorderTraversal(TreeNode* root)
    {
        vector<int> res;
        if(!root)
        {
            return res;
        }
        vector<TreeNode*> stk;
        //stk.push_back(root);
        while(root||!stk.empty())
        {
            while(root)
            {
                stk.push_back(root);
                res.push_back(root->val);
                root=root->left;
            }
            root=stk.back();
            stk.pop_back();
            root=root->right;
            
            
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
