//
//  main.cpp
//  Bloomberg Phone Interview
//
//  Created by yangjingyi on 7/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <climits>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <list>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
    
};
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
    
};
class myComparison
{
public:
    bool operator()(const pair<string,int>& p1,pair<string,int>& p2) const
    {
        if(p1.first==p2.first)
        {
            return p1.second>p2.second;
        }
        return p1.first>p2.first;
    }
};
class myComparison1
{
public:
    bool operator()(const string& s1,const string& s2) const
    {
        return s1.compare(s2)>0;
    }
};
class myComparison2
{
public:
    bool operator()(const unordered_map<string, int> ::iterator & it1, const unordered_map<string,int>::iterator& it2) const
    {
        return it1->second<it2->second;
    }
};
class myComparison3
{
public:
    bool operator()(const unordered_map<int,pair<int,int> >::iterator & it1, const unordered_map<int,pair<int, int> >::iterator& it2) const
    {
        if(it1->second.second==it2->second.second)
        {
            return it1->second.first>it2->second.first;
        }
        else
        {
            return it1->second.second<it2->second.second;
        }
    }
};
class myComparison4
{
public:
    bool operator()(const int& lhs,const int& rhs) const
    {
        return lhs>rhs;
    }
};


int main(int argc, const char * argv[]) {
    vector<int> v1;
    TreeNode* in12=new TreeNode(8);
    in12->left=new TreeNode(4);
    in12->right=new TreeNode(12);
    in12->left->left=new TreeNode(2);
    in12->left->left->left=new TreeNode(1);
    in12->left->left->right=new TreeNode(3);
    
    in12->left->right=new TreeNode(6);
    in12->left->right->left=new TreeNode(5);
    in12->left->right->right=new TreeNode(7);
    in12->right->left=new TreeNode(10);
    in12->right->left->left=new TreeNode(9);
    in12->right->left->right=new TreeNode(11);
    in12->right->right=new TreeNode(13);
    ListNode* in9=new ListNode(0);
    ListNode* curr9=in9;
    for(int i=0;i<6;i++)
    {
        curr9->next=new ListNode(i+1);
        curr9=curr9->next;
    }
    curr9=in9->next;


    return 0;
}
