//
//  main.cpp
//  Bloomberg(1)
//
//  Created by yangjingyi on 5/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
#include <climits>
using namespace std;
class Solution
{
public:
    //The number before is smaller than the number later.
    int biggestdiff(vector<int> nums)
    {
        int min_val=INT_MAX;
        int max_val=INT_MIN;
        int result=INT_MIN;
        for(int i=0;i<nums.size();i++)
        {
            result=max(result,nums[i]-min_val);
            if(nums[i]<min_val)
            {
                min_val=nums[i];
                
            }
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in={5,4,10,2,9};
    Solution a;
    int out=a.biggestdiff(in);
    cout<<out<<endl;
    
    return 0;
}


