//
//  main.cpp
//  Bloomberg(10)
//
//  Created by yangjingyi on 5/24/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    TreeNode* buildBT(vector<int> prev,vector<int> inv)
    {
        return buildBT_help(prev,0, prev.size(),inv, 0,inv.size());
        
        
    }
    TreeNode* buildBT_help(vector<int>& prev,int i, int j, vector<int> inv,int ii, int jj)
    {
        if(i>=j|ii>=j)
        {
            return NULL;
            
        }
        int mid=prev[i];
        auto it=find(inv.begin()+ii,inv.begin()+jj,mid);
        int dis=it-inv.begin()-ii;
        TreeNode* root=new TreeNode(mid);
        root->left=buildBT_help(prev,i+1,i+1+dis,inv,ii,ii+dis);
        root->right=buildBT_help(prev,i+1+dis,j,inv,ii+dis+1,jj);
        return root;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
