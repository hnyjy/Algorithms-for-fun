//
//  main.cpp
//  Bloomberg(2)
//
//  Created by yangjingyi on 5/23/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
#include <climits>
using namespace std;
class Solution
{
public:
    int firstrepeat(vector<int> nums)
    {
        unordered_map<int,int> hash;
        int result=INT_MAX;
        for(int i=0;i<nums.size();i++)
        {
            
            if(hash.count(nums[i]))
            {
                return i;
            }
            else
            {
                hash[nums[i]]=i;
            }
        }
        return -1;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    vector<int> in={3,2,1,2,3,5,0,6};
    Solution a;
    int out=a.firstrepeat(in);
    cout<<out<<endl;
    return 0;
}
