//
//  main.cpp
//  Bloomberg(3)
//
//  Created by yangjingyi on 5/23/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
};
using namespace std;
class Solution
{
public:
    ListNode* mergenode(ListNode*& head1,ListNode*& head2)
    {
        ListNode* curr1=head1;
        ListNode* curr2=head2;
        int size1=0;
        int size2=0;
        int sum2=0;
        while(curr2)
        {
            sum2+=curr2->val;
            curr2=curr2->next;
            size2++;
        }
        curr2=head2;
        while(curr1)
        {
            curr1->val=curr1->val+1;
            
        }
        int tmp_sum2;
        while(curr2)
        {
            tmp_sum2+=curr2->val;
            curr2=curr2->next;
            
        }
        int diff=tmp_sum2-sum2;
        int distance=size2-diff;
        if(distance==0)
        {
            return NULL;
        }
        curr2=head2;
        while(distance)
        {
            curr2=curr2->next;
            distance--;
        }
        return curr2;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
