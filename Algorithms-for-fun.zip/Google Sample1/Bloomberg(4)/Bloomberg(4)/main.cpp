//
//  main.cpp
//  Bloomberg(4)
//
//  Created by yangjingyi on 5/23/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <map>
#include <queue>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    void printvertical(TreeNode* root)
    {
        map<int, vector<int> > printmap;
        queue<pair<int,TreeNode*> > q;
        q.push({0,root});
        while(!q.empty())
        {
            auto tmppair=q.front();
            q.pop();
            printmap[tmppair.first].push_back(tmppair.second->val);
            if(tmppair.second->left)
            {
                q.push({tmppair.first-1,tmppair.second->left});
                
            }
            if(tmppair.second->right)
            {
                q.push({tmppair.first+1,tmppair.second->right});
            }
            
        }
        
        for(auto it=printmap.begin();it!=printmap.end();it++)
        {
            for(auto num:it->second)
            {
                cout<<num<<" ";
            }
            cout<<endl;
        }
    }
};

int main(int argc, const char * argv[]) {
    TreeNode* root=new TreeNode(10);
    root->left=new TreeNode(5);
    root->right=new TreeNode(6);
    root->right->left=new TreeNode(11);
    root->right->right=new TreeNode(17);
    root->left->left=new TreeNode(7);
    root->left->right=new TreeNode(8);
    root->left->left->right=new TreeNode(15);
    root->left->left->right->right=new TreeNode(19);
    
    Solution a;
    a.printvertical(root);
    return 0;
}
