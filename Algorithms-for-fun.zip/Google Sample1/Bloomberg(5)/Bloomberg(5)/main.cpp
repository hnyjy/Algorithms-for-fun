//
//  main.cpp
//  Bloomberg(5)
//
//  Created by yangjingyi on 5/23/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <climits>
#include <vector>
using namespace std;
class Solution
{
public:
    bool findx(vector<int> nums,int target)
    {
        int mid=findmid(nums);
        int left1=0;
        int right1=mid;
        int left2=mid;
        int right2=nums.size()-1;
        if(target==nums[mid])
        {
            return true;
        }
        
        while(right1>left1)
        {
            mid=left1+(right1-left1)/2;
            if(target<nums[mid])
            {
                right1=mid;
            }
            else if(target>nums[mid])
            {
                

                left1=mid+1;
            }
            else if(target==nums[mid])
            {
                return true;
            }
            else
            {
                continue;
            }
        }
        if(nums[left1==target])
        {
            return true;
        }
        
        while(right2>left2)
        {
            mid=left2+(right2-left2)/2;
            if(target<nums[mid])
            {
                right2=mid;
            }
            else if(target>nums[mid])
            {
                left2=mid+1;
            }
            else if(target==nums[mid])
            {
                return true;
            }
            else
            {
                continue;
            }
            
        }
        if(nums[left2]==target)
        {
            return true;
        }
        return false;
    }
    
    int findmid(vector<int> nums)
    {
        int left=0;
        int right=nums.size()-1;
        int mid=0;
        while(right>left)
        {
            mid=left+(right-left)/2;
            if(nums[mid-1]<nums[mid]&&nums[mid+1]>nums[mid])
            {
                left=mid;
            }
            else if(nums[mid-1]>nums[mid]&&nums[mid+1]<nums[mid])
            {
                right=mid;
            }
            else if(nums[mid-1]<nums[mid]&&nums[mid+1]<nums[mid])
            {
                return mid;
            }
            else
            {
                continue;
            }
        }
        return mid;
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in={1,3,5,17,11,9,8,6,4,2,0};
    Solution a;
    int out1=a.findmid(in);
    bool out2=a.findx(in,11);
    if(out2)
    {
        cout<<"right"<<endl;
    }
    else
    {
        cout<<"wrong"<<endl;
        
    }
    cout<<out1<<endl;
    return 0;
}
