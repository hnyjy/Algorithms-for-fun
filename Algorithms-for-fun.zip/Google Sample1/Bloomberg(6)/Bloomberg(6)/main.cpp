//
//  main.cpp
//  Bloomberg(6)
//
//  Created by yangjingyi on 5/23/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;
class Solution
{
public:
    double power_recursive(int x,int y)
    {
        double result=1;
        //bool flag1=x>=0?true:false;
        bool flag2=y>=0?true:false;
        //x=abs(x);
        y=abs(y);
        //result=power_help(x,y);
        if(y==0)
        {
            return 1;
        }
        
        if(y%2!=0)
        {
            result=power_recursive(x,y/2);
            result=x*result*result;
        }
        else
        {
            result=power_recursive(x,y/2);
            result=result*result;
        }
        if(!flag2)
        {
            result=1/result;
        }
        return result;
    }
    double power_iterative(int x,int y)
    {
        double result=1;
        bool flag=y>=0?true:false;
        y=abs(y);
        while(y>0)
        {
            if(y%2!=0)
            {
                result=result*x;
                
            }
            x=x*x;
            y=y/2;
            
        }
        if(!flag)
        {
            result=1/result;
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    Solution a;
    double out1=a.power_recursive(2,-5);
    double out2=a.power_iterative(-3, -5);
    cout<<out1<<endl;
    cout<<out2<<endl;
    return 0;
}
