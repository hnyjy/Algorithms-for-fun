//
//  main.cpp
//  Bloomberg(7)
//
//  Created by yangjingyi on 5/23/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
#include <vector>

using namespace std;
class record
{
public:
    string website;
    long time;
};
struct newtime
{
    bool operator()(const record& new1,const record& new2)const
    {
        return new1.time>new2.time;
    }
};

class recentwebsite
{
public:
    vector<record> v;
    priority_queue<record,newtime> q;
        void visit(record new_record)
    {
        for(auto it=v.begin();it!=v.end();it++)
        {
            if(it->website==new_record.website)
            {
                v.erase(it);
                v.push_back(new_record);
                return;
            }
        }
        v.push_back(new_record);
        while(v.size()>10)
        {
            v.erase(v.begin());
        }
        
        return;
            
    }
    void visit1(record new_record)
    {
        
        q.push_back(new_record);
        while(q.size()>10)
        {
            q.pop();
        }
        return;
    }
    
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
