//
//  main.cpp
//  Bloomberg(8)
//
//  Created by yangjingyi on 5/23/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <vector>
#include <climits>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    bool BST(TreeNode* root)
    {
        if(!root)
        {
            return true;
        }
        return BST_help(root,INT_MIN,INT_MAX);
    }
    bool BST_help(TreeNode* root, int min_val,int max_val)
    {
        if(!root)
        {
            return true;
        }
        if(root->val>=max_val||root->val<=min_val)
        {
            return false;
        }
        return BST_help(root->left,min_val,root->val)&&BST_help(root->right,root->val,max_val);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
