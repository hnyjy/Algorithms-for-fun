//
//  main.cpp
//  Bloomberg(9)
//
//  Created by yangjingyi on 5/23/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <stack>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    int secondbiggestnode(TreeNode* root)
    {
        vector<int> res;
        stack<TreeNode*> stk;
        while(root||(!stk.empty()))
        {
            while(root)
            {
                stk.push(root);
                root=root->right;
            }
            root=stk.top();
            stk.pop();
            res.push_back(root->val);
            if(res.size()==2)
            {
                return res.back();
            }
            root=root->left;
        }
        return res.back();
            
        
    }
    int secondbiggestnode2(TreeNode* root)
    {
        TreeNode* pre;
        TreeNode* curr=largestnode(root,pre);
        if(curr->left)
        {
            
            TreeNode* tmp1;
            TreeNode* tmp=largestnode(curr->left,tmp1);
            return tmp->val;
        }
        //cout<<"right"<<endl;
        return pre->val;
        
    }
    TreeNode* largestnode(TreeNode* root,TreeNode*& pre)
    {
        TreeNode* tmp=root;
        while(tmp->right)
        {
            //cout<<"right2"<<endl;
            pre=tmp;
            tmp=tmp->right;
        }
        //cout<<tmp->val<<endl;
        //cout<<pre->val<<endl;
        return tmp;
    }
};

int main(int argc, const char * argv[]) {
    TreeNode* root=new TreeNode(7);
    root->left=new TreeNode(5);
    root->left->left=new TreeNode(3);
    root->left->right=new TreeNode(6);
    root->left->left->left=new TreeNode(2);
    root->left->left->right=new TreeNode(4);
    root->right=new TreeNode(10);
    root->right->left=new TreeNode(8);
    root->right->right=new TreeNode(14);
    root->right->right->left=new TreeNode(12);
    root->right->right->right=new TreeNode(16);
    root->right->right->right->left=new TreeNode(15);
    root->right->right->left->left= new TreeNode(11);
    root->right->right->left->right=new TreeNode(13);
    Solution a;
    int out=a.secondbiggestnode2(root);
    cout<<out<<endl;
    return 0;
}
