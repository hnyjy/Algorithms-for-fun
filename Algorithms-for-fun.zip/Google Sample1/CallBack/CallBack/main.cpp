//
//  main.cpp
//  CallBack
//
//  Created by yangjingyi on 8/7/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
#include <mutex>
using namespace std;
class CallBack
{
private:
    //mutex mut;
    bool isFired;
    queue<CallBack> qcb;
public:
    void register(CallBack cb)
    {
        if(!isFired)
        {
            qcb.push(cb);
            
        }
        else
        {
            cb.invoke();
        }
    }
    void fire()
    {
        isFired=true;
        while(qcb.size())
        {
            CallBack tmp=qcb.front();
            tmp.invoke();
            qcb.pop();
        }
    }
};
class CallBack1
{
private:
    mutex mut;
    bool isFired;
    queue<CallBack> qcb;
public:
    void register(CallBack cb)
    {
        lock(mut);
        if(!isFired)
        {
            qcb.push(cb);
            unlock(mut);
        }
        else
        {
            unlock(mut);
            cb.invoke();
            
        }
    }
    void fire()
    {
        lock(mut);
        
        while(qcb.size())
        {
            CallBack tmp=qcb.front();
            unlock(mut);
            tmp.invoke();
            qcb.pop();
            lock(mut);
        }
        isFired=true;
        unlock(mut);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
