//
//  main.cpp
//  Count Numbers with Unique Digits
//
//  Created by yangjingyi on 7/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
class Solution
{
public:
    int countNumbersWithUniqueDigits(int n)
    {
        int sum=1;
        if(n>0)
        {
            int end=(n>10)?10:n;
            for(int i=0;i<end;i++)
            {
                sum+=9*permutation(9,i);
            }
        }
        return sum;
    }
    int permutation (int n,int r)
    {
        if(r==0)
        {
            return 1;
        }
        else
        {
            return n*permutation(n-1,r-1);
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
