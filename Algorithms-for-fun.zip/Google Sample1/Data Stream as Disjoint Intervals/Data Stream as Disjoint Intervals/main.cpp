//
//  main.cpp
//  Data Stream as Disjoint Intervals
//
//  Created by yangjingyi on 7/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
struct Interval
{
    int start;
    int end;
    Interval():start(0),end(0){}
    Interval(int s, int e):start(s),end(e){}
};
class SummaryRanges
{
    vector<Interval> record;
public:
    SummaryRanges()
    {
        
    }
    void addNum(int val)
    {
        auto cmp=[](Interval a, Interval b)
        {
            return a.start<b.start;
            
        };
        auto it=lower_bound(vec.begin(),vec.end(),Interval(val,val),cmp);
        int start=val,end=val;
        if(it!=vec.begin()&&(it-1)->end+1>=val)
        {
            it--;
        }
        while(it!=vec.end()&&val+1>=it->start&&val-1<=it->end)
        {
            start=min(start,it->start);
            end=max(end,it->end);
            it=vec.erase(it);
        }
        vec.insert(it,Interval(start,end));
        
    }
    vector<Interval> getIntervals()
    {
        return vec;
    }
private:
    vector<Interval> vec;
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
