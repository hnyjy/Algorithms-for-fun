//
//  main.cpp
//  Design Hit Counter
//
//  Created by yangjingyi on 7/7/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
using namespace std;
class HitCounter
{
    queue<pair<int,int> > q;
    int res=0;
public:
    void hit(int timestamp)
    {
        res++;
        if(!q.empty()&&q.back().first==timestamp)
        {
            q.back().second++;
            return;
        }
        while(!q.empty()&&timestamp-q.front().first>=300)
        {
            res-=q.front().second;
            q.pop();
        }
        q.push({timestamp,1});
    }
    int getHits(int timestamp)
    {
        while(!q.empty()&&timestamp-q.front().first>=300)
        {
            res-=q.front().second;
            q.pop();
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    HitCounter in;
    in.hit(1);
    in.hit(2);
    in.hit(3);
    cout<<in.getHits(4)<<endl;
    in.hit(300);
    cout<<in.getHits(300)<<endl;
    cout<<in.getHits(301)<<endl;
    return 0;
}
