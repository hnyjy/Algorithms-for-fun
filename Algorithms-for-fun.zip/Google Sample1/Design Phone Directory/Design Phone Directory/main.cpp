//
//  main.cpp
//  Design Phone Directory
//
//  Created by yangjingyi on 8/9/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class PhoneDirectory
{
private:
    vector<int> dict;
    vector<bool> used;
    int upbnd, fnt, rear;
public:
    PhoneDirectory(int maxNumbers)
    {
        upbnd=maxNumbers-1;
        used.resize(maxNumbers+1,false);
        dict.resize(maxNumbers+1);
        fnt=rear=0;
        for(int i=0;i<maxNumbers;i++)
        {
            dict[rear++]=i;
        }
        
    }
    int get()
    {
        if(fnt>=rear)
        {
            return -1;
        }
        int res=dict[fnt++];
        used[res]=true;
        return res;
    }
    bool check(int number)
    {
        if(number<0||number>upbnd)
        {
            return false;
        }
        return !used[number];
    }
    void release(int number)
    {
        if(number>=0&&number<=upbnd&&used[number]==true)
        {
            used[number]=false;
            dict[--fnt]=number;
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
