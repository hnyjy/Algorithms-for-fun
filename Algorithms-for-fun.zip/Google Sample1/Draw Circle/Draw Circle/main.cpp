//
//  main.cpp
//  Draw Circle
//
//  Created by yangjingyi on 8/8/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct pixelPoint
{
    int x;
    int y;
    pixelPoint(int a,int b):x(a),y(b){}
};
class Solution
{
    void drawCircle(int x1,int y1, int r)
    /* 求的八分之一圆孤为(0, R) -(R√2,R√2)，可知最大位移方向是x方向，x0 = 0, y0 = R，每次对x自增，然后判断y是否减1，直到x >= y为止(从点(0, R)到圆的八分之一处就有这种情况)。误差量由Ｆ(x, y) = x^2 + y^2 - R^2给出。
    先找递推关系，若当前d = F(x + 1, y - 0.5) > 0，则y须减1，则下一d值为
    d =  F(x + 2, y - 1.5) = (x + 2)^2 + (y - 1.5)^2 - R^2 = (x + 1)^2 + (x - 0.5)^2 - R^2 + 2x + 3 - 2y + 2 = d + 2x - 2y + 5，若当前d = F(x + 1, y - 0.5) < 0，则y不变，只有x增1，则下一d值为d = F(x + 2, y - 0.5) = d + 2x + 3。
    d的初值，d0 = F(1, R - 0.5) = 1.25 - R，则可以对d - 0.25进行判断，因为递推关系中只有整数运算，所以d - 0.25 > 0即d > 0.25，这和d > 0等价，所以d取初值1 - R*/
    
    /*symmetry*/
    
    {
        int x=0,y=r;
        int d=1-r;
        while(y>x)
        {
            (x1+x,y1+y);
            (x1+y,y1+x);
            (x1-x,y1+y);
            (x1-x,y1-y);
            (x1+x,y1-y);
            (x1+y,y1-x);
            (x1-y,y1+x);
            (x1-y,y1-x);
            if(d<0)
            {
                d=d+2*x+3;
            }
            else
            {
                d=d+2*(x-y)+5;
                y--;
            }
            x++;
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
