//
//  main.cpp
//  Evaluate Reverse Polish Notation2
//
//  Created by yangjingyi on 4/12/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <stack>
using namespace std;
class Solution
{
public:
    int evalRPN(vector<string>& tokens)
    {
        stack<int> st;
        for(int i=0;i<tokens.size();i++)
        {
            if(tokens[i]=="*"||tokens[i]=="/"||tokens[i]=="+"||tokens[i]=="-")
            {
                int x=st.top();
                st.pop();
                int y=st.top();
                st.pop();
                if(tokens[i]=="*")
                {
                    st.push(x*y);
                }
                if(tokens[i]=="/")
                {
                    st.push(y/x);
                
                }
                if(tokens[i]=="+")
                {
                    st.push(x+y);
                }
                if(tokens[i]=="-")
                {
                    st.push(y-x);
                }
            }
            else
            {
                st.push(atoi(tokens[i].c_str()));
            }
        }
        return st.top();
        
    }
};

int main(int argc, const char * argv[]) {
    vector<string> in={{"0"},{"3"},{"/"}};
    Solution a;
    int out=a.evalRPN(in);
    cout<<out<<endl;
    return 0;
}
