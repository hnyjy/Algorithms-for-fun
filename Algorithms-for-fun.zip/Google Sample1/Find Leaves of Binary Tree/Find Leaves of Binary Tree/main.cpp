//
//  main.cpp
//  Find Leaves of Binary Tree
//
//  Created by yangjingyi on 7/4/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <climits>
#include <algorithm>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    vector<vector<int> > findLeaves(TreeNode* root)
    {
        vector<vector<int> > res;
        int level=INT_MIN;
        help(root,res,level);
        return res;
    }
    int help(TreeNode* root, vector<vector<int> >& res,int& maxlevel)
    {
        if(!root)
        {
            
            return -1;
        }
        if(root&&!root->left&&!root->right)
        {
            //cout<<"right"<<endl;
            if(res.size()==0)
            {
                vector<int> tmp;
                res.push_back(tmp);
            }
            res[0].push_back(root->val);
            cout<<root->val<<"="<<"0"<<endl;
            return 0;
        }
        else
        {
            int level=1+max(help(root->left,res,maxlevel),help(root->right,res,maxlevel));
            
            if(level>=maxlevel)
            {
                maxlevel=level;
                
            }
            cout<<root->val<<"="<<level<<endl;
            //cout<<res.size()<<endl;
            res.resize(maxlevel+1);
            cout<<"level="<<level<<endl;
            res[level].push_back(root->val);
            cout<<"element="<<res[level][0]<<endl;
            return level;
        }
    }
};

int main(int argc, const char * argv[]) {
    TreeNode* root=new TreeNode(1);
    root->left=new TreeNode(2);
    root->right=new TreeNode(3);
    root->right->left=new TreeNode(6);
    root->right->left->right=new TreeNode(9);
    root->right->right=new TreeNode(7);
    root->left->left=new TreeNode(4);
    root->left->left->right=new TreeNode(8);
    root->left->right=new TreeNode(5);
    Solution sol;
    vector<vector<int> >out=sol.findLeaves(root);
    //cout<<out.size()<<endl;
    //cout<<"out[2][0]="<<out[2][0]<<endl;
    for(int i=0;i<out.size();i++)
    {
        //cout<<"i="<<i<<endl;
        for(int j=0;j<out[i].size();j++)
        {
            cout<<out[i][j]<<" ";
        }
        cout<<endl;
    }
    return 0;
}
