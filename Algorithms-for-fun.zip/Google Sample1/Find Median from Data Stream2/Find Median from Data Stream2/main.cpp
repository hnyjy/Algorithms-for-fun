//
//  main.cpp
//  Find Median from Data Stream2
//
//  Created by yangjingyi on 3/20/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
using namespace std;
class MedianFinder
{
    priority_queue<long> small, large;
    void addNum(int num)
    {
        small.push(num);
        large.push(-small.top());
        small.pop();
        if(small.size()<large.size())
        {
            small.push(-large.top());
            large.pop();
        }
    }
    double findMedian()
    {
        return small.size()>large.size()?small.top():(small.top()-large.top())/2.0;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
