//
//  main.cpp
//  Find the Celebrity
//
//  Created by yangjingyi on 7/26/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
bool knows(int i,int j);
class Solution
{
public:
    int findCelebrity(int n)
    {
        for(int i=0,j=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                if(i!=j&&knows(i,j))
                {
                    break;
                }
                if(i!=j&&knows(j,i))
                {
                    break;
                }
            }
            if(j==n)
            {
                return i;
            }
        }
        return -1;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
