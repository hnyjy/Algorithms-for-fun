//
//  main.cpp
//  Four Way Stop
//
//  Created by yangjingyi on 4/24/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
#include <algorithm>
#include <vector>
using namespace std;
struct Car
{

    int arrival_time;
    int laneid;
    
};
struct Lane
{
    queue<Car> arrive_car;
    int laneid;
    Lane()
    {};
};
class Solution
{
public:
    queue<Car> cars;
    vector<Lane> lanes;
    
    void arriveCar(Car car,Lane lane)
    {
        lanes.resize(4);
        lane.arrive_car.push(car);
        cars.push(car);
        
    }
    Car getNextCar()
    {
        Car next_car=cars.front();
        
        cars.pop();
        lanes[next_car.laneid].arrive_car.pop();
        return next_car;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
