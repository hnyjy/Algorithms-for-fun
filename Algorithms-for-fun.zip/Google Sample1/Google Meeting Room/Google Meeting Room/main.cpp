//
//  main.cpp
//  Google Meeting Room
//
//  Created by yangjingyi on 4/24/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
#include <algorithm>
using namespace std;
struct Interval
{
    int start;
    int end;
    Interval():start(),end(){}
    Interval(int a, int b):start(a),end(b){}
};
class Solution
{
public:
    static bool comp(const Interval& a, Interval& b)
    {
        return a.start<b.start;
    }
    int maxtime(vector<Interval>& in)
    {
        sort(in.begin(),in.end(),comp);
        vector<Interval> res;
        res.push_back(in[0]);
        int result=INT_MIN;
        for(int i=1;i<in.size();i++)
        {
            if(in[i].start<=res.back().end)
            {
                
                Interval tmp(res.back().start,max(in[i].end,res.back().end));
                res.pop_back();
                res.push_back(tmp);
                result=max(result,res.back().end-res.back().start);
                
                                       
            }
            else
            {
                res.push_back(in[i]);
            }
        }
        return result;
    }
};
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
