//
//  main.cpp
//  Google Phone Interview
//
//  Created by yangjingyi on 4/27/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
#include <stack>
#include <queue>
#include <set>

using namespace std;
class Solution
{
    
};
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
