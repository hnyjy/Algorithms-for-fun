//
//  main.cpp
//  Google Phone Interview2
//
//  Created by yangjingyi on 5/6/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>
#include <stack>
#include <queue>
#include <set>
#include <unordered_map>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),right(NULL),left(NULL){}
};
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
};
class Solution
{
public:
    ListNode* reversenode(ListNode* head, int n, int k)
    {
        int s=n/k;
        int last=n-k*s;
        ListNode* fhead=new ListNode(0);
        fhead->next=head;
        ListNode* curr=head;
        ListNode* pre=head;
        ListNode* lastn=fhead;
        ListNode* headn=fhead->next;
        //cout<<"s="<<s<<endl;
        for(int i=0;i<s;i++)
        {
            for(int j=0;j<k;j++)
            {
                curr=curr->next;
            }
            ListNode* tmpc=curr;
            cout<<"tmpc's val="<<tmpc->val<<endl;
            for(int h=0;h<k-1;h++)
            {
                ListNode* tmpn=pre->next->next;
                ListNode* tmpp=pre->next;
                lastn->next=tmpp;
                tmpp->next=headn;
                headn=tmpp;
                pre->next=tmpn;
                
            }
            lastn=pre;
            cout<<"lastn'val="<<lastn->val<<endl;
            pre->next=tmpc;
            pre=pre->next;
            headn=pre;
            cout<<"pre'val="<<pre->val<<endl;
        }
        return fhead->next;
    }
    
};

int main(int argc, const char * argv[]) {
    ListNode* head=new ListNode(1);
    ListNode* curr=head;
    for(int i=2;i<11;i++)
    
    {
        curr->next=new ListNode(i);
        curr=curr->next;
        
    }
    curr=head;
    /*while(curr)
    {
        cout<<curr->val<<endl;
        curr=curr->next;
    }*/
    Solution a;
    ListNode* out=a.reversenode(head,10,3);
    curr=out;
    while(curr)
    {
        cout<<curr->val<<endl;
        curr=curr->next;
    }
    
    
    
    return 0;
}
