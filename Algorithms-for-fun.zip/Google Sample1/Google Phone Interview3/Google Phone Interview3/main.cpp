//
//  main.cpp
//  Google Phone Interview3
//
//  Created by yangjingyi on 5/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
#include <queue>
#include <stack>
using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
};
class Solution
{
public:
    ListNode* reversenode(ListNode* head, int list_size, int k)
    {
        int loop_size=list_size/k;
        ListNode* fhead=new ListNode(0);
        fhead->next=head;
        ListNode* curr=fhead;
        ListNode* pre=head;
        ListNode* last_head=fhead;
        ListNode* this_head=head;
        stack<ListNode*> stk;
        for(int i=0;i<loop_size;i++)
        {
            for(int j=0;j<k;j++)
            {
                stk.push(pre);
                pre=pre->next;
                
            }
            for(int p=0;p<k;p++)
            {
                last_head->next=stk.top();
                stk.pop();
                last_head=last_head->next;
            }
        
        }
        last_head->next=pre;
        return fhead->next;
    }
};

int main(int argc, const char * argv[]) {
    ListNode* head=new ListNode(1);
    ListNode* curr=head;
    for(int i=2;i<11;i++)
        
    {
        curr->next=new ListNode(i);
        curr=curr->next;
        
    }
    curr=head;
    /*while(curr)
     {
     cout<<curr->val<<endl;
     curr=curr->next;
     }*/
    Solution a;
    ListNode* out=a.reversenode(head,10,3);
    curr=out;
    while(curr)
    {
        cout<<curr->val<<endl;
        curr=curr->next;
    }

    return 0;
}
