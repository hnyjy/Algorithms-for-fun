//
//  main.cpp
//  Google Sample1
//
//  Created by yangjingyi on 3/7/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
#include <climits>
#include <stack>
using namespace std;
int solution(int x)
{
    string input=to_string(x);
    int pre=INT_MIN;
    int cur=INT_MIN;
    stack<int> point;
    for(int i=0;i<input.size();i++)
    {
        if(i<input.size()-1)
        {
            if(input[i]==input[i+1])
            {
                if(point.empty())
                {
                    point.push(i);
                }
                else if(input[i]<=input[point.top()])
                {
                    point.pop();
                    point.push(i);
                }
                else
                {
                    break;
                }
            }
            else
            {
                continue;
            }
        }
        else
        {
            if(input[i]==input[i-1])
            {
                if(point.empty())
                {
                    point.push(i);
                }
                else if(input[i]<=input[point.top()])
                {
                    point.pop();
                    point.push(i);
                }
                else
                {
                    break;
                }
            }
            else
            {
                continue;
                
            }
        }
    }
    //cout<<point.top()<<endl;
    string result=input.substr(0,point.top())+input.substr(point.top()+1);
    return atoi(result.c_str());
}

int main(int argc, const char * argv[]) {
    int in=221336;
    int out=solution(in);
    cout<<out<<endl;
    return 0;
}
