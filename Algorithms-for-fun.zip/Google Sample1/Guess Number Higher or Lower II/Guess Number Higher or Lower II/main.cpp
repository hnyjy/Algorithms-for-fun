//
//  main.cpp
//  Guess Number Higher or Lower II
//
//  Created by yangjingyi on 7/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <climits>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int getMoneyAmount(int n)
    {
        vector<vector<int> > dp(n+2,vector<int>(n+2,0));
        for(int i=1;i<=n;i++)
        {
            for(int j=i-1;j>=1;j--)
            {
                int min_value=INT_MAX;
                for(int k=j;k<=i;k++)
                {
                    int tmp=k+max(dp[j][k-1],dp[k+1][i]);
                    min_value=min(min_value,tmp);
                }
                dp[j][i]=min_value;
            }
            
        }
        return dp[1][n];
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
