//
//  main.cpp
//  Guess Number Higher or Lower
//
//  Created by yangjingyi on 7/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    int guessNumber(int n)
    {
        int low=1;
        while(low<=n)
        {
            int mid=low+(n-low)/2;
            int res=guess(mid);
            if(res==0)
            {
                return mid;
            }
            else if(res==-1)
            {
                n=mid-1;
            }
            else
            {
                low=mid+1;
            }
        }
        return -1;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
