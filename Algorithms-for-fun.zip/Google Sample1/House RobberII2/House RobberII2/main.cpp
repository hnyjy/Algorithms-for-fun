//
//  main.cpp
//  House RobberII2
//
//  Created by yangjingyi on 4/18/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int rob(vector<int>& nums)
    {
        int n=nums.size();
        if(n<2)
        {
            return n?nums[0]:0;
        }
        return max(robber(nums,1,n-1),robber(nums,0,n-2));
    }
    int robber(vector<int>& nums, int l, int r)
    {
        vector<int> dp(r-l+4,0);
        for(int i=3;i<r-l+4;i++)
        {
            dp[i]=max(max(dp[i-3]+nums[l+i-3],dp[i-2]+nums[l+i-3]),dp[i-1]);
            //cout<<"right"<<endl;
        }
        return dp[r-l+3];
    }
};
int main(int argc, const char * argv[]) {
    vector<int> in={9,5,1,8,2,3};
    Solution a;
    int out=a.rob(in);
    cout<<out<<endl;
    return 0;
}
