//
//  main.cpp
//  Implement Queue using Stacks2
//
//  Created by yangjingyi on 3/20/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <stack>
using namespace std;
class Queue
{
public:
    stack<int> input,output;
    void push(int x)
    {
        input.push(x);
    }
    void pop()
    {
        peek();
        output.pop();
    }
    int peek()
    {
        if(output.empty())
        {
            while(input.size())
            {
                output.push(input.top());
                input.pop();
            }
        }
        return output.top();
    }
    bool empty()
    {
        return input.empty()&&output.empty();
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
