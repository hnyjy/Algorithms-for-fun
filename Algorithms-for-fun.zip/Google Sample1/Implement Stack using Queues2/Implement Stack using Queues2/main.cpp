//
//  main.cpp
//  Implement Stack using Queues2
//
//  Created by yangjingyi on 3/20/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
using namespace std;
class Stack
{
public:
    queue<int> q1,q2;
    void push(int x)
    {
        q1.push(x);
    }
    void pop()
    {
        while(q1.size()-1>0)
        {
            q2.push(q1.front());
            q1.pop();
        }
        q1.pop();
        q1=q2;
        while(q2.size())
        {
            q2.pop();
        }

    }
    int top()
    {
        while(q1.size()-1>0)
        {
            q2.push(q1.front());
            q1.pop();
        }
        return q1.front();
        q2.push(q1.front());
        q1.pop();
        q1=q2;
        while(q2.size())
        {
            q2.pop();
        }
    }
    bool empty()
    {
        return q1.empty();
    }
    
};
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
