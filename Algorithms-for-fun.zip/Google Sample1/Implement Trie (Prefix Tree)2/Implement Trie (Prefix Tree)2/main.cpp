//
//  main.cpp
//  Implement Trie (Prefix Tree)2
//
//  Created by yangjingyi on 6/30/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
using namespace std;
class TrieNode
{
public:
    TrieNode(char x)
    {
        val=x;
        isend=false;
    }
    TrieNode()
    {
        isend=false;
    }
    char val;
    unordered_map<char,TrieNode*> children;
    bool isend;

};
class Trie
{
public:
    Trie()
    {
        root=new TrieNode();
    }
    void insert(string word)
    {
        TrieNode* curr=root;
        for(int i=0;i<word.size();i++)
        {
            if(curr->children.count(word[i]))
            {
                curr=curr->children[word[i]];
            }
            else
            {
                TrieNode* tmp=new TrieNode(word[i]);
                curr->children[word[i]]=tmp;
                curr=tmp;
            }
        }
        curr->isend=true;
        
    }
    bool search(string word)
    {
        TrieNode* p=find(word);
        return p!=NULL&&p->isend;
    }
    bool startsWith(string prefix)
    {
        return find(prefix)!=NULL;
    }
    TrieNode* find(string s)
    {
        TrieNode* p=root;
        for(int i=0;i<s.size()&&p!=NULL;i++)
        {
            if(!p->children.count(s[i]))
            {
                p=NULL;
                break;
            }
            else
            {
                p=p->children[s[i]];
            }
            
        }
        return p;
    }
private:
    TrieNode* root;
    

};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
