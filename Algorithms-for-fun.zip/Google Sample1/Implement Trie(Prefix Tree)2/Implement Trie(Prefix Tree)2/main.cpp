//
//  main.cpp
//  Implement Trie(Prefix Tree)2
//
//  Created by yangjingyi on 3/20/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <set>
#include <unordered_map>
using namespace std;
class TrieNode
{
public:
    char val;
    vector<TrieNode*> branches;
    bool isWord;
    TrieNode()
    {
        val=' ';
        isWord=false;
        
    }
    TrieNode(char x)
    {
        val=x;
        isWord=false;
    }
    TrieNode* find(char x)
    {
        if(!branches.empty())
        {
            for(auto branch:branches)
            {
                if(branch->val==x)
                {
                    return branch;
                }
            }
        }
        return NULL;
    }
    
    
};
class Trie
{
public:
    
    Trie()
    {
        root=new TrieNode();
    }
    void insert(string word)
    {
        for(int i=0;i<word.size();i++)
        {
            if(search(word))
            {
                return;
            }
            TrieNode* curr=root;
            for(auto ch:word)
            {
                TrieNode* branch=curr->find(ch);
                if(branch)
                {
                    curr=branch;
                }
                else
                {
                    TrieNode* newnode=new TrieNode(ch);
                    curr->branches.push_back(newnode);
                    curr=newnode;
                }
            }
            curr->isWord=true;
        }
    }
    bool search(string s)
    {
        TrieNode* curr=root;
        for(auto ch:s)
        {
            curr=curr->find(ch);
            if(!curr)
            {
                return false;
            }
        }
        return curr->isWord==true;
    }
    bool startsWith(string prefix)
    {
        TrieNode* curr=root;
        for(auto ch:prefix)
        {
            curr=curr->find(ch);
            if(!curr)
            {
                return false;
            }
            else
            {
                continue;
            }
        }
        return true;
    }
private:
    TrieNode* root;
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
