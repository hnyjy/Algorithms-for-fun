//
//  main.cpp
//  Insert Delete GetRandom O(1) - Duplicates allowed
//
//  Created by yangjingyi on 8/9/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
#include <unordered_set>
#include <sstream>
using namespace std;
class RandomizedCollection
{
private:
    vector<int> vec;
    unordered_map<int,unordered_set<int> > hash;
public:
    RandomizedCollection()
    {
        
    }
    bool insert(int val)
    {
        
            hash[val].insert(vec.size());
            vec.push_back(val);
            return hash[val].size()==1;
    }
    bool remove(int val)
    {
        if(!hash.count(val))
        {
            return false;
        }
        else
        {
            int last=vec.back();
            auto it=hash[val].begin();
            vec[*it]=last;
            hash[last].erase(vec.size()-1);
            hash[last].insert(*it);
            vec.pop_back();
            hash[val].erase(it);
            if(hash[val].size()==0)
            {
                hash.erase(val);
            }
            
            return true;
        }
            }
    int getRandom()
    {
        return vec[rand()%vec.size()];
    }
    
};

int main(int argc, const char * argv[]) {
//    RandomizedCollection rc;
//    rc.insert(-1);
//    rc.remove(-2);
//    rc.insert(-2);
//    cout<<rc.getRandom()<<endl;
//    rc.remove(-1);
//    rc.insert(-2);
//    cout<<rc.getRandom()<<endl;
    stringstream ss("1.1837 1.3829 0.6102");
    string quote;
    while(ss>>quote)
    {
        cout<<quote<<endl;
    }

    return 0;
}
