//
//  main.cpp
//  Insert Delete GetRandom O(1)
//
//  Created by yangjingyi on 8/9/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;
class RandomizedSet
{
private:
    unordered_map<int,int> hash;
    vector<int> vec;
public:
    RandomizedSet()
    {
        
    }
    bool insert(int val)
    {
        if(!hash.count(val))
        {
            hash[val]=vec.size();
            vec.push_back(val);
            return true;
        }
        else
        {
            return false;
        }
    }
    bool remove(int val)
    {
        if(!hash.count(val))
        {
            return false;
        }
        int last=vec.back();
        hash[last]=hash[val];
        vec[hash[val]]=last;
        hash.erase(val);
        vec.pop_back();
        return true;
        
    }
    int getRandom()
    {
        return vec[rand()%vec.size()];
    }
    
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
