//
//  main.cpp
//  Integer Break
//
//  Created by yangjingyi on 5/3/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    long long integerBreak(long long n)
    {
        if(n==2)
        {
            return 1;
        }
        if(n==3)
        {
            return 2;
        }
        if(n==4)
        {
            return 4;
        }
        if(n==5)
        {
            return 6;
        }
        if(n==6)
        {
            return 9;
        }
        return 3*integerBreak(n-3);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
