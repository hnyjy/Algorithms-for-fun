//
//  main.cpp
//  Interview
//
//  Created by yangjingyi on 6/1/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>

Node* findparent(Node* a, Node* b)
{
    
    unordered_map<Node*, vector<Node*> > hash;
    Node* curr=a;
    while(curr)
    {
        hash[a].push_back(curr);
        curr=curr->parent;
    }
    curr=b;
    while(curr)
    {
        hash[b].push_back(curr);
        curr=curr->parent;
    }
    for(int i=0;i<hash[a].size();i++)
    {
        for(int j=0;j<hash[b].size();j++)
        {
            if(hash[a][i]==hash[b][j])
            {
                return hash[a][i];
            }
        }
    }
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
