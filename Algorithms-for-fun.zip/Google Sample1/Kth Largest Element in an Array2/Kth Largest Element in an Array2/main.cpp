//
//  main.cpp
//  Kth Largest Element in an Array2
//
//  Created by yangjingyi on 6/30/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int partition(vector<int>& nums, int left, int right)
    {
        int pivot=nums[left];
        int l=left+1;
        int r=right;
        while(l<=r)
        {
            if(nums[l]<pivot&&nums[r]>pivot)
            {
                swap(nums[l++],nums[r++]);
            }
            if(nums[l]>=pivot)
            {
                l++;
            }
            if(nums[r]<=pivot)
            {
                r--;
            }
        }
        swap(nums[left],nums[r]);
        return r;
    }
    int findKthLargest(vector<int>& nums, int k)
    {
        int left=0, right=nums.size()-1;
        while(true)
        {
            int pos=partition(nums,left,right);
            if(pos==k-1)
            {
                return nums[pos];
            }
            if(pos>k-1)
            {
                right=pos-1;
            }
            else
            {
                left=pos+1;
            }
        }
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in1={4,6,2,4,9,14,7,8,1,3,2,6};
    Solution sol;
    int out1=sol.partition(in1, 0, in1.size()-1);
    cout<<out1<<endl;
    cout<<"vector"<<endl;
    for(auto n:in1)
    {
        cout<<n<<" ";
    }
    return 0;
}
