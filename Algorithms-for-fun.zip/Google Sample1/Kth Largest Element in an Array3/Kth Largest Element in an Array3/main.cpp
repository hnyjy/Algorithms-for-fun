//
//  main.cpp
//  Kth Largest Element in an Array3
//
//  Created by yangjingyi on 6/30/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    inline int left(int idx)
    {
        return (idx<<1)+1;
    }
    inline int right(int idx)
    {
        return (idx<<1)+2;
    }
    void max_heapify(vector<int>& nums, int idx)
    {
        int largest=idx;
        int l=left(idx),r=right(idx);
        if(l<heap_size&&nums[l]>nums[largest])
        {
            largest=l;
        }
        if(r<heap_size&&nums[r]>nums[largest])
        {
            largest=r;
        }
        if(largest!=idx)
        {
            swap(nums[idx],nums[largest]);
            max_heapify(nums,largest);
        }
    }
    void build_max_heap(vector<int>& nums)
    {
        heap_size=nums.size();
        for(int i=(heap_size>>1)-1;i>=0;i--)
        {
            max_heapify(nums,i);
       
        }
    }
    int findKthLargest(vector<int>& nums,int k)
    {
        build_max_heap(nums);
        for(int i=0;i<k;i++)
        {
            swap(nums[0],nums[heap_size-1]);
            heap_size--;
            max_heapify(nums,0);
            
        }
        return nums[heap_size];
    }
    int heap_size;
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
