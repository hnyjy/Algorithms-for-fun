//
//  main.cpp
//  Kth Smallest Element in a BST2
//
//  Created by yangjingyi on 4/4/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <stack>
#include <vector>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    int kthSmallest(TreeNode* root, int& k)
    {
        stack<TreeNode*> st;
        vector<int> re;
        while((!st.empty()||root)&&re.size()<k)
        {
            while(root)
            {
                st.push(root);
                root=root->left;
            }
            root=st.top();
            re.push_back(root->val);
            st.pop();
            root=root->right;
            
        }
        return re[k-1];
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
