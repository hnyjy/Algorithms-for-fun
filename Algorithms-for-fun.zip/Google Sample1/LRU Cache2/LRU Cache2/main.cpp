//
//  main.cpp
//  LRU Cache2
//
//  Created by yangjingyi on 3/21/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
