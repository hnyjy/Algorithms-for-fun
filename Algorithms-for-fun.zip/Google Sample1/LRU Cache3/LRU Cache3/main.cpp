//
//  main.cpp
//  LRU Cache3
//
//  Created by yangjingyi on 6/29/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <list>
#include <stack>
using namespace std;
class LRUCache
{
public:
    list<int> cachelist;
    unordered_map<int,pair<int,list<int>::iterator> > hash;
    int listcapacity;
    LRUCache(int capacity)
    {
        listcapacity=capacity;
    }
    int get(int key)
    {
        auto it=hash.find(key);
        if(it==hash.end())
        {
            return -1;
        }
           
        help(it);
        return it->second.first;
    }
    void set(int key,int value)
    {
        stack<pair<int,int > > stk;
        stk.top().first;
        
        auto it=hash.find(key);
        if(it!=hash.end())
        {
            help(it);
            
        }
        else
        {
            if(hash.size()==listcapacity)
            {
                hash.erase(cachelist.back());
                cachelist.pop_back();
            }
        }
        hash[key]={value,cachelist.begin()};
    }
    void help(unordered_map<int,pair<int,list<int>::iterator> >::iterator &it)
    {
        int val=it->first;
        cachelist.erase(it->second.second);
        cachelist.push_front(val);
        it->second.second=cachelist.begin();
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
