//
//  main.cpp
//  LRU4
//
//  Created by yangjingyi on 7/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;
class LRUCache
{
private:
    unordered_map<int,int> hash;
    vector<unordered_map<int,int> ::iterator> v;
    int _capacity;
public:
    LRUCache(int capacity):_capacity(capacity){}
    int get(int key)
    {
        auto it=hash.find(key);
        if(it==hash.end())
        {
            return -1;
        }
        touch(it);
        return it->second;
    }
    void set(int key, int value)
    {
        auto it=hash.find(key);
        if(it!=hash.end())
        {
            hash[key]=value;
            touch(it);
            
        }
        else
        {
            if(v.size()==_capacity)
            {
                hash.erase(*(v.begin()));
                hash[key]=value;
                v.erase(v.begin());
                auto tmp=hash.find(key);
                v.push_back(tmp);
            }
            else
            {
                hash[key]=value;
                auto tmp=hash.find(key);
                v.push_back(tmp);
            }
        }
    }
    void touch(unordered_map<int,int>::iterator it)
    {
        auto tmp=find(v.begin(),v.end(),it);
        v.erase(tmp);
        v.push_back(it);
    }
};


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
