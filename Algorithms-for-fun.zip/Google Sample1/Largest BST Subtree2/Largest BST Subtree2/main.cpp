//
//  main.cpp
//  Largest BST Subtree2
//
//  Created by yangjingyi on 4/4/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <climits>
#include <algorithm>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    int largestBSTSubtree(TreeNode* root)
    {
        int res;
        int minval,maxval;
        bool flag=isBST(root, res,minval,maxval);
        return res;
        
    }
    bool isBST(TreeNode* root, int& res, int& minval, int& maxval)
    {
        if(!root)
        {
            return true;
        }
        bool flag_left,flag_right;
        int left_size,right_size,left_minval,left_maxval,right_minval,right_maxval;
        flag_left=isBST(root->left,left_size,left_minval,left_maxval);
        flag_right=isBST(root->right,right_size,right_minval,right_maxval);
        if(flag_left&&flag_right)
        {
            if((!root->left||root->val>=left_maxval)&&(!root->right||root->val<=right_minval))
            {res=left_size+right_size+1;
            minval=root->left?left_minval:root->val;
            maxval=root->right?right_maxval:root->val;
            }
        }
        res=max(left_size,right_size);
        return false;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
