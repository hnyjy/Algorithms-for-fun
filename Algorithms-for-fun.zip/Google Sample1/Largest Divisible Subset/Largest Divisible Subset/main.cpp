//
//  main.cpp
//  Largest Divisible Subset
//
//  Created by yangjingyi on 7/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<int> largestDivisibleSubset(vector<int>& nums)
    {
        sort(nums.begin(),nums.end());
        vector<int> T(nums.size(),0);
        vector<int> parent(nums.size(),0);
        int m=0;
        int mi=0;
        for(int i=nums.size()-1;i>=0;i--)
        {
            for(int j=i;j<nums.size();j++)
            {
                if(nums[j]%nums[i]==0&&T[i]<1+T[j])
                {
                    T[i]=1+T[j];
                    parent[i]=j;
                    if(T[i]>m)
                    {
                        m=T[i];
                        mi=i;
                    }
                }
            }
        }
        vector<int> res;
        for(int i=0;i<m;i++)
        {
            res.push_back(nums[mi]);
            mi=parent[mi];
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
