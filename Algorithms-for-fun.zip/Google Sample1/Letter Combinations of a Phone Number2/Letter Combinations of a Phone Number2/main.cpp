//
//  main.cpp
//  Letter Combinations of a Phone Number2
//
//  Created by yangjingyi on 4/24/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<string> dtl={"","", "abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};
    vector<string> letterCombinations(string digits)
    {
        vector<string> res;
        if(digits.size()==0)
        {
            return res;
        }
        res.push_back("");
        for(int i=0;i<digits.size();i++)
        {
            int num=digits[i]-'0';
            if(num<0||num>9)
            {
                break;
            }
            string can=dtl[num];
            if(can.size()==0)
            {
                continue;
            }
            vector<string> tmp;
            for(int j=0;j<can.size();j++)
            {
                for(int k=0;k<res.size();k++)
                {
                    tmp.push_back(res[k]+can[j]);
                }
            }
            res.swap(tmp);
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
