//
//  main.cpp
//  Line Reflection
//
//  Created by yangjingyi on 7/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
#include <set>
using namespace std;
class Solution
{
public:
    bool isReflected(vector<pair<int,int> >& points)
    {
        int len=points.size();
        if(len==0||len==1)
        {
            return true;
        }
        unordered_map<int,set<int> > mp;
        int max=points[0].first, min=points[0].first;
        for(int i=0;i<len;i++)
        {
            if(points[i].first<min)
            {
                min=points[i].first;
            }
            if(points[i].first>max)
            {
                max=points[i].first;
            }
            mp[points[i].second].insert(points[i].first);
        }
        double line=(min+max)/2.0;
        for(auto it=mp.begin();it!=mp.end();it++)
        {
            set<int>& s=it->second;
            for(auto start=s.begin(),end=s.end();start!=end;start++)
            {
                if((*start+*(--end))/2.0!=line)
                {
                    return false;
                }
                if(start==end)
                {
                    break;
                }
            }
        }
        return true;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
