//
//  main.cpp
//  Logger Rate Limiter
//
//  Created by yangjingyi on 7/3/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <map>
using namespace std;
class Logger
{
public:
    map<string,int> ok;
    bool shouldPrintMessage(int timestamp, string message)
    {
        if(timestamp<ok[message])
        {
            return false;
        }
        ok[message]=timestamp+10;
        return true;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
