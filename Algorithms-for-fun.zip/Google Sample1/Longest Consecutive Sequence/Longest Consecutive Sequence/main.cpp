//
//  main.cpp
//  Longest Consecutive Sequence
//
//  Created by yangjingyi on 4/24/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;
class Solution
{
public:
    int longestConsecutive(vector<int> &num)
    {
        unordered_map<int,int> mp;
        int r=0;
        for(auto n:num)
        {
            if(mp[n])
            {
                continue;
            }
            r=max(r,mp[n]=mp[n+mp[n+1]]=mp[n-mp[n-1]]=mp[n+1]+mp[n-1]+1);
        }
        return r;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
