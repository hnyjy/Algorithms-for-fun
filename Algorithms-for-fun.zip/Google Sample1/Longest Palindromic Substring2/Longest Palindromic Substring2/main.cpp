//
//  main.cpp
//  Longest Palindromic Substring2
//
//  Created by yangjingyi on 4/21/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
class Solution
{
public:
    string longestPalindrome(string s)
    {
        string sv;
        if(s.size()==0)
        {
            return "";
        }
        if(s.size()==1)
        {
            return s.substr(0,1);
        }
        for(int i=0;i<2*s.size()+2;i++)
        {
            if(i%2!=0)
            {
                sv=sv+s[i/2];
            }
            else
            {
                sv=sv+'#';
            }
        }
        //cout<<sv<<endl;
        string tmp;
        string res;
        for(int i=1;i<sv.size();i++)
        {
            int j;
            for(j=1;i-j>=0&&i+j<sv.size()&&sv[i-j]==sv[i+j];j++);
            
            tmp=sv.substr(i-j+1,2*j-1);
            if(tmp.size()>res.size())
            {
                res=tmp;
            }
            
        }
        //replace(res.begin(),res.end(),'#',' ');
        
        tmp=res;
        res.clear();
        for(auto t:tmp)
        {
            if(t!='#')
            {
                res=res+t;
            }
        }
        return res;
        
    }
};
int main(int argc, const char * argv[]) {
    string in="abdhdfdhbck";
    Solution a;
    string out=a.longestPalindrome(in);
    cout<<out<<endl;
    return 0;
}
