//
//  main.cpp
//  Longest Substring with At Most K Distinct Characters
//
//  Created by yangjingyi on 7/29/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
    string LongestSubstringKDistinct(string s, int k)
    {
        unordered_map<char,int> hash;
        if(s.size()<=k)
        {
            return s;
        }
        int start=0,length=0, maximum=k,left=0;
        for(int i=0;i<s.size();i++)
        {
            if(hash.size()<=k)
            {hash[s[i]]++;}
            else
            {
                if(maximum<i-start)
                {
                    maximum=i-start;
                    left=start;
                }
            while(hash.size()>=k)
            {
                if(--hash[s[start]]==0)
                {
                    hash.erase(s[start]);
                    start++;
                }
            }
            }
            
        }
        return s.substr(left,maximum);
        
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
