//
//  main.cpp
//  Minimum Window Substring2
//
//  Created by yangjingyi on 4/24/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <climits>
using namespace std;
class Solution
{
public:
    string minWindow(string s, string t)
    {
        unordered_map<char,int> hash;
        for(int i=0;i<t.size();i++)
        {
            hash[t[i]]++;
        }
        int start=0,head=0;
        int length=INT_MAX;
        int count=t.size();
        int end=0;
        while(end<s.size())
        {
            if(hash[s[end++]]-->0)
            {
                count--;
            }
            while(count==0)
            {
                if(end-start<length)
                {
                    head=start;
                    length=end-head;
                    
                }
                if(hash[s[start++]]++==0)
                {
                    count++;
                }
            }
        }
        return length==INT_MAX?"":s.substr(head,length);
    }
};

int main(int argc, const char * argv[]) {
    string s="ADOBECODEBANC";
    string t="ABC";
    Solution a;
    string out=a.minWindow(s, t);
    cout<<out<<endl;
    return 0;
}
