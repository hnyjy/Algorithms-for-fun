//
//  main.cpp
//  Moving Average from Data Stream
//
//  Created by yangjingyi on 7/3/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
using namespace std;
class MovingAverage
{
    queue<int> q;
    int subSum;
    int size;
public:
    MovingAverage(int size)
    {
        this->subSum=0;
        this->size=size;
    }
    double next(int val)
    {
        if(q.size()==size)
        {
            subSum-=q.front();
            q.pop();
            
        }
        q.push(val);
        subSum+=val;
        return (double)subSum/(double)q.size();
    }
    
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
