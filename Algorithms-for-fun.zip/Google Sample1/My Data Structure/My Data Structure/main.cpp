//
//  main.cpp
//  My Data Structure
//
//  Created by yangjingyi on 7/18/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <assert.h>
#include <exception>
#include <vector>
#include <string>
using namespace std;
template <class T>
struct ListNode
{
    T val;
    ListNode* next;
    ListNode* pre;
    ListNode(T x):val(x),next(NULL),pre(NULL){}
    
};
template<class T>
class myvector
{
private:
    int vect_size;
    int vect_capa;
    ListNode<T>* headpt;
    ListNode<T>* endpt;
    ListNode<T>* currpt;
public:
    myvector()
    {
        vect_size=0;
        vect_capa=0;
        headpt=new ListNode<T>;
    }
    myvector(int con_size)
    {
        vect_size=con_size;
        vect_capa=con_size;
        headpt=new ListNode<T>;
        currpt=headpt;
        for(int i=0;i<con_size;i++)
        {
            ListNode<T>* tmp=new ListNode<T>;
            currpt->next=tmp;
            tmp->pre=currpt;
            currpt=currpt->next;
        }
        endpt=currpt;
    }
    myvector(vector<T> const& con_vect)
    {
        vect_size=con_vect.size();
        vect_capa=con_vect.capacity();
        headpt=new ListNode<T>;
        currpt=headpt;
        for(int i=0;i<con_vect.size();i++)
        {
            ListNode<T>* tmp=new ListNode<T>(con_vect[i]);
            currpt->next=tmp;
            tmp->pre=currpt;
            currpt=currpt->next;
        }
        endpt=currpt;
    }
    myvector(T const con_array[],int con_array_len)
    {
        vect_size=con_array_len;
        vect_size=con_array_len;
        headpt=new ListNode<T>;
        for(int i=0;i<con_array_len;i++)
        {
            
        }
    }
    void addsize(int add_size)
    {
        T* tmp=(T*) calloc(add_size,sizeof(T));
        currpt=endpt;
        endpt->next=tmp;
        
        
    }
};
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
