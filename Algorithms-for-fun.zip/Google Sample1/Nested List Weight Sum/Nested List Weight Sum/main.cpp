//
//  main.cpp
//  Nested List Weight Sum
//
//  Created by yangjingyi on 7/3/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int depthSum(vector<NestedInteger> & nestedList)
    {
        return depthSumHelper(nestedList,1);
    }
    int depthSumHelper(vector<NestedInteger>& nestedList, int depth)
    {
        int res=0;
        for(auto nl:nestedList)
        {
            if(nl.isInteger())
            {
                res+=depth*nl.getInteger();
            }
            else
            {
                res+=depthSumHelper(nl.getList(),depth+1);
            }
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
