//
//  main.cpp
//  Nested List Weight SumII2
//
//  Created by yangjingyi on 7/8/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int depthSumInverse(vector<NestedInteger> nestedList)
    {
        int unweighted=0,weighted=0;
        while(!nestedList.empty())
        {
            vector<NestedInteger> nextLevel;
            for(int i=0;i<nestedList.size();i++)
            {
                if(nestedList[i].isInteger())
                {
                    unweighted+=nestedList[i].getInteger);
                }
                else
                {
                    nextLevel.push_back(nestedList[i]);
                }
            }
            weighted+=unweighted;
            nestedList=nextLevel;
        }
        return weighted;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
