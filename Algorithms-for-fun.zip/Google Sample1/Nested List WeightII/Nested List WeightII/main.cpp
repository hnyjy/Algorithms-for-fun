//
//  main.cpp
//  Nested List WeightII
//
//  Created by yangjingyi on 7/8/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>
using namespace std;
class Solution
{ public:
    int depthSum(vector<NestedInteger>& nestedList)
    {
        int res=0;
        int dep=depth(nestedList);
         res= depthSumHelper(nestedList, dep);
        return res;
    }
    int depth(vector<NestedInteger>& nestedList)
    {
        int dep=1;
        for(int i=0;i<nestedList.size();i++)
        {
            if(!nestedList[i].isInteger())
            {
                dep=max(dep,depth(nestedList[i])+1);
            }
        }
        return dep;
    }
    int depthSumHelper(vector<NestedInteger>& nestedList, int& dep)
    {
        int res=0;
        for(int i=0;i<nestedList.size();i++)
        {
            if(nestedList[i].isInteger())
            {
                res+=depth*nestedList.getInteger();
            }
            else
            {
                res+=depthSumHelper(nestedList[i].getList(), depth-1);
            }
        }
        return res;
    }
    
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
