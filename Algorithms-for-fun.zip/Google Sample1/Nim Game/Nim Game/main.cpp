//
//  main.cpp
//  Nim Game
//
//  Created by yangjingyi on 7/3/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
     bool canWinNim1(int n)
    {
        return n% 4!=0;
    }
    bool canWinNim( int n)
    {
        int* p=new (nothrow) int [n];
        if(p!=nullptr)
        {
            p[0]=true;
            p[1]=true;
            p[2]=true;
            for(int i=3;i<n;i++)
            {
                p[i]=!(p[i-1]&&p[i-2]&&p[i-3]);
            }
        }
        int res=p[n-1];
        delete[] p;
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
