//
//  main.cpp
//  Number of Islands2
//
//  Created by yangjingyi on 3/30/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
    
public:
    
    int numIslands(vector<vector<char> >& grid)
    {
        
        
        if(grid.size()==0||grid[0].size()==0)
        {
            return 0;
        }
        int n=grid.size();
        int m=grid[0].size();
        int res=0;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<m;j++)
            {
                if(grid[i][j]=='1')
                {
                    res++;
                    DFS(i,j,grid);
                }
            }
            
        }
        return res;
    }
    vector<vector<int> >dirs={{0,1},{0,-1},{1,0},{-1,0}};
    void DFS(int i,int j,vector<vector<char> >& grid)
    {
        grid[i][j]='0';
        for(auto dir:dirs)
        {
            int ii=i+dir[0];
            int jj=j+dir[1];
            if(ii>=0&&ii<grid.size()&&jj>=0&&jj<grid[0].size()&&grid[ii][jj]=='1')
            {
                DFS(ii,jj,grid);
            }
            else
            {
                continue;
            }
        }
        return;
    }
    
};


int main(int argc, const char * argv[]) {
    vector<vector<char> >in={{'1','1'}};
    Solution a;
    
    return 0;
}
