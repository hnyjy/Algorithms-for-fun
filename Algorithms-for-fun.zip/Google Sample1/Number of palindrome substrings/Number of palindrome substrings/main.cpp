//
//  main.cpp
//  Number of palindrome substrings
//
//  Created by yangjingyi on 8/2/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int NumofPalindromeSubstring(string s)
    {
        vector<vector<int> > dp(s.size(),vector<int> (s.size()));
        vector<vector<bool> > dp1(s.size(),vector<bool>(s.size(),false));
        for(int j=0;j<s.size();j++)
        {
            dp[j][j]=1;
            dp1[j][j]=true;
            for(int i=j-1;i>=0;i--)
            {
                dp[i][j]=dp[i+1][j]+dp[i][j-1];
                if(i+1<=j-1)
                {
                    dp[i][j]-=dp[i+1][j-1];
                }
                if(s[i]==s[j]&&(i+1<=j-1?dp1[i+1][j-1]:true))
                {
                    dp[i][j]+=1;
                    dp1[i][j]=true;
                }
                cout<<"dp["<<i<<"]["<<j<<"]="<<dp[i][j]<<endl;
                
            }
            
        }
        return dp[0][s.size()-1];
    }
    bool isPalindrom(string s)
    {
        int left=0,right=s.size()-1;
        while(left<=right)
        {
            if(s[left]!=s[right])
            {
                cout<<left<<endl;
                return false;
            }
            left++;
            right--;
        }
        return true;
    }
};

int main(int argc, const char * argv[]) {
    string in="hellolle";
    Solution sol;
   cout<<sol.NumofPalindromeSubstring(in)<<endl;
//    if(sol.isPalindrom(in.substr(2,2)))
//    {
//        cout<<"right"<<endl;
//    }
   
    string in1="wowppurerocks";
    cout<<sol.NumofPalindromeSubstring(in1)<<endl;
//    string in2="abaa";
//    cout<<sol.NumofPalindromeSubstring(in2)<<endl;
    
    return 0;
};
