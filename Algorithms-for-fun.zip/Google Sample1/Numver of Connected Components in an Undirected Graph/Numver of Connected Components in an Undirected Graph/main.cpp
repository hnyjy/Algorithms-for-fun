//
//  main.cpp
//  Numver of Connected Components in an Undirected Graph
//
//  Created by yangjingyi on 7/8/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
#include <numeric>
using namespace std;
class Soluiton
{
public:
    int countComponents(int n,vector<pair<int,int> >& edges)
    {
        vector<int> p(n);
        iota(p.begin(),p.end(),0);
        
        for(auto edge:edges)
        {
            int v=edge.first, w=edge.second;
            while(p[v]!=v)
            {
                p[v]=p[p[v]];
                v=p[v];
            }
            while(p[w]!=w)
            {
                p[w]=p[p[w]];
                w=p[w];
            }
            p[v]=w;
            n-=v!=w;
        }
        return n;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
