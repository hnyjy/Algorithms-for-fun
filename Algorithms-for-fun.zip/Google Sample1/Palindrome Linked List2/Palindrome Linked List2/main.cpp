//
//  main.cpp
//  Palindrome Linked List2
//
//  Created by yangjingyi on 7/4/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
};
class Solution
{
public:
    bool isPalindrome(ListNode* head)
    {
        if(!head||!head->next)
        {
            return true;
        }
        ListNode* slow=head;
        ListNode* fast=head;
        ListNode* rev=NULL;
        int i=0;
        while(fast&&fast->next)
        {
            fast=fast->next->next;
            ListNode* tmp=rev;
            rev=slow;
            slow=slow->next;
            

            rev->next=tmp;
            //cout<<i<<endl;
            //i++;
            
                        
        }
        //cout<<"right"<<endl;

        if(fast)
        {
            slow=slow->next;
        }
        while(rev&&rev->val==slow->val)
        {
            slow=slow->next;
            rev=rev->next;
        }
        return !rev;
        
    }
};

int main(int argc, const char * argv[]) {
    ListNode* in1=new ListNode(1);
    in1->next=new ListNode(2);
    in1->next->next=new ListNode(1);
    Solution sol;
    bool out1=sol.isPalindrome(in1);
    if(out1)
    {
        cout<<"right"<<endl;
    }
    return 0;
}
