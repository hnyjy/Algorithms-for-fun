//
//  main.cpp
//  Permutation II2
//
//  Created by yangjingyi on 7/20/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<vector<int> > permuteUnique(vector<int>& num)
    {
        sort(num.begin(),num.end());
        vector<vector<int> > res;
        recursion(num,0,num.size(),res);
        return res;
    }
    void recursion(vector<int> num, int i, int j, vector<vector<int> >& res)
    {
        if(i==j-1)
        {
            res.push_back(num);
            return;
        }
        for(int k=i;k<j;k++)
        {
            if(i!=k&&num[i]==num[k])
            {
                continue;
            }
            swap(num[i],num[k]);
            recursion(num,i+1,j,res);
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
