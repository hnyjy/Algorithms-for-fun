//
//  main.cpp
//  Plus One Linked List
//
//  Created by yangjingyi on 7/7/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
    
};
class Solution
{
public:
    ListNode* plusOne(ListNode* head)
    {
        if(!head)
        {
            return new ListNode(1);
        }
        ListNode* plus=plusOne(head->next);
        head->val+=plus!=head->next;
        if(head->val<=9)
        {
            return head;
        }
        head->val=0;
        plus->next=head;
        return plus;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
