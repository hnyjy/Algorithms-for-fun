//
//  main.cpp
//  Practice
//
//  Created by yangjingyi on 6/4/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <stack>
#include <queue>
#include <algorithm>
#include <climits>
#include <unordered_map>
#include <set>
#include <vector>
#include <map>
#include <list>
#include <string>
#define TABLE_SIZE 128
using namespace std;
class foo
{public:
    stack<int>* stk;
    int minval=INT_MIN;
public:
    foo()
    {
        stk=new stack<int>();
    }
    void setmin(int x)
    {
        minval=x;
    }
   bool empty()
    {
        if(stk->size()==0)
        {
            cout<<"True"<<endl;
            return true;
        }
        else
        {
            return false;
        }
        
    }
    
};
struct TreeNode
{
    int val;
    TreeNode* right;
    TreeNode* left;
    TreeNode(int x):val(x),right(NULL),left(NULL){}
};
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
};
struct ListNode1
{
    int val;
    ListNode1* next;
    ListNode1* down;
    ListNode1(int x):val(x),next(NULL),down(NULL){}
};
class HashNode
{
public:
    int key;
    int value;
    HashNode* next;
    HashNode(int k,int v): key(k),value(v),next(NULL){}
};
class Hash
{
    HashNode** table;
public:
    Hash()
    {
        table=new HashNode*[TABLE_SIZE];
        memset(table,0,TABLE_SIZE*sizeof(HashNode*));
        
    }
    int operator[](int key)
    {
        return(this->search(key));
    }
    int hash_key(int k)
    {
        return (k%TABLE_SIZE);
    }
    void insert(int k,int v)
    {
        int h=hash_key(k);
        if(table[h])
        {
            HashNode* current=table[h];
            HashNode* previous=NULL;
            while(current)
            {
                previous=current;
                current=current->next;
            }
            previous->next=new HashNode(k,v);
            
        }
        else
        {
            HashNode* _new=new HashNode(k,v);
            table[h]=_new;
        }
    }
    int search(int k)
    {
        int h=hash_key(k);
        HashNode* current=table[h];
        if(current==0)
        {
            cout<<"Didn't find the element"<<endl;
            return -1;
        }
        while(current->key!=k)
        {
            current=current->next;
            if(!current)
            {
                cout<<"Didn't find the element"<<endl;
                return -1;
            }
        }
        cout<<"Element found"<<endl;
        return current->value;
    }
};

class myComparison
{
public:
    bool operator()(const pair<string,int>& p1,pair<string,int>& p2) const
    {
        if(p1.first==p2.first)
        {
            return p1.second>p2.second;
        }
        return p1.first>p2.first;
    }
};
class myComparison1
{
public:
    bool operator()(const string& s1,const string& s2) const
    {
        return s1.compare(s2)>0;
    }
};
class myComparison2
{
public:
    bool operator()(const unordered_map<string, int> ::iterator & it1, const unordered_map<string,int>::iterator& it2) const
    {
        return it1->second<it2->second;
    }
};
class myComparison3
{
public:
    bool operator()(const unordered_map<int,pair<int,int> >::iterator & it1, const unordered_map<int,pair<int, int> >::iterator& it2) const
    {
        if(it1->second.second==it2->second.second)
        {
            return it1->second.first>it2->second.first;
        }
        else
        {
            return it1->second.second<it2->second.second;
        }
    }
};
class myComparison4
{
public:
    bool operator()(const int& lhs,const int& rhs) const
    {
        return lhs>rhs;
    }
};
class Stack
{
private:
    queue<int> q1;
public:
    void push(int x)
    {
        q1.push(x);
        int q_size=q1.size();
        for(int i=0;i<q_size-1;i++)
        {
            q1.push(q1.front());
            q1.pop();
        }
        
    }
    void pop()
    {
        q1.pop();
    }
    int top()
    {
        return q1.front();
    }
    bool empty()
    {
        return q1.empty();
    }
    
};
class MaxStack1
{
    
public:
    long max;
    stack<long> stk;
    MaxStack1()
    {
        
    }
    void push(int x)
    {
        if(stk.empty())
        {
            stk.push(0);
            max=x;
        }
        else
        {
            stk.push(x-max);
            if(x>max)
            {
                max=x;
            }
        }
        
    }
    void pop()
    {
        if(stk.empty())
        {
            return;
        }
        else
        {
            long popval=stk.top();
            stk.pop();
            if(popval>0)
            {
                max=max-popval;
            }
        }
        
        
    }
    int top()
    {
        long topval=stk.top();
        if(topval<0)
        {
            return (max+topval);
        }
        else
        {
            return max;
        }
    }
    int getMax()
    {
        return max;
    }
};
struct MaxStack2Node
{
    int val;
    int maxval;
    MaxStack2Node* next;
    MaxStack2Node(int x,int y):val(x),maxval(y),next(NULL){}
};

class MaxStack2
{
public:
    MaxStack2Node* head=NULL;
    void push(int x)
    {
        if(!head)
        {
            head=new MaxStack2Node(x,x);
        }
        else
        {
            MaxStack2Node* n=new MaxStack2Node(x,max(head->maxval,x));
            n->next=head;
            head=n;
        }
    }
    void pop()
    {
        if(head)
        {
            head=head->next;
        }
    }
    int top()
    {
        if(head)
        {
            return head->val;
        }
        else
        {
            return -1;
        }
    }
    int getMax()
    {
        if(head)
        {
            return head->maxval;
        }
        else
        {
            return -1;
        }
    }
};
class MaxStack3
{
public:
    stack<int> stk1;
    stack<int> stk2;
    int maxval;
    void push(int x)
    {
        if(stk1.empty())
        {
            stk1.push(x);
            stk2.push(x);
        }
        else
        {
            stk1.push(x);
            if(x>=maxval)
            {
                stk2.push(x);
            }
        }
    }
    void pop()
    {
        if(stk1.top()==getMax())
        {
            stk2.pop();
        }
        stk1.pop();
    }
    int top()
    {
        return stk1.top();
    }
    int getMax()
    {
        return stk2.top();
    }
};
struct TrieNode1
{
    TrieNode1* children[10];
    vector<string> words;
    bool end;
    TrieNode1():end(false)
    {
        memset(children,NULL,sizeof(TrieNode1*)*10);
    }
};
class LRUCache
{
    size_t m_capacity;
    unordered_map<int,list<pair<int,int> >::iterator> m_map;
    list<pair<int,int> > m_list;
public:
    LRUCache(size_t capacity):m_capacity(capacity){}
    int get(int key)
    {
        auto found_iter=m_map.find(key);
        if(found_iter==m_map.end())
        {
            return -1;
        }
        m_list.splice(m_list.begin(),m_list,found_iter->second);;
        return found_iter->second->second;
    }
    void set(int key, int value)
    {
        auto found_iter=m_map.find(key);
        if(found_iter!=m_map.end())
        {
            m_list.splice(m_list.begin(),m_list,found_iter->second);
            found_iter->second->second=value;
            return;
        }
        if(m_map.size()==m_capacity)
        {
            int key_to_del=m_list.back().first;
            m_list.pop_back();
            m_map.erase(key_to_del);
        }
        m_list.emplace_front(key,value);
        m_map[key]=m_list.begin();
    }
    
};
struct Ticket
{
    string start;
    string end;
    int depart;
    int arrive;
    Ticket(string s1, string s2, int x, int y):start(s1),end(s2),depart(x),arrive(y){}
};
class MinStack
{
private:
    queue<pair<int, int> > q1;
    queue<pair<int,int> > q2;
    int minval=INT_MIN;
public:
    void push(int x)
    {
        if(q1.size()==0)
        {
            q1.push({x,x});
        }
        else
        {
            if(x<=minval)
            {
                minval=x;
            }
            q1.push({x,minval});
            int qsize=q1.size();
            for(int i=0;i<qsize-1;i++)
            {
                q1.push(q1.front());
                q1.pop();
            }

        }
    }
    void pop()
    {
        q1.pop();
    }
    int top()
    {
        return q1.front().first;
    }
    int getMin()
    {
        return q1.front().second;
    }
};

class Solution
{
public:
    int height(TreeNode* root)
    {
        if(!root)
        {
            return 0;
        }
        else
        {
            return max(height(root->left),height(root->right))+1;
        }
    }
    bool isBalanced(TreeNode* root)
    {
        if(!root)
        {
            return true;
        }
        else
        {
            return isBalanced(root->left)&&isBalanced(root->right)&&abs(height(root->right)-height(root->left))<=1;
        }
    }
    int findMostFrequent(ListNode* head)
    {
        ListNode* curr=head;
        unordered_map<int,int> hashmap;
        int res=0;
        int frequence=INT_MIN;
        while(curr)
        {
            hashmap[curr->val]++;
            
            if(hashmap[curr->val]>frequence)
            {
                //cout<<"right"<<endl;
                res=curr->val;
                frequence=hashmap[curr->val];
            }
            curr=curr->next;
        }
        return res;
    }
    ListNode* addTwoNumbers(ListNode* l1, ListNode* l2)
    {
        ListNode preHead(0);
        ListNode* p=&preHead;
        int extra=0;
        while(l1||l2||extra)
        {
            int sum=(l1?l1->val:0)+(l2?l2->val:0)+extra;
            extra=sum/10;
            p->next=new ListNode(sum%10);
            p=p->next;
            l1=l1?l1->next:l1;
            l2=l2?l2->next:l2;
        }
        return preHead.next;
    }
    ListNode* reverseList(ListNode* head)
    {
        ListNode preHead(0);
        ListNode* p=&preHead;
        ListNode* curr=head;
        stack<int> stk;
        while(curr)
        {
            stk.push(curr->val);
            curr=curr->next;
        }
        while(!stk.empty())
        {
            p->next=new ListNode(stk.top());
            stk.pop();
            p=p->next;
        }
        return preHead.next;
        
    }
    ListNode* reverseList2(ListNode* head)
    {
        ListNode preHead(0);
        ListNode* p=&preHead;
        ListNode* fhead=head;
        ListNode* curr=head->next;
        //cout<<curr->val<<endl;
        ListNode* pre=head;
        while(curr)
        {
            ListNode* nextN;
            nextN=curr->next;
            //cout<<curr->val<<endl;
            
            p->next=curr;
            curr->next=fhead;
            pre->next=nextN;
            fhead=curr;
            curr=pre->next;
            
        }
        return preHead.next;
    }
    int addDigits(int num)
    {
        string numS=to_string(num);
        //cout<<numS<<endl;
        int res=0;
        for(int i=0;i<numS.size();i++)
        {
            res+=numS[i]-'0';
        }
        //cout<<res<<endl;
        if(res<=9)
        {
            return res;
        }
        else
        {
            return addDigits(res);
        }
    }
    vector<pair<int,int> > addTo10(vector<int> nums)
    {
        vector<pair<int,int> > res;
        
        set<int> st(nums.begin(),nums.end());
        //auto it1=st.begin();
        //auto it2=st.begin();
        for(auto it1=st.begin();it1!=st.end();it1++)
        {
            if(*it1>10)
            {
                break;
            }
            auto it2=find(st.begin(),st.end(),10-*it1);
            if((it2!=st.end())&&((*it2)>(*it1)||((*it2)==(*it1)&&(it2!=it1))))
            {
                res.push_back({*it1,*it2});
            }
            
            
            
        }
        return res;
    }
    vector<vector<string> > allAnagrams(vector<string> words)
    {
        vector<vector<string> > res;
        if(words.size()==0)
        {
            return res;
        }
        help_allAnagrams(words, res, 0);
        return res;
    }
    void help_allAnagrams(vector<string>& words, vector<vector<string> >&res, int begin)
    {
        if(begin>=words.size())
        {
            res.push_back(words);
            return;
        }
        else
        {
            for(int i=begin;i<words.size();i++)
            {
                swap(words[begin],words[i]);
                help_allAnagrams(words, res, begin+1);
                swap(words[begin],words[i]);
            }
        }
        
    }
    vector<int> maxProfit(vector<int>& prices)//0 means hold, 1 means long, 2 means short
    {
        int len=prices.size();
        vector<int> res(len,0);
        
        if(prices.size()==0)
        {
            return res;
        }
        bool stock=false;
        
        for(int i=0;i<prices.size()-1;i++)
        {
            if(prices[i+1]-prices[i]>=0)
            {
                if(stock)
                {
                    res[i]=0;
                    res[i+1]=0;
                }
                else
                {
                    res[i]=1;
                    res[i+1]=0;
                    stock=true;
                }
            }
            else
            {
                if(stock)
                {
                    res[i]=2;
                    res[i+1]=0;
                    stock=false;
                }
                else
                {
                    res[i]=0;
                    res[i+1]=0;
                }
            }
        }
        return res;
        
    }
    queue<int> lastFive(ListNode* head)
    {
        ListNode* curr=head;
        queue<int> res;
        while(curr)
        {
            res.push(curr->val);
            if(res.size()>5)
            {
                res.pop();
            }
        }
        return res;
    }
    void reverseString(string& s)
    {
        int k=s.size()/2;
        for(int i=0;i<k;i++)
        {
            swap(s[i],s[s.size()-1-i]);
        }
    }
    int minSquare(vector<vector<int> > nums, int x, int y)
    {
        int target=nums[x][y];
        bool findT=false;
        int up=INT_MAX, down=INT_MIN, left=INT_MAX,right=INT_MIN;
        for(int i=0;i<nums.size();i++)
        {
            for(int j=0;j<nums[i].size();j++)
            {
                if(nums[i][j]==target)
                {
                    up=min(i,up);
                    down=max(i,down);
                    left=min(j,left);
                    right=max(j,right);
                }
            }
        }
        
        return (right-left)*2+(down-up)*2;
        
    }
    int myAtoi(string str)
    {
        long result=0;
        int indicator=1;
        for(int i=0;i<str.size();)
        {
            i=str.find_first_not_of(' ');
            if(str[i]=='-'||str[i]=='+')
            {
                indicator=(str[i++]=='-')?-1:1;
            }
            while('0'<=str[i]&&str[i]<='9')
            {
                result=result*10+(str[i++]-'0');
                if(result*indicator>=INT_MAX)
                {
                  
                    return INT_MAX;
                }
                if(result*indicator<=INT_MIN)
                {
                    return INT_MIN;
                }
            }
            return result*indicator;
        }
        return 0;
        
    }
    void printNN(unordered_map<int, string> hash)
    {
        
        priority_queue<pair<string,int>, vector<pair<string,int> >,myComparison> mypq;
        for(auto it=hash.begin();it!=hash.end();it++)
        {
            mypq.push({it->second,it->first});
            
        }
        while(mypq.size())
        {
            auto it=mypq.top();
            cout<<it.first<<" "<<it.second<<endl;
            mypq.pop();
        }
    }
    void buildDictionary(vector<string> dict)
    {
        for(int i=0;i<26;i++)
        {
            if(i>=0&&i<3)
            {
                dictmap['a'+i]=2;
            }
            else if(i>=3&&i<6)
            {
                dictmap['a'+i]=3;
            }
            else if(i>=6&&i<9)
            {
                dictmap['a'+i]=4;
            }
            else if(i>=9&&i<12)
            {
                dictmap['a'+i]=5;
            }
            else if(i>=12&&i<15)
            {
                dictmap['a'+i]=6;
            }
            else if(i>=15&&i<19)
            {
                dictmap['a'+i]=7;
            }
            else if(i>=19&&i<22)
            {
                dictmap['a'+i]=8;
            }
            else
            {
                dictmap['a'+i]=9;
            }
        }
        for(auto it=dictmap.begin();it!=dictmap.end();it++)
        {
            //cout<<it->first<<", "<<it->second<<endl;
        }
        for(int i=0;i<dict.size();i++)
        {
            addWord(dict[i]);
        }
        //printDict(head);
        
    }
    void addWord(string s)
    {
        TrieNode1* curr=head;
        
        for(int i=0;i<s.size();i++)
        {
            if(!(curr->children[dictmap[s[i]]]))
            {
                curr->children[dictmap[s[i]]]=new TrieNode1();
            }
            curr=curr->children[dictmap[s[i]]];
        }
        curr->end=true;
        curr->words.push_back(s);
        
    }
    void printDict(TrieNode1* curr)
    {
        if(curr->end)
        {
            for(auto s:curr->words)
            {
                //cout<<s<<endl;
            }
        }
        for(int i=0;i<10;i++)
        {
            if(curr->children[i])
            {
                //cout<<"right"<<i<<endl;
                printDict(curr->children[i]);
            }
        }

        return;
     
        
        
        
    }
    vector<string> lookup(int input)
    {
        vector<string> res;
        //cout<<"right"<<endl;
        string inputStr=to_string(input);
        //cout<<inputStr<<endl;
        TrieNode1* curr=head;
        for(int i=0;i<inputStr.size();i++)
        {
            if(!curr->children[inputStr[i]-'0'])
            {
                //cout<<inputStr[i]-'0'<<endl;
                return res;
            }
            else
            {
                curr=curr->children[inputStr[i]-'0'];
            }
            //cout<<inputStr[i]-'0'<<endl;
        }
        
        help_lookup(curr,res);
        return res;
        
    }
    void help_lookup(TrieNode1* curr,vector<string>& res)
    {
        //cout<<"level"<<endl;
        if(curr->end)
        {
            res.insert(res.end(),curr->words.begin(),curr->words.end());
            for(auto s:curr->words)
            {
                //cout<<s<<endl;
            }
        }
        TrieNode1* tmp=curr;
        for(int i=0;i<10;i++)
        {
            TrieNode1* tmp2=tmp->children[i];
            if(tmp2)
            {
                //cout<<"right"<<i<<endl;
                help_lookup(tmp2,res);
            }
        }
        return;
        
        
    }
    void printN(int n)
    {
        priority_queue<string,vector<string>,myComparison1> pq;
        for(int i=1;i<=n;i++)
        {
            pq.push(to_string(i));
            
        }
        while(pq.size())
        {
            string tmp=pq.top();
            cout<<tmp<<endl;
            pq.pop();
            
        }
        
            
    }
    void sortDict(vector<char>& dict, vector<string> words)
    {
        map<char,set<char> > suc, pre;
        set<char> chars(dict.begin(),dict.end());
        string s;
        for(string w:words)
        {
            for(int i=0;i<min(s.size(),w.size());i++)
            {
                char a=s[i],b=w[i];
                if(a!=b)
                {
                    suc[a].insert(b);
                    pre[b].insert(a);
                    break;
                }
                
            }
            s=w;
        }
        vector<char> res;
        for(auto p:pre)
        {
            chars.erase(p.first);
        }
        while(chars.size())
        {
            char a=*chars.begin();
            res.push_back(a);
            chars.erase(a);
            for(char b:suc[a])
            {
                pre[b].erase(a);
                if(pre[b].empty())
                {
                    chars.insert(b);
                }
            }
        }
        dict=res;
        return;
    }
    TreeNode* mirror(TreeNode* root)
    {
        if(!root)
        {
            return root;
        }
        TreeNode* tmp=new TreeNode(root->val);
        
        tmp->right=mirror(root->left);
        tmp->left=mirror(root->right);
        return tmp;
    }
    void printMost10(vector<pair<string, int> >& stream)
    {
        unordered_map<string,int> hash;
        for(auto s:stream)
        {
            hash[s.first]++;
        }
        for(auto it=hash.begin();it!=hash.end();it++)
        {
            cout<<it->first<<","<<it->second<<endl;
        }
        priority_queue<unordered_map<string, int>::iterator,vector<unordered_map<string,int>::iterator>,myComparison2> pq;
        vector<unordered_map<string,int>::iterator> v;
        for(auto it=hash.begin();it!=hash.end();it++)
        {
            v.push_back(it);
            pq.push(it);
        }
        
        //make_heap(v.begin(),v.end(),myComparison2());
        //cout<<v[0]->first<<endl;
        //cout<<pq.top()->first<<endl;
        
        for(int i=0;i<3;i++)
        {
            cout<<pq.top()->first<<endl;
            pq.pop();
        }
        
    }
    string removeDuplicateLetters(string s)
    {
        vector<int> cand(256,0);
        for(char c:s)
        {
            cand[c]++;
        }
        string result="0";
        for(char c:s)
        {
            if(cand[c]<0)
            {
                cand[c]++;
                continue;
            }
            cand[c]--;
            while(cand[result.back()]<0&&c<result.back())
            {
                cand[result.back()]=-cand[result.back()];
                result.pop_back();
            }
            result+=c;
            cand[c]=-cand[c];
            
        }
        return result.substr(1);
    }
    string flattenListNode1(ListNode1* head)
    {
        string result="";
        if(!head)
        {
            return result;
        }
        result=help_flattenListNode1(head);
        return result;
    }
    string help_flattenListNode1(ListNode1* head)
    {
        string result="";
        if(!head)
        {
            return result;
        }
        result=result+to_string(head->val)+" ";
        result+=help_flattenListNode1(head->down);
        result+=help_flattenListNode1(head->next);
        return result;
    }
    static bool comp(const Ticket& a, const Ticket& b)
    {
        return a.depart<b.depart;
    }
    vector<vector<string> > printTicket(vector<Ticket>& tickets,string start, string dest)
    {
        vector<vector<string> > res;
        if(tickets.size()<2)
        {
            return res;
        }
        sort(tickets.begin(),tickets.end(),comp);
        vector<string> tmp;
        for(int i=0;i<tickets.size()-1;i++)
        {
            tmp.push_back(tickets[i].start);
            help_printTicket(tmp,res,i,tickets,dest);
            tmp.clear();
        }
        return res;
        
    }
    void help_printTicket(vector<string>& tmp, vector<vector<string> >& res, int from,vector<Ticket>& tickets,string dest)
    {
        if(tickets[from].end==dest)
        {
            res.push_back(tmp);
            
        }
        for(int i=from+1;i<tickets.size();i++)
        {
            if(tickets[i].start==tickets[from].end&&tickets[i].depart>tickets[from].arrive)
            {
                tmp.push_back(tickets[i].start);
                help_printTicket(tmp,res,i,tickets,dest);
                tmp.pop_back();
            }
        }
        return;
    }
    ListNode* everyDNode(ListNode* head,int d)
    {
        ListNode* newHead=new ListNode(0);
        ListNode* newcurr=newHead;
        ListNode* curr=head;
        int lsize=1;
        if(!head->next)
        {
            return head;
        }
        while(curr->next)
        {
            curr=curr->next;
            lsize++;
        }
        //cout<<lsize<<endl;
        curr->next=head;
        curr=curr->next;
        ListNode* fhead=new ListNode(0);
        ListNode* pre=fhead;
        pre->next=head;
        while(lsize>1)
        {
            for(int i=0;i<d-1;i++)
            {
                curr=curr->next;
                pre=pre->next;
            }
            
            ListNode* nextn=curr->next;
            //cout<<"curr->val="<<curr->val<<endl;
            newcurr->next=new ListNode(curr->val);
            pre->next=nextn;
            curr=nextn;
            newcurr=newcurr->next;
            
            lsize--;
        }
        newcurr->next=new ListNode(curr->val);
        return newHead->next;
        
    }
    
    void printNum(vector<int> nums)
    {
        unordered_map<int,pair<int,int> >hash;
        unordered_map<int,int> hash1;
        map<int,vector<int>,myComparison4 > hash2;
        for(int i=0;i<nums.size();i++)
        {
            hash1[nums[i]]++;
            if(hash.count(nums[i]))
            {
                hash[nums[i]].second++;
            }
            else
            {
                hash[nums[i]].first=i;
                hash[nums[i]].second++;
            }
        }
        for(auto it=hash.begin();it!=hash.end();it++)
        {
            //cout<<it->first<<","<<it->second.first<<","<<it->second.second<<endl;
        }
        priority_queue<unordered_map<int,pair<int,int> >::iterator,vector<unordered_map<int,pair<int,int> >::iterator>,myComparison3> pq;
        for(auto it=hash.begin();it!=hash.end();it++)
        {
            pq.push(it);
        }
        int pqsize=pq.size();
        //cout<<"pqsize="<<pqsize<<endl;
        for(int i=0;i<pqsize;i++)
        {
            //cout<<pq.top()->first<<endl;
            pq.pop();
        }
        for(auto it=hash1.begin();it!=hash1.end();it++)
        {
            hash2[it->second].push_back(it->first);
        }
        for(auto it=hash2.begin();it!=hash2.end();it++)
        {
            for(auto num:it->second)
            {
                cout<<num<<endl;
            }
        }
        
    }
    void traverseBSTFromRight(TreeNode* root)
    {
        stack<TreeNode*> st;
        vector<int> re;
        while((!st.empty())||root)
        {
            while(root)
            {
                st.push(root);
                root=root->right;
            }
            root=st.top();
            re.push_back(root->val);
            st.pop();
            root=root->left;
        }
        for(auto r:re)
        {
            cout<<r<<endl;
        }
    }
    TreeNode* constructBST(vector<int> nums)
    {
        if(nums.size()==0)
        {
            return NULL;
        }
        int nsize=nums.size();
        TreeNode* root=help_constructBST(0,nums.size()-1,nums);
        return root;
    }
    TreeNode* help_constructBST(int left, int right, vector<int> nums)
    {
        if(right<left)
        {
            return NULL;
        }
        if(left==right)
        {
            TreeNode* root=new TreeNode(nums[left]);
            return root;
        }
        int mid=left+(right-left)/2;
        TreeNode* root=new TreeNode(nums[mid]);
        root->left=help_constructBST(left,mid-1,nums);
        root->right=help_constructBST(mid+1, right, nums);
        return root;
        
    }
    void levelTraverseBT(TreeNode* root)
    {
        vector<vector<int> > res;
        queue<TreeNode*> q;
        q.push(root);
        while(!q.empty())
        {
            vector<int> tmp;
            int size=q.size();
            for(int i=0;i<size;i++)
            {
                if(q.front())
                {
                    
                    tmp.push_back(q.front()->val);
                    if(q.front()->left)
                    {
                        q.push(q.front()->left);
                    }
                    if(!q.front()->left)
                    {
                        q.push(NULL);
                    }
                    if(q.front()->right)
                    {
                        q.push(q.front()->right);
                    }
                    if(!q.front()->right)
                    {
                        q.push(NULL);
                    }

                }
                else
                {
                    tmp.push_back(0);
                }
                q.pop();
            }
            res.push_back(tmp);
        }
        for(auto re:res)
        {
            for(auto r:re)
            {
                cout<<r<<" ";
            }
            cout<<endl;
        }
    }
private:
    TrieNode1* head=new TrieNode1();
    unordered_map<char,int> dictmap;
    
};
class Base
{
public:
    int x;
};
class Derived : public Base{};


int main(int argc, const char * argv[]) {
    
//    int a=20;
//    int* c;
//    int* b;
//    c=&a;
//    b=c;
//    a=10;
//    //cout<<a<<","<<&b<<","<<&c<<endl;
//    string s="abc";
//    //cout<<s.size()<<endl;
//    ListNode* head=new ListNode(5);
//    vector<int> in={9,2,4,2,2,5,2,9,10,2,3,4};
//    ListNode* curr=head;
//    for(int i=0;i<in.size();i++)
//    {
//        curr->next=new ListNode(in[i]);
//        curr=curr->next;
//    }
    Solution sol;
//    //int out=sol.findMostFrequent(head);
//    //cout<<out<<endl;
//    //ListNode* outList=sol.reverseList2(head);
//    /*while(outList)
//    {
//        //cout<<outList->val<<"->";
//        outList=outList->next;
//    }*/
//    //cout<<endl;
//    string normal_str="First line.\nSecond line.\nEnd of message.\n";
//    string raw_str=R"(First line.\nSecond line.\nEnd of message.\n)";
//    //cout<<normal_str<<endl;
//    //cout<<raw_str<<endl;
//    int inNum=928;
//    //int outNum=sol.addDigits(inNum);
//    //cout<<outNum<<endl;
//    vector<int> in1={0,0,0,1,1,2,2,3,4,5,5,6,6,7,7,7,8,8,9,10};
//    vector<pair<int,int> > out1=sol.addTo10(in1);
//    for(auto out1in:out1)
//    {
//        //cout<<out1in.first<<", "<<out1in.second<<endl;
//    }
//    vector<int> in2={1,2,4,2,1,-10,5,8,3,5,9,1,1,-2};
//    vector<int> out2=sol.maxProfit(in2);
//    for(int i=0;i<out2.size();i++)
//    {
//        //cout<<out2[i]<<"->";
//    }
//    //cout<<endl;
//    string in3="strings";
//    sol.reverseString(in3);
//    //cout<<in3<<endl;
//    vector<vector<int> > in4={{0,1,2,3,4},{0,3,0,1,7},{0,3,0,1,7},{0,3,3,1,7}};
//    int out3=sol.minSquare(in4,2, 1);
//    //cout<<out3<<endl;
//    unordered_map<int,string> in5;
//    in5.insert({{1,"John"},{2,"John"},{3,"Bob"},{4,"Amy"}});
//    //sol.printNN(in5);
//    /*MaxStack2 in6;
//    in6.push(5);
//    in6.push(4);
//    cout<<in6.getMax()<<endl;
//    in6.push(7);
//    in6.push(3);
//    cout<<in6.getMax()<<endl;
//    cout<<in6.top()<<endl;
//    in6.pop();
//    cout<<in6.getMax()<<endl;
//    cout<<in6.top()<<endl;
//    in6.pop();
//    cout<<in6.getMax()<<endl;
//    cout<<in6.top()<<endl;*/
//    vector<string> in7={"company","coop","corporate","test","corr"};
//    sol.buildDictionary(in7);
//    
//    vector<string> out7=sol.lookup(26);
//    for(auto s:out7)
//    {
//        //cout<<s<<endl;
//    }
//    string s1="142";
//    string s2="132";
//    //sol.printN(132);
//    ListNode1* in8=new ListNode1(1);
//    in8->next=new ListNode1(2);
//    in8->next->down=new ListNode1(6);
//    in8->next->down->down=new ListNode1(9);
//    in8->next->down->next=new ListNode1(7);
//    in8->next->down->next->next=new ListNode1(8);
//    in8->next->next=new ListNode1(3);
//    in8->next->next->down=new ListNode1(10);
//    in8->next->next->down->next=new ListNode1(11);
//    in8->next->next->next=new ListNode1(4);
//    in8->next->next->next->next=new ListNode1(5);
//    in8->next->next->next->next->down=new ListNode1(12);
//    string out8=sol.flattenListNode1(in8);
//    //cout<<out8<<endl;
//    foo F;
//    //F.empty();
//    //cout<<F.minval<<endl;
//    F.setmin(1);
//    //cout<<F.minval<<endl;
//    ListNode* in9=new ListNode(0);
//    ListNode* curr9=in9;
//    for(int i=0;i<6;i++)
//    {
//        curr9->next=new ListNode(i+1);
//        curr9=curr9->next;
//    }
//    curr9=in9->next;
    /*while(curr9)
    {
        cout<<curr9->val<<endl;
        curr9=curr9->next;
    }*/
    //ListNode* out9=sol.everyDNode(in9->next, 3);
//    while(out9)
//    {
//        //cout<<out9->val<<endl;
//        out9=out9->next;
//    }
//    vector<pair<string,int> > in10={{"a",1},{"b",1},{"c",2},{"d",3},{"b",2},{"e",5},{"a",5},{"f",10},{"k",23},{"l",23},{"c",11},{"f",4},{"d",2},{"n",22},{"m",10},{"p",11},{"q",30},{"l",10},{"k",23},{"a",6},{"a",11},{"a",20},{"c",23},{"l",10}};
//    sol.printMost10(in10);
    //vector<int> in11={6,1,2,2,1,3,3,3,9};
    //sol.printNum(in11);
    TreeNode* in12=new TreeNode(8);
    in12->left=new TreeNode(4);
    in12->right=new TreeNode(12);
    in12->left->left=new TreeNode(2);
    in12->left->left->left=new TreeNode(1);
    in12->left->left->right=new TreeNode(3);

    in12->left->right=new TreeNode(6);
    in12->left->right->left=new TreeNode(5);
    in12->left->right->right=new TreeNode(7);
    in12->right->left=new TreeNode(10);
    in12->right->left->left=new TreeNode(9);
    in12->right->left->right=new TreeNode(11);
    in12->right->right=new TreeNode(13);
    //sol.traverseBSTFromRight(in12);
    vector<int> in13={1,2,3,4,5,6,7,8,9,10};
    TreeNode* out13=sol.constructBST(in13);
    sol.traverseBSTFromRight(out13);
    sol.levelTraverseBT(out13);
    return 0;
}
