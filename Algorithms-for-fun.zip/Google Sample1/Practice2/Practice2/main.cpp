//
//  main.cpp
//  Practice2
//
//  Created by yangjingyi on 6/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <map>
#include <unordered_map>
#include <set>
#include <vector>
#include <stack>
#include <queue>
#include <algorithm>
#include <climits>
#include <sstream>
#include <string>
#include <set>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
};
struct TreeNode1
{

};
class Solution
{
public:
    char firstUniqueChar(string s)
    {
        unordered_map<char,int> hash;
        vector<char> res;
        for(int i=0;i<s.size();i++)
            
        {
            if(!hash.count(s[i]))
            {
                res.push_back(s[i]);
                hash[s[i]]++;
            }
            else
            {
                auto it=find(res.begin(),res.end(),s[i]);
                res.erase(it);
            }
            
        }
        return *res.begin();
    }
    bool findNumberInRotateArray(vector<int> nums, int target)
    {
        int peakIndex=findPeakIndex(nums);
        int res=INT_MIN;
        if(target>nums[peakIndex])
        {
            return false;
        }
        if(nums[0]==target||nums[nums.size()-1]==target||nums[peakIndex]==target)
        {
            return true;
        }
        
        if(findNumber(nums,0,peakIndex,true,target)||findNumber(nums,peakIndex,nums.size()-1,false,target))
        {
            return true;
        }
        return false;
    }
    bool findNumber(vector<int> nums,int left, int right,bool ascend,int target)
    {
        if(ascend)
        {
            while(right>=left)
            {
                int mid=left+(right-left)/2;
                if(nums[mid]==target)
                {
                    
                    return true;
                }
                else if(nums[mid]<target)
                {
                    left=mid+1;
                }
                else
                {
                    right=mid-1;
                }
            }
            return false;
        }
        else
        {
            while(right>=left)
            {
                int mid=left+(right-left)/2;
                if(nums[mid]==target)
                {
                    
                    return true;
                }
                else if(nums[mid]>target)
                {
                    left=mid+1;
                }
                else
                {
                    right=mid-1;
                }
            }
            return false;

        }
    }
    int findPeakIndex(vector<int> nums)
    {
        int left=0;
        int right=nums.size()-1;
        
        while(right>=left)
        {
            int mid=left+(right-left)/2;
            if(nums[mid-1]<nums[mid]&&nums[mid+1]<nums[mid])
            {
                return mid;
            }
            else
            {
                if(nums[mid-1]>nums[mid]&&nums[mid+1]<nums[mid])
                {
                    right=mid-1;
                }
                else
                {
                    left=mid+1;
                }
            }
        }
        return 0;
    }
    int findBottomIndex(vector<int> nums)
    {
        int left=0;
        int right=nums.size()-1;
        while(right>=left)
        {
            int mid=left+(right-left)/2;
            if(nums[mid-1]>nums[mid]&&nums[mid+1]>nums[mid])
            {
                return mid;
                
            }
            else
            {
                if(nums[mid-1]>nums[mid]&&nums[mid+1]<nums[mid])
                {
                    left=mid+1;
                }
                else
                {
                    right=mid-1;
                }
            }
        }
        return 0;
    }
    void printFirst10(vector<pair<string, int> > info)
    {
        map<int, vector<string>,greater<int> > hash;
        for(int i=0;i<info.size();i++)
        {
            helpadd_printFirst10(hash,info[i]);
        }
        helpprint_printFirst10(hash);
        return;
    }
    void helpadd_printFirst10(map<int,vector<string> ,greater<int> >& hash, pair<string,int> infoPair)
    
    {
        hash[infoPair.second].push_back(infoPair.first);
    }
    void helpprint_printFirst10(map<int, vector<string>, greater<int> >hash)
    {
        int i=0;
        for(auto it=hash.begin();it!=hash.end()&&i<4;it++)
        {
            
            for(auto name:it->second)
            {
                cout<<name<<endl;
                i++;
            }
            if(i>=4)
            {
                break;
            }
        }
    }
    ListNode* reverseListIterative(ListNode* head)
    {
        ListNode* new_head=new ListNode(0);
        new_head->next=head;
        ListNode* pre=new_head;
        ListNode* curr=head;
        while(curr&&curr->next)
        {
            ListNode* tmp=pre->next;
            pre->next=curr->next;
            curr->next=curr->next->next;
            pre->next->next=tmp;
        }
        return new_head->next;
    }
    ListNode* reverseListIterative2(ListNode* head)
    {
        ListNode* pre=NULL;
        while(head)
        {
            ListNode* next=head->next;
            head->next=pre;
            pre=head;
            head=next;
        }
        return pre;
        
    }
    ListNode* reverseListRecursive(ListNode* head)
    {
        if(!head||!(head->next))
        {
            return head;
        }
        ListNode* node=reverseListRecursive(head->next);
        head->next->next=head;
        head->next=NULL;
        
        return node;
    }
    void deleteSpace(string s)
    {
        stringstream ss;
        ss.str(s);
        string word,res="";
        while(ss>>word)
        {
            res=res+word;
        }
        cout<<res<<endl;
        
    }
    int addup(int i)
    {
        int res=i;
        //string input=to_string(i)
        while(res>10)
        {
            int tmp=0;
            i=res;
            while(i>0)
            {
                tmp=tmp+i%10;
                i=i/10;
                
            }
            res=tmp;
        }
        return res;
        
    }
    char* strcopy(string s)
    {
        s=s.c_str();
        char *p=&s[0];
        char * head=p;
        char *fhead=head;
        while(*p!='\0')
        {
            *head++=*p++;
        }
        return fhead;
    }
    set<pair<int,int> > findPair(vector<int> nums)
    {
        set<pair<int,int> > res;
        set<signed int> tmp;
        tmp.insert(-(nums[nums.size()-1]));
        for(int i=nums.size()-2;i>=0;i--)
        {
            auto it=upper_bound(tmp.begin(),tmp.end(),-nums[i]);
            if(it!=tmp.end())
            {
                for(it;it!=tmp.end();it++)
                {
                    //cout<<"right"<<endl;
                    res.insert({nums[i],-(*it)});
                }
            }
            tmp.insert(-nums[i]);
            
        }
        
        
        return res;
    }
    
};

int main(int argc, const char * argv[]) {
    // insert code here...
    Solution sol;
//    string in1="aabnjjkmp";
//    
//    char out1=sol.firstUniqueChar(in1);
//    cout<<out1<<endl;
//    vector<int> in2={1,2,3,4,5,8,10,8,6,5,3,1};
//    bool out2=sol.findNumberInRotateArray(in2, 8);
//    if(out2)
//    {
//        cout<<"right"<<endl;
//    }
//    vector<pair<string,int> >in3={{"a",1},{"b",2},{"c",1},{"b",3},{"d",6},{"c",5},{"e",7},{"b",8}};
//    sol.printFirst10(in3);
//    string in3="sdgnh";
//    int a[]={1,2};
    vector<int> in4={1,3,6,2,1,6,8,3,5,2,7,1};
    set<pair<int,int> >out4=sol.findPair(in4);
    for(auto out:out4)
    {
        cout<<out.first<<","<<out.second<<endl;
    }
    
    return 0;
}
