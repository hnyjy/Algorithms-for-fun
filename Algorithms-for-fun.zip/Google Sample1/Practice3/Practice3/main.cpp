//
//  main.cpp
//  Practice3
//
//  Created by yangjingyi on 6/27/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <climits>
#include <stack>
using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
};
class Solution
{
public:
    ListNode* addTwoNumbers(ListNode* l1, ListNode* l2) {
        ListNode* head=new ListNode(0);
        ListNode* fhead=head;
        int tmp=0;
        while(tmp>0||l1||l2)
        {
            int a=l1?l1->val:0;
            int b=l2?l2->val:0;
            //cout<<a+b<<endl;
            head->next=new ListNode((a+b+tmp)%10);
            tmp=(a+b+tmp)/10;
            //cout<<tmp<<endl;
            head=head->next;
            l1=l1?l1->next:NULL;
            l2=l2?l2->next:NULL;
        }
        return fhead->next;
        
    }
    int lengthOfLongestSubstring(string s) {
        int start=0;
        int end=0;
        int res=0;
        unordered_map<int,int> hash;
        for(int i=0;i<s.size();i++)
        {
            
            if(hash.count(s[i]))
            {
                res=max(res,end-start);
                //cout<<"i="<<i<<" "<<"res="<<res<<endl;
                start=max(start,hash[s[i]]+1);
                //cout<<"start="<<start<<endl;
                
                hash[s[i]]=i;
                
            }
            else
            {
                hash[s[i]]=i;
                
            }
            end++;
            
        }
        //cout<<"end="<<end<<endl;
        //cout<<"start="<<start<<endl;
        res=max(res,end-start);
        return res;
    }
    ListNode* swapPairs(ListNode* head) {
        ListNode* fhead=new ListNode(0);
        fhead->next=head;
        ListNode* pre=fhead;
        ListNode* curr=head;
        stack<ListNode*> stk;
        while(head)
        {
            for(int i=0;i<2&&head;i++)
            {
                stk.push(head);
                head=head->next;
                
            }
            while(!stk.empty())
            {
                pre->next=stk.top();
                stk.pop();
                pre=pre->next;
                
            }
            //cout<<"right"<<endl;
        }
        pre->next=NULL;
        return fhead->next;
    }
    double myPow(double x, int n) {
        bool flag=n>0?true:false;
        n=abs(n);
        long res=1;
        while(n>=1)
        {
            if(n%2==0)
            {
                x=x*x;
                
                n=n/2;
            }
            else
            {
                res=res*x;
                x=x*x;
                n=n/2;
            }
        }
        if(!flag)
        {
            res=1/res;
        }
        return res;
    }
    double squareRoot(double n)
    {
        double x=n;
        double y=1;
        double e=0.000000000001;
        if(n>=1)
        {
            while(x-y>e)
            {
                x=(x+y)/2;
                y=n/x;
            }
        }
        else
        {
            x=1/x;
            n=1/n;
            while(x-y>e)
            {
                x=(x+y)/2;
                y=n/x;
            }
            x=1/x;
        }
        return x;
    }
    int findSecondBiggest(vector<int> nums)
    {
        if(nums.size()<=1)
        {
            return nums[0];
        }
        
        int max1=INT_MIN;
        int max2=INT_MIN;
        for(int i=0;i<nums.size();i++)
        {
            if(nums[i]>max1)
            {
                max2=max(max1,max2);
                max1=nums[i];
                
                continue;
            }
            if(nums[i]==max1)
            {
                continue;
            }
            if(nums[i]<max1&&nums[i]>=max2)
            {
                max2=nums[i];
                continue;
            }
            if(nums[i]<max2)
            {
                continue;
            }
        }
        return max2==INT_MIN?max1:max2;
    }

};

int main(int argc, const char * argv[]) {
    Solution sol;
//    ListNode* in11=new ListNode(5);
//    ListNode* in12=new ListNode(5);
//    ListNode* out1=sol.addTwoNumbers(in11, in12);
//    while(out1)
//    {
//        cout<<out1->val<<" ";
//        out1=out1->next;
//    }
//        ListNode* in2=new ListNode(1);
//        in2->next=new ListNode(2);
//        ListNode* out2=sol.swapPairs(in2);
//        while(out2)
//        {
//            cout<<out2->val<<endl;
//            out2=out2->next;
//        }
    vector<int> in1={1,2,2,3,3};
    cout<<sol.findSecondBiggest(in1)<<endl;;
    return 0;
}
