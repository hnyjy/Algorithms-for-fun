//
//  main.cpp
//  Practice4
//
//  Created by yangjingyi on 7/11/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
#include <set>
#include <queue>
#include <climits>
#include <algorithm>
#include <cmath>
#include <sstream>
#include <unordered_set>
#include <stack>

using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x), next(NULL){}
};
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
struct GraphNode
{
    char val;
    vector<pair<GraphNode*, int> > next;
    GraphNode(char x):val(x){}
    
};
struct TreeLinkNode
{
    int val;
    TreeLinkNode* left,* right,* next;
    TreeLinkNode(int x):val(x),left(NULL),right(NULL),next(NULL){}
};
struct TreeNode1
{
    int val;
    TreeNode1* left;
    TreeNode1* right;
    bool visited;
    TreeNode1(int x):val(x),left(NULL),right(NULL),visited(false){}
};
struct MyQueue
{
    queue<double> q;
    double GetNext()
    {
        double tmp=q.front();
        q.pop();
        return tmp;
    }
    bool IsEmpty()
    {
        return q.empty();
    }
};
template<class T>
class SharedPtr
{
    T* ShrdPtr;
    mutable int* refCount;
public:
    SharedPtr(T* ptr)
    {
        ShrdPtr=ptr;
        refCount=new int();
        *refCount=1;
    }
    ~SharedPtr()
    {
        if(--(*refCount)==0)
        {
            delete ShrdPtr;
        }
    }
    T& operator=(const SharedPtr& ptr);
    SharedPtr(const SharedPtr& ptr);
    T* operator->()
    {
        return ShrdPtr;
    }
    T& operator*()
    {
        return *ShrdPtr;
    }
};

template<class T>
T& SharedPtr<T>::operator=(const SharedPtr& ptr)
{
    this->ShrdPtr=ptr.ShrdPtr;
    (*(ptr.refCount))++;
    this->refCount=ptr.refCount;
    return *this;
}
template<class T>
SharedPtr<T>::SharedPtr(const SharedPtr& ptr)
{
    this->ShrdPtr=ptr.ShrdPtr;
    this->ShrdPtr=ptr.ShrdPtr;
    (*(ptr.refCount))++;
    this->refCount=ptr->refCount;
    return *this;
}
class MedianFinder
{
    priority_queue<long> small,large;
    long size=0;
    double ave=0;
    long sum=0;
public:
    void addNum(int num)
    {
        size++;
        sum=sum+num;
        ave=sum/size;
        small.push(num);
        large.push(-small.top());
        small.pop();
        if(small.size()<large.size())
        {
            small.push(-large.top());
            large.pop();
        }
    }
    double findMedian()
    {
        return small.size()>large.size()?small.top():(small.top()-large.top())/2;
    }
};
class Mycomparision
{
public:
    bool operator() (const unordered_map<char,pair<int,int> >::iterator& itl,const unordered_map<char,pair<int,int> >::iterator& itr)
    {
        if(itl->second.first==itr->second.first)
        {
            return itl->second.second>itr->second.second;
        }
        else
        {
            return itl->second.first<itr->second.first;
        }
        
    }
};
class Version
{public:
    
    string ver;
    Version(string x):ver(x){}
    
};
bool operator<(Version& lhs, Version& rhs)
{
    int i=0;
    int j=0;
    int n=lhs.ver.size();
    int m=rhs.ver.size();
    int num1=0,num2=0;
    while(i<n||j<m)
    {
        while(i<n&&lhs.ver[i]!='.')
        {
            num1=num1*10+(lhs.ver[i]-'0');
            i++;
        }
        while(j<m&&rhs.ver[j]!='.')
        {
            num2=num2*10+(rhs.ver[i]-'0');
            j++;
        }
       if(num1!=num2)
       {
           return num1<num2;
       }
        num1=0;
        num2=0;
        i++;
        j++;
    }
    return true;
}
class Solution
{
public:
    bool palindromeLinkedlist(ListNode* head)
    {
        ListNode* fast=head;
        ListNode* curr=head;
        return help_palindromeLinkedlist(head,curr,fast);
    }
    bool palindromeLinkedlist2(ListNode*& head, ListNode* curr )
    {
        
        if(curr->next==NULL)
        {
            if(curr->val==head->val)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            bool res=palindromeLinkedlist2(head, curr->next);
            if(!res)
            {
                return false;
            }
            else
            {
                head=head->next;
                if(curr->val==head->val)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
    bool help_palindromeLinkedlist(ListNode* head,ListNode*& curr,ListNode* fast)
    {
        if(curr)
        {cout<<"curr->val="<<curr->val<<endl;}
        if(fast)
        {
            cout<<"fast->val="<<fast->val<<endl;
        }
        if(head)
        {
            cout<<"head->val="<<head->val<<endl;
        }
        if(fast&&(!fast->next))
        {
            cout<<"1"<<endl;
            
            bool res=(head->val==curr->val);
            curr=curr->next;
            if(res)
            {
                cout<<"res1=true and curr->val="<<curr->val<<endl;
            }
            
            return res;
        }
        else if(fast&&fast->next&&(!fast->next->next))
        {
            cout<<"2"<<endl;
            curr=curr->next;
            bool res=(head->val==curr->val);
            curr=curr->next;
            if(res)
            {
                cout<<"res2=true"<<endl;
            }
            return res;
        }

        else if(fast&&fast->next&&fast->next->next)
            
        {
            cout<<"3"<<endl;
            curr=curr->next;
            bool res=help_palindromeLinkedlist(head->next,curr,fast->next->next)&&head->val==curr->val;
            cout<<"head->val="<<head->val<<endl;
            cout<<"curr->val="<<curr->val<<endl;
            if(curr->next)
            {
                curr=curr->next;
            }
            
            if(res)
            {
                cout<<"res3=true"<<endl;
            }
            return res;
        }
        return true;
        
    }
    string removeDuplicate(string nums)
    {
        if(nums.size()<=1)
        {
            return nums;
        }
        else
        {
            int count=0;
            for(int i=1;i<nums.size();i++)
            {
                if(nums[i]==nums[i-1])
                {
                    continue;
                }
                else
                {
                    nums[++count]=nums[i];
                }
            }
            nums.resize(count+1);
            return nums;
        }
    }
    string bigIntergerMultiply(string num1, string num2)
    {
        string res;
        int i,j;
        vector<int> resv(num1.size()+num2.size(),0);
        reverse(num1.begin(),num1.end());
        reverse(num2.begin(),num2.end());
        for(int i=0;i<num1.size();i++)
        {
            for(int j=0;j<num2.size();j++)
            {
                resv[i+j]+=(num1[i]-'0')*(num2[j]-'0');
                resv[i+j+1]+=resv[i+j]/10;
                resv[i+j]=resv[i+j]%10;
            }
        }
        for(i=num1.size()+num2.size()-1;i>0&&resv[i]==0;i--);
        for(;i>=0;i--)
        {
            res+=to_string(resv[i]);
        }
        
        return res;
    }
    vector<int> prime(int n)
    {
        vector<bool> res(n+1,true);
        
        for(int i=2;i<n+1;i++)
        {
            if(!res[i])
            {
                continue;
            }
            for(int j=i*2;j<n+1;j=j+i)
            {
                if(res[j])
                {res[j]=false;}
            }
        }
        vector<int> resv;
        for(int i=1;i<res.size();i++)
        {
            if(res[i])
            {
                resv.push_back(i);
            }
        }
        return resv;
    }
    int trailingZeroes(int n)
    {
        int count=0;
        if(n<5)
        {
            return 0;
        }
        else
        {
            count=n/5+trailingZeroes(n/5);
        }
        return count;
    }
    int tralingZeroes2(int n)
    {
        int res=0;
        for(long long i=5;n/i>0;i*=5)
        {
            res+=(n/i);
        }
        return res;
    }
    double squareRoot(double n)
    {
        double i=n;
        bool flag=true;
        if(n<1)
        {
            i=1/i;
            n=1/n;
            flag=false;
        }
        double j=1;
        double e=0.00000001;
        double mid=0;
        while(i-j>0)
        {
            mid=(i+j)/2;
            if(mid*mid==n)
            {
                break;
            }
            if(mid*mid<n)
            {
                j=mid+e;
            }
            else
            {
                i=mid-e;
            }
        }
        return flag?mid:1/mid;
    }
    string wordCompression(string s)
    {
        string res=s.substr(0,1);
        int count=1;
        for(int i=1;i<s.size();i++)
        {
            if(s[i]==res.back())
            {
                count++;
            }
            else
            {
                if(count>1)
                {
                    res=res+to_string(count);
                    
                }
                count=1;
                res=res+s[i];
            }
        }
        if(count>1)
        {
            res+=to_string(count);
        }
        return res;
    }
    string resverseSentence(string& s)
    {
        string res;
        for(int i=0;i<s.size();)
        {
            int j;
            for(j=i;j<s.size()&&s[j]!=' ';j++);
            help_reverseSentence(s, i, j-1);
            i=j+1;
        }
        reverse(s.begin(),s.end());
        return s;
        
    }
    void help_reverseSentence(string& s,int start, int end)
    {
        int i=start,j=end;
        while(j>=i)
        {
            swap(s[i],s[j]);
            i++;
            j--;
        }
    }
    bool linkedListIntersection(ListNode* head1, ListNode* head2)
    {
        ListNode* curr1=head1;
        ListNode* curr2=head2;
        while(curr1!=curr2)
        {
            curr1=curr1?curr1->next:head2;
            curr2=curr2?curr2->next:head1;
        }
        return curr1!=NULL;
    }
    vector<GraphNode*> closeFriend(GraphNode* user,int dis,int weightSum)//doesn't have any circle
    {
        unordered_map<GraphNode*,pair<int,int> > hash;
        vector<GraphNode*> res;
        hash[user].first=0;
        hash[user].second=0;
        
        help_closeFriend(user,1,dis, 0, weightSum,res);
        return res;
    }
    void help_closeFriend(GraphNode* user, int distmp, int dis, int weighttmp, int weightSum,vector<GraphNode*>& res)
    {
        if(distmp>dis)
        {
            return;
        }
        else
        {
            for(int i=0;i<user->next.size();i++)
            {
                if(weighttmp+user->next[i].second>=weightSum)
                {
                    res.push_back(user->next[i].first);
                }
                help_closeFriend(user->next[i].first,distmp+1,dis,weighttmp+user->next[i].second,weightSum,res);
            }
            return;
        }
    }
    void inplaceSort(vector<int>& nums)
    {
        for(int i=0;i<nums.size()-1;i++)
        {
            if(nums[i]!=i)
            {
                int tmp=i;
                int j=nums[i];
                while(nums[j]!=j)
                {
                    nums[nums.size()-1]=nums[j];
                    nums[j]=j;
                    j=nums[nums.size()-1];
                    

                }
                
                
            }
            
        }
        return;
    }
    char firstUnique(string s)
    {
        string res;
        unordered_map<char,int> hash;
        for(int i=0;i<s.size();i++)
        {
            if(!hash.count(s[i]))
            {
                
                hash[s[i]]++;
            }
            
        }
        for(int i=0;i<s.size();i++)
        {
            if(!hash.count(s[i]))
            {
                return s[i];
            }
        }
        return s[0];
    }
    int josephLinkedList(ListNode* head,int k)
    {
        if(!head||!head->next)
        {
            return 0;
        }
        ListNode* curr=head;
        while(curr->next)
        {
            curr=curr->next;
        }
        curr->next=head;
        curr=head;
        ListNode* fhead=new ListNode(0);
        ListNode* pre=fhead;
        pre->next=head;
        while(curr->next!=curr)
        {
            for(int i=0;i<k-1;i++)
            {
                pre=pre->next;
                curr=curr->next;
            }
            pre->next=curr->next;
            curr=curr->next;
        }
        return curr->val;
    }
    int josephVector(int m, int k)
    {
        if(m<=0||k<=0)
        {
            return -1;
        }
        else
        {
            if(m==1)
            {
                return 0;
            }
            else
            {
                return ((josephVector(m-1,k)+k)%m);
            }
        }
    }
    void connect(TreeLinkNode* root)
    {
        TreeLinkNode* pre=root;
        if(!root)
        {
            return;
        }
        TreeLinkNode* currh=NULL,*curr=NULL;
        while(pre)
        {
            if(pre->left)
            {
                if(!currh)
                {
                    currh=pre->left;
                    curr=currh;
                }
                else
                {
                    curr->next=pre->left;
                    curr=curr->next;
                }
            }
            if(pre->right)
            {
                if(!currh)
                {
                    currh=pre->right;
                    curr=currh;
                }
                else
                {
                    curr->next=pre->right;
                    curr=curr->next;
                    
                }
            }
            pre=pre->next;
            if(!pre)
            {
                pre=currh;
                currh=curr=NULL;
            }
        }
    }
    int firstMissingPositive(vector<int> nums)
    {
        int tmp;
        for(int i=0;i<nums.size();i++)
        {
            
            if(nums[i]>0&&nums[i]!=i)
            {
                int tmp=nums[i];
                int j=nums[i];
                while(j<nums.size()&&nums[j]!=j)
                {
                    tmp=nums[j];
                    nums[j]=j;
                    j=tmp;
                }
            }
        }
        for(int i=1;i<nums.size();i++)
        {
            if(nums[i]!=i)
            {
                return i;
            }
        }
        return nums.size();
    }
    ListNode* reverseList1(ListNode* head)
    {
        if(!head||!head->next)
        {
            return head;
        }
        else
        {
            ListNode* fhead=new ListNode(0);
            fhead->next=head;
            ListNode* curr=head;
            while(curr->next)
            {
                ListNode* tmp=curr->next->next;
                curr->next->next=fhead->next;
                fhead->next=curr->next;
                curr->next=tmp;
                
            }
            return fhead->next;
        }
        
    }
    ListNode* reverseList2(ListNode* head)
    {
        if(!head||!head->next)
        {
            return head;
        }
        else
        {
            
            ListNode* fhead=reverseList2(head->next);
            head->next->next=head;
            head->next=NULL;
            return fhead;
        }
    }
    ListNode* reverseList3(ListNode* head)
    {
        if(!head||!head->next)
        {
            return head;
        }
        else
        {
            ListNode* fhead=NULL;
            while(head)
            {
                ListNode* next=head->next;
                head->next=fhead;
                fhead=head;
                head=next;
            }
            return fhead;
        }
    }
    vector<pair<double,double> > DiffofQueue(MyQueue in1,MyQueue in2)
    {
        vector<double> tmp;
        double tmp1,tmp2;
        tmp.push_back(in2.GetNext());
        vector<pair<double,double> > res;
        while(!in1.IsEmpty())
        {
            tmp1=in1.GetNext();
            cout<<"tmp1="<<tmp1<<endl;
            
                while(tmp1-1>*tmp.begin()&&!tmp.empty())
                {
                    tmp.erase(tmp.begin());
                }
                while(!in2.IsEmpty())
                {
                    tmp2=in2.GetNext();
                    tmp.push_back(tmp2);
                    if(tmp2>tmp1+1)
                    {
                        break;
                    }
                }
                for(int i=0;i<tmp.size();i++)
                {
                    if(abs(tmp[i]-tmp1)<1)
                    {
                        res.push_back({tmp1,tmp[i]});
                    }
                }
                
            
            
            
        }
        return res;
        
    }
    string deleteSpace(string s)
    {
        stringstream ss(s);
        string word;
        string res="";
        while(ss>>word)
        {
            res+=word;
        }
        return res;
    }
    ListNode* oddEvenList(ListNode* head)
    {
        if(!head->next||!head->next->next)
        {
            return head;
        }
        ListNode* fhead=new ListNode(0);
        fhead->next=head;
        ListNode* otail=head;
        ListNode* ehead=head->next;
        ListNode* curr=head->next;
        int count=0;
        while(curr->next)
        {
            if(count%2==0)
            {
                otail->next=curr->next;
                curr->next=curr->next->next;
                otail->next->next=ehead;
                otail=otail->next;
                count++;
            }
            else if(count%2!=0)
            {
                otail->next=curr->next;
                curr->next=curr->next->next;
                otail->next->next=ehead;
                ehead=otail->next;
                count++;
            }
        }
        return fhead->next;
        
    }
    vector<vector<string>> shortestLadderLength(string beginWord, string endWord, unordered_set<string>& wordDict)
    {
        wordDict.insert(endWord);
        queue<pair<string,vector<string> > > toVisit;
        
        vector<vector<string> > res;
        addNextWords({beginWord,{beginWord}},endWord,wordDict,toVisit);
        int dist=2;
        while(!toVisit.empty())
        {
            int num=toVisit.size();
            bool flag=false;
            cout<<"dist="<<dist<<endl;
            cout<<"toVisit.size()="<<toVisit.size()<<endl;
            for(int i=0;i<num;i++)
            {
                pair<string,vector<string> > tmp=toVisit.front();
                toVisit.pop();
                cout<<tmp.first<<endl;
                if(tmp.first==endWord)
                {
                    res.push_back(tmp.second);
                    
                    flag=true;
                    
                }
                if(!flag)
                {
                    addNextWords(tmp,endWord,wordDict,toVisit);
                }
                
            }
            dist++;
            if(flag)
            {
                return res;
            }
            
            
        }
        return res;
    }
    void addNextWords(pair<string,vector<string> > wordPath,string endWord, unordered_set<string>& wordDict,queue<pair<string,vector<string> > >& toVisit)
    {
        wordDict.erase(wordPath.first);
        for(int p=0;p<(int)wordPath.first.length();p++)
        {
            char letter=wordPath.first[p];
            for(int k=0;k<26;k++)
            {
                wordPath.first[p]='a'+k;
                if(wordDict.find(wordPath.first)!=wordDict.end())
                {
                    
                    wordPath.second.push_back(wordPath.first);
                    toVisit.push(wordPath);
                    if(wordPath.first!=endWord)
                    {wordDict.erase(wordPath.first);}
                    wordPath.second.pop_back();
                }
                
            }
            
            wordPath.first[p]=letter;
            
        }
        
    }
    
    ListNode* reversePrintLinkedList(ListNode* head)
    {
        if(head&&!head->next)
        {
            return head;
        }
        ListNode* fhead=reversePrintLinkedList(head->next);
        head->next->next=head;
        head->next=NULL;
        cout<<head->val<<endl;
        return fhead;
    }
    void copystring()
    {
        char* s=(char*) malloc(10*sizeof(char));
        strcpy(s,"Hello");
        printf("%s\n",s);
    }
    bool validTree(TreeNode1* root)
    {
        return help_validTree(root);
    }
    bool help_validTree(TreeNode1* root)
    {
        if(root->visited==true)
        {
            return false;
        }
        else
        {
            root->visited=true;
            return help_validTree(root->left)&&help_validTree(root->right);
        }
    }
    vector<int >  minPathSum(TreeNode* root)//root to leaf
    {
        
        int res=INT_MAX;
        vector<int > path;
        if(!root)
        {
            return path;
        }
        vector<int> tmpp;
        
        int tmp=0;
        help_minPathSum(root, res,path,tmpp,tmp);
        
        return path;
        
    }
    void help_minPathSum(TreeNode* root, int& res, vector<int>& path,vector<int> & tmpp,int tmp)
    {
        if(!root)
        {
            if(tmp<res)
            {
                path=tmpp;
                res=tmp;
                return;
            }
            else
            {
                return;
            }
        }
        else
        {
            tmpp.push_back(root->val);
            help_minPathSum(root->left,res,path,tmpp,tmp+root->val);
            help_minPathSum(root->right,res,path,tmpp,tmp+root->val);
            tmpp.pop_back();
            return;
        }
        
        
    }
    int minPathSum1(TreeNode* root)//path doesn't need to go through root
    {
        int minval=INT_MAX;
        minToRoot(root,minval);
        return minval;
    }
    int minToRoot(TreeNode* root, int& minval)
    {
        if(!root)
        {
            return 0;
        }
        int l=minToRoot(root->left,minval);
        int r=minToRoot(root->right,minval);
        if(l>0)
        {
            l=0;
        }
        if(r>0)
        {
            r=0;
        }
        if(root->val+r+l<minval)
        {
            minval=root->val+r+l;
        }
        return root->val+=min(r,l);
    }
    int multiply_iterative(int x, int y)
    {
        int res=0, temp=0;
        if(y==0)
        {
            return 0;
        }
        bool flag=true;
        if(y<0)
        {
            flag=false;
            y=-y;
        }
        
        while(y>1)
        {
            res=res+temp;
            temp=0;
            if(y&1)
            {
                temp=x;
                x=x+x;
                y=y>>1;
                
                
            }
            else
            {
                x=x+x;
                y=y>>1;
            }
        }
        res=res+x+temp;
        return flag?res:(-res);
    }
    int multiply_recursive(int x,int y)
    {
        int res=0;
        if(y==0)
        {
            return 0;
        }
        if(y==1)
        {
            return x;
        }
        bool flag=true;
        if(y<0)
        {
            flag=false;
            y=-y;
        }
        if(y&1)
        {
            res=multiply_recursive(x+x, y>>1)+x;
        }
        else
        {
            res=multiply_recursive(x+x, y>>1);
        }
        return flag?res:(-res);
            
    
    }
    vector<vector<int> > numberPath(vector<int> nums)
    {
        unordered_map<int,int> hash;
        set<vector<int> > ress;
        vector<int>  tmp;
        queue<int> toVisit;
        for(int i=0;i<nums.size();i++)
        {
            hash[nums[i]]++;
            tmp.push_back(nums[i]);
        }
        
        
        help_numberPath(nums,ress,tmp,hash);
        return vector<vector<int> >(ress.begin(),ress.end());
    }
    void help_numberPath(vector<int> nums,set<vector<int> >& ress, vector<int> & tmp, unordered_map<int,int> & hash)
    {
        bool flag=false;
        for(int i=0;i<tmp.size()-1;i++)
        {
            for(int j=i+1;j<tmp.size();j++)
            {
                if(!hash.count(abs(tmp[i]-tmp[j])))
                {
                    tmp.push_back(abs(tmp[i]-tmp[j]));
                    hash[abs(tmp[i]-tmp[j])]++;
                    flag=true;
                    help_numberPath(nums,ress,tmp,hash);
                    tmp.pop_back();
                    hash.erase(abs(tmp[i]-tmp[j]));
                    
                }
            }
        }
        if(!flag)
        {
            ress.insert(tmp);
            return;
        }
        return;
    }
    vector<vector<int> > permutation(vector<int> nums)
    {
        vector<vector<int> > res;
        vector<int> tmp;
        
        help_permutation(res,0,nums);
        return res;
    }
    void help_permutation(vector<vector<int> > &res, int begin, vector<int>& nums)
    {
       if(begin>=nums.size())
       {
           res.push_back(nums);
           return;
       }
        for(int i=begin;i<nums.size();i++)
        {
            swap(nums[begin],nums[i]);
            help_permutation(res, begin+1, nums);
            swap(nums[begin],nums[i]);
        }
    }
    vector<int> shortestPath(TreeNode* root,TreeNode* p1,TreeNode* p2)
    {
        vector<int> res,path1,path2;
        bool findp1=false,findp2=false,flag=false;
        TreeNode* lowest=help_shortestPath(root, p1, p2, path1, path2,flag);
        vector<int> tmp;
        path1.clear();
        path2.clear();
        //cout<<lowest->val<<endl;
        help2_shortestPath(lowest,p1,path1,tmp);
        for(auto num:tmp)
        {
            cout<<num<<" ";
        }
        cout<<endl;
        reverse(tmp.begin(),tmp.end());
        res.insert(res.begin(),tmp.begin(),tmp.end());
        res.pop_back();
        help2_shortestPath(lowest,p2,path2,tmp);
        res.insert(res.end(),tmp.begin(),tmp.end());
        
        return res;
    }
    void help1_shortestPath(TreeNode* root,TreeNode* p1,TreeNode* p2,stack<int>& path)
    {
        if(!root)
        {
            return;
        }
        if(root==p1||root==p2)
        {
            path.push(root->val);
            return;
        }
        
        help1_shortestPath(root->left,p1,p2,path);
        help1_shortestPath(root->right,p1,p2,path);
        path.push(root->val);
        return;
    }
    TreeNode* help_shortestPath(TreeNode* root,TreeNode* p1, TreeNode* p2,vector<int>& path1,vector<int>& path2,bool & flag)
    {
        if(!root)
        {
            return root;
        }
        if(root==p1)
        {
            path1.push_back(p1->val);
            
            TreeNode* left=help_shortestPath(root->left, p1, p2,path1,path2,flag);
            TreeNode* right=help_shortestPath(root->right, p1, p2,path1,path2,flag);
            return root;
        }
        if(root==p2)
        {
            
            path2.push_back(p2->val);
            TreeNode* left=help_shortestPath(root->left, p1, p2,path1,path2,flag);
            TreeNode* right=help_shortestPath(root->right, p1, p2,path1,path2,flag);
            return root;
        }
        TreeNode* left=help_shortestPath(root->left, p1, p2,path1,path2,flag);
        TreeNode* right=help_shortestPath(root->right, p1, p2,path1,path2,flag);
        
        if(!left)
        {
            
            if(right==p1&&root!=p2)
            {
                path1.push_back(root->val);
            }
            if(right==p2&&root!=p1)
            {
                path2.push_back(root->val);
            }
            
            
            return right;
        }
        else
        {
            if(!right)
            {
                if(left==p1&&root!=p2)
                {
                    path1.push_back(root->val);
                }
                if(left==p2&&root!=p1)
                {
                    path2.push_back(root->val);
                }
                return left;
            }
            else
            {
                path1.push_back(root->val);
                return root;
            }
        }
    }
    void help2_shortestPath(TreeNode* root, TreeNode* target,vector<int> path,vector<int>& tmp)
    {
        if(root==target)
        {
            path.push_back(root->val);
            tmp=path;
            return;
        }
        else
            
        {
            path.push_back(root->val);
            if(root->left)
            {
                //path.push_back(root->left->val);
                help2_shortestPath(root->left,target,path,tmp);
                //path.pop_back();
            }
            if(root->right)
            {
                //path.push_back(root->right->val);
                help2_shortestPath(root->right, target, path, tmp);
                //path.pop_back();
            }
            path.pop_back();
        }
        
    }
    int largestCluster(vector<vector<int> >& matrix)
    {
        int res=0;
        for(int i=0;i<matrix.size();i++)
        {
            for(int j=0;j<matrix[0].size();j++)
            {
                if(matrix[i][j]==1)
                {
                    int tmp=0;
                    help_largestCluster(tmp,i,j,matrix);
                    res=max(res,tmp);
                }
            }
        }
        return res;
    }
    void help_largestCluster(int& tmp,int i, int j, vector<vector<int> >& matrix)
    {
        tmp++;
        matrix[i][j]=-1;
        vector<vector<int> > dirs={{0,1},{0,-1},{1,0},{-1,0}};
        for(auto dir:dirs)
        {
            int ii=i+dir[0];
            int jj=j+dir[1];
            if(ii>=0&&ii<matrix.size()&&jj>=0&&jj<matrix[0].size()&&matrix[ii][jj]==1)
            {
                help_largestCluster(tmp, ii, jj, matrix);
            }
        }
    }
    vector<int> findParents(vector<TreeNode*> tree, TreeNode* pt)
    {
        unordered_map<TreeNode*,TreeNode*> parent;
        unordered_map<TreeNode*, vector<TreeNode*> > children;
        for(int i=0;i<tree.size();i++)
        {
            if(tree[i]->left)
            {
                children[tree[i]].push_back(tree[i]->left);
                parent[tree[i]->left]=tree[i];
            }
            if(tree[i]->right)
            {
                children[tree[i]].push_back(tree[i]->right);
                parent[tree[i]->right]=tree[i];
            }
            
        }
        vector<int> res;
        help_findParents(pt,res,parent);
        queue<TreeNode*> toVisit;
        for(int i=0;i<children[pt].size();i++)
        {
            toVisit.push(children[pt][i]);
            
        }
        vector<int> res1;
        help_findChildren( res1,toVisit, children);
        for(auto out:res1)
        {
            cout<<out<<" ";
        }
        return res;
        
    }
    void help_findParents(TreeNode* pt, vector<int>& res,unordered_map<TreeNode*, TreeNode*> parent)
    {
        
        if(!parent.count(pt))
        {
            return;
        }
        else
        {
            res.push_back(parent[pt]->val);
            help_findParents(parent[pt],res,parent);
        }
        
    }
    void help_findChildren(vector<int>& res1,queue<TreeNode*>& toVisit, unordered_map<TreeNode*,vector<TreeNode*> > children)
    {
        if(toVisit.empty())
        {
            return;
        }
        else
        {
            int size=toVisit.size();
            for(int i=0;i<size;i++)
            {
                TreeNode* tmp=toVisit.front();
                toVisit.pop();
                res1.push_back(tmp->val);
                for(int j=0;j<children[tmp].size();j++)
                {
                    toVisit.push(children[tmp][j]);
                }
            }
            help_findChildren(res1, toVisit, children);
        }
            
        
    }
    int findPaths(vector<vector<int> >matrix)//up to down
    {
        vector<vector<int> > res(matrix.size(),vector<int>(matrix[0].size(),0));
        for(int i=0;i<matrix.size();i++)
        {
            if(matrix[i][0]==1)
            {
                res[i][0]=1;
            }
            else
            {
                break;
            }
        }
        for(int i=0;i<matrix[0].size();i++)
        {
            if(matrix[0][i]==1)
            {
                res[0][i]=1;
            }
            else
            {
                break;
            }
        }
        for(int i=1;i<matrix.size();i++)
            
        {
            for(int j=1;j<matrix[0].size();j++)
            {
                if(matrix[i][j]==1)
                {
                    res[i][j]=res[i-1][j]+res[i][j-1];
                }
            }
        }
        return res[matrix.size()-1][matrix[0].size()-1];
    }
    int findPaths2(vector<vector<int> >matrix)//any direction
    {
        int res=0;
        int m=matrix.size();
        int n=matrix[0].size();
        
        vector<vector<pair<int,int> > > paths;
        vector<pair<int,int> > path;
        help_findPaths2(0,0,m,n,res,matrix,paths,path);
        for(auto p:paths)
        {
            for(auto d:p)
            {
                cout<<d.first<<"+"<<d.second<<" ";
            }
            cout<<endl;
        }
        return res;
    }
    void help_findPaths2(int i,int j,int m,int n,int& res,vector<vector<int> >& matrix,vector<vector<pair<int,int> > >& paths,vector<pair<int,int> >& path)
    {
        if(i==m-1&&j==n-1)
        {
            res++;
            
            paths.push_back(path);
            return;
        }
        else
        {
            vector<vector<int> > dirs={{0,1},{0,-1},{1,0},{-1,0}};
            path.push_back({i,j});
            matrix[i][j]=-1;
            for(auto dir:dirs)
            {
                int ii=i+dir[0];
                int jj=j+dir[1];
                if(ii>=0&&ii<m&&jj>=0&&jj<n&&matrix[ii][jj]==1)
                {
                    help_findPaths2(ii,jj,m,n,res,matrix,paths,path);
                }
            }
            matrix[i][j]=1;
            path.pop_back();
        }
        
    }
    string frequenceString(string s)
    {
        string res="";
        unordered_map<char,pair<int,int> > hash;
        priority_queue<unordered_map<char,pair<int,int> >::iterator,vector<unordered_map<char,pair<int,int> >::iterator>, Mycomparision> q;
        for(int i=0;i<s.size();i++)
        {
            if(!hash.count(s[i]))
            {
                hash[s[i]].first++;
                hash[s[i]].second=i;
            }
            else
            {
                hash[s[i]].first++;
            }
            
        }
        cout<<s.size()<<endl;
        cout<<hash.size()<<endl;
        for(auto it=hash.begin();it!=hash.end();it++)
        {
            //cout<<it->first<<"+"<<it->second.second<<endl;
            q.push(it);
        }
        while(!q.empty())
        {
            string tmp(q.top()->second.first,q.top()->first);
            //cout<<tmp<<endl;
            res=res+tmp;
            q.pop();
        }
        return res;
        
    }
    void sortVersion(vector<Version>& versions)
    {
        vector<Version> res;
        for(int i=0;i<versions.size();i++)
        {
            for(int j=i+1;j<versions.size();j++)
            {
                if(versions[j]<versions[i])
                {
                    swap(versions[i],versions[j]);
                }
            }
        }
        return ;
    }
    void deleteSpace2(string& s)
    {
        int count=0;
        bool flag=false;
        for(int i=0;i<s.size();i++)
        {
            if(s[i]!=' ')
            {
                s[count]=s[i];
                count++;
                flag=false;
            }
            else
            {
                if(flag==false)
                {   s[count]=' ';
                    count++;
                    flag=true;
                }
                else
                {
                    continue;
                }
            }
        }
        s.resize(count);
        return;
    }
    void preKMP(string pattern)
    {
        int m=pattern.size(),k;
        vector<int> f(m,0);
        f[0]=-1;
        for(int i=1;i<m;i++)
        {
            k=f[i-1];
            while(k>=0)
            {
                if(pattern[k]==pattern[i-1])
                {
                    break;
                }
                else
                {
                    k=f[k];
                }
            }
            f[i]=k+1;
        }
        for(auto num:f)
        {
            cout<<num<<" ";
        }
    }
    vector<int> longestSuccessive(vector<int> nums)
    {
        sort(nums.begin(),nums.end());
        for(auto num:nums)
        {
            cout<<num<<" ";
        }
        cout<<endl;
        int maxval=0;
        int count=0;
        int start=0;
        for(int i=0;i<nums.size()-1;)
        {
            int startval=nums[i];
            int j;
            for(j=i+1;j<nums.size();)
            {
                while(nums[j]==nums[j-1])
                {
                    //cout<<"j'="<<j<<endl;
                    j++;
                }
                if(nums[j]==startval+1)
                {
                    startval=nums[j];
                    //cout<<"j="<<j<<endl;
                    j++;
                    
                    //cout<<"startval="<<startval<<endl;
                    
                    count++;
                }
                else
                {
                    //cout<<"j="<<j<<endl;
                    if(count>maxval)
                    {
                        start=i;
                        maxval=count;
                    }
                    break;
                }
                
            }
            i=j;
            //cout<<"nums[i]="<<nums[i]<<endl;
        }
        //cout<<"maxval="<<maxval<<endl;
        vector<int> result;
        for(int i=start;nums[i]<=nums[start]+maxval;i++)
        {
            result.push_back(nums[i]);
        }
        return result;
    }
    
    vector<int> lexicographicalOrderPrintN(int n)
    {
        vector<int> res;
        for(int i=1;i<=9;i++)
        {
            if(i<=n)
            {
                help_lexicographicalOrderPrintN(res,i,n);
            }
        }
        return res;
    }
    void help_lexicographicalOrderPrintN(vector<int>& res,int i, int n)
    {
        if(i<n)
        {
            res.push_back(i);
            for(int j=0;j<=9;j++)
            {
                help_lexicographicalOrderPrintN(res,i*10+j,n);
            }
        }
        else
        {
            return;
        }
    }
    pair<int,int>  TwoSumofBST(TreeNode* root,int target)
    {
        TreeNode* right=root;
        TreeNode* left=root;
        stack<TreeNode*> rightT;
        stack<TreeNode*> leftT;
        while((right==root&&left==root)||right!=left)
        {
            while(left)
            {
                leftT.push(left);
                left=left->left;
                //cout<<"left->val="<<left->val<<endl;
            }
            left=leftT.top();
            leftT.pop();
            
            while(right)
            {
                rightT.push(right);
                right=right->right;
            }
            right=rightT.top();
            rightT.pop();
            cout<<"right->val="<<right->val<<endl;
            if(left->val+right->val==target)
            {
                return {left->val,right->val};
            }
            else if(left->val+right->val>target)
            {
                right=right->left;
                continue;
            }
            else
            {
                left=left->right;
                continue;
            }
        }
        return {left->val,right->val};
    }
    
    
};
int main(int argc, const char * argv[]) {
    Solution sol;

//    ListNode* in1=new ListNode(0);
//    ListNode* curr=in1;
//    
//    vector<int> inv={1,2,3,4,5,6,4,3,9,1};
//    for(int i=0;i<inv.size();i++)
//    {
//        curr->next=new ListNode(inv[i]);
//        curr=curr->next;
//    }
//    curr=in1->next;
//    ListNode* out=sol.reverseList2(curr);
//    while(out)
//    {
//        cout<<out->val<<endl;
//        out=out->next;
//    }
//    ListNode* head=in1->next;
//        bool out1=sol.palindromeLinkedlist2(head,curr);
//    if(out1)
//    {
//        cout<<"right"<<endl;
//    }
//    else
//    {
//        cout<<"wrong"<<endl;
//    }
    
//    string in2="1223567744499";
//    
//    string out2=sol.removeDuplicate(in2);
//    cout<<out2<<endl;
//    cout<<out2.size()<<endl;
//    vector<int> out3=sol.prime(100);
//    for(auto out:out3)
//    {
//        cout<<out<<" ";
//    }
//
//    int out41=sol.trailingZeroes(289);
//    int out42=sol.tralingZeroes2(289);
//    cout<<out41<<endl;
//    cout<<out42<<endl;
//    double out5=sol.squareRoot(0.02);
//    cout<<out5<<endl;
//    string out6=sol.wordCompression("ababcbaacb");
//    cout<<out6<<endl;
//    string in7="the sky is blue";
//    string out7=sol.resverseSentence(in7);
//    cout<<out7<<endl;
//    GraphNode* A=new GraphNode('a');
//    GraphNode* B=new GraphNode('b');
//    GraphNode* C=new GraphNode('c');
//    GraphNode* D=new GraphNode('d');
//    GraphNode* E=new GraphNode('d');
//    GraphNode* F=new GraphNode('f');
//    GraphNode* G=new GraphNode('g');
//    GraphNode* H=new GraphNode('h');
//    GraphNode* I=new GraphNode('i');
//    GraphNode* J=new GraphNode('j');
//    A->next={{B,5},{C,2}};
//    B->next={{D,3},{J,1}};
//    C->next={{E,1},{F,4},{G,7}};
//    F->next={{H,2}};
//    H->next={{I,1}};
//    vector<GraphNode*> out8=sol.closeFriend(A, 4, 6);
//    for(auto out:out8)
//    {
//        cout<<out->val<<" ";
//    }
//    vector<int> in8={6,2,8,0,7,1,4,3,5,INT_MIN};
//    sol.inplaceSort(in8);
//    for(auto out:in8)
//    {
//        cout<<out<<" ";
//    }
//    ListNode* in9=new ListNode(0);
//    ListNode* in9t=in9;
//    for(int i=1;i<11;i++)
//    {
//        in9t->next=new ListNode(i);
//        in9t=in9t->next;
//    }
//    ListNode* out9=sol.reversePrintLinkedList(in9->next);
//    cout<<sol.josephLinkedList(in9->next, 4);
//    MyQueue in101;
//    in101.q.push(0.7);
//    in101.q.push(1.2);
//    in101.q.push(3.0);
//    MyQueue in102;
//    in102.q.push(1.4);
//    in102.q.push(1.5);
//    in102.q.push(3.5);
//    vector<pair<double,double> > out10=sol.DiffofQueue(in101,in102);
//    for(auto p:out10)
//    {
//        cout<<p.first<<", "<<p.second<<endl;
//    }
//    string in11="I put into it.";
//    cout<<sol.deleteSpace(in11)<<endl;
//    ListNode* in12=new ListNode(0);
//    ListNode* in12t=in12;
//    for(int i=1;i<10;i++)
//    {
//        in12t->next=new ListNode(i);
//        in12t=in12t->next;
//    }
//    ListNode* out12=sol.oddEvenList(in12->next);
//    while(out12)
//    {
//        cout<<out12->val<<" ";
//        out12=out12->next;
//    }
//    string in131="red";
//    string in132="tax";
//    unordered_set<string> in133={{"ted","tex","red","tax","tad","den","rex","pee"}};
//    vector<vector<string> > out13=sol.shortestLadderLength(in131, in132, in133);
//    for(int i=0;i<out13.size();i++)
//    {
//        for(int j=0;j<out13[i].size();j++)
//        {
//            cout<<out13[i][j]<<", ";
//        }
//        cout<<endl;
//    }
//    sol.copystring();
//    TreeNode* in14=new TreeNode(1);
//    in14->left=new TreeNode(-3);
//    in14->right=new TreeNode(5);
//    in14->left->left=new TreeNode(-18);
//    in14->left->right=new TreeNode(6);
//    in14->left->right->left=new TreeNode(-10);
//    in14->right->left=new TreeNode(-8);
//    in14->right->right=new TreeNode(9);
//    vector<int > out14=sol.minPathSum(in14);
//    for(auto v:out14)
//    {
//        
//        cout<<v<<" ";
//    }
//    int out15=sol.minPathSum1(in14);
//    cout<<out15<<endl;
//    cout<<sol.multiply_recursive(6, 6);
//    vector<int> in16={30,5};
//    vector<vector<int> > out16=sol.numberPath(in16);
//    for(auto out:out16)
//    {
//        for(auto n:out)
//        {
//            cout<<n<<" ";
//        }
//        cout<<endl;
//    }
//    vector<vector<int> > in17={{0,0,1,0,0,0,1},{0,1,1,0,0,1,1},{0,0,0,0,0,1,1},{0,0,1,0,0,1,0}};
//    int out17=sol.largestCluster(in17);
//    cout<<out17<<endl;
//    TreeNode* in18=new TreeNode(1);
//    in18->left=new TreeNode(2);
//    in18->right=new TreeNode(3);
//    in18->left->left=new TreeNode(4);
//    in18->left->right=new TreeNode(5);
//    in18->right->left=new TreeNode(6);
//    in18->right->right=new TreeNode(7);
//    in18->right->right->left=new TreeNode(8);
//    in18->right->right->right=new TreeNode(9);
//    in18->right->right->right->left=new TreeNode(10);
//    vector<TreeNode*> in181={in18,in18->left,in18->right,in18->left->left,in18->left->right,in18->right->left,in18->right->right,in18->right->right->left,in18->right->right->right,in18->right->right->right->left};
//    vector<int> out18=sol.findParents(in181, in18->right);
    
//    vector<vector<int> > in19={{1,1,0,0,1},{0,1,1,1,1},{0,1,0,1,1},{1,1,1,1,1}};
//    int out19=sol.findPaths(in19);
//    cout<<out19<<endl;
//    int out20=sol.findPaths2(in19);
//    cout<<out20<<endl;
//    string in21="BBBCADDDD";
//    string out21=sol.frequenceString(in21);
//    cout<<out21<<endl;
//    return 0;
//    int out=sol.josephVector(10, 2);
////    cout<<out<<endl;
//    Version in221("1.1");
//    Version in222("1.1.5");
//    Version in223("12.0");
//    Version in224("1.23");
//    Version in225("12.3");
//    vector<Version> in22={in221,in222,in223,in224,in225};
//    sol.sortVersion(in22);
//    for(auto out:in22)
//    {
//        cout<<out.ver<<endl;
//    }
//    string in23="I  love       New    York    City!";
//    sol.deleteSpace2(in23);
//    cout<<in23<<endl;
//    sol.preKMP("abcabdabcabcf");
//    vector<int> in24={2,1,5,2,3,9,4,4,6,6,6};
//    vector<int> out24=sol.longestSuccessive(in24);
//    for(auto out:out24)
//    {
//        cout<<out<<" "<<endl;
//    }
//    vector<int> out25=sol.lexicographicalOrderPrintN(125);
//    for(auto out:out25)
//    {
//        cout<<out<<" ";
//    }
    TreeNode* in26=new TreeNode(10);
    in26->left=new TreeNode(5);
    in26->right=new TreeNode(15);
    in26->left->left=new TreeNode(3);
    in26->left->right=new TreeNode(8);
    in26->left->left->right=new TreeNode(4);
    in26->left->right->left=new TreeNode(6);
    in26->left->right->right=new TreeNode(9);
    in26->right->left=new TreeNode(13);
    in26->right->left->left=new TreeNode(12);
    in26->right->left->right=new TreeNode(14);
    in26->right->right=new TreeNode(17);
    pair<int,int> out26=sol.TwoSumofBST(in26, 18);
    cout<<out26.first<<" "<<out26.second<<endl;
    
}