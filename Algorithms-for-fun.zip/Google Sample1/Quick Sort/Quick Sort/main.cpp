//
//  main.cpp
//  Quick Sort
//
//  Created by yangjingyi on 6/30/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int partition(vector<int>& nums, int left, int right)
    {
        int pivot=nums[left];
        int l=left+1;
        int r=right;
        while(r>=l)
        {
            if(nums[l]>pivot&&nums[r]<pivot)
            {
                swap(nums[l++],nums[r--]);
            }
            if(nums[l]<=pivot)
            {
                l++;
            }
            if(nums[r]>=pivot)
            {
                r--;
            }
        }
        swap(nums[left],nums[l-1]);
        return r;
    }
    void quicksort(vector<int>& nums,int left,int right)
    {
        int l=left,r=right;
        int pos=partition(nums,l,r);
        if(l<pos)
        {
            quicksort(nums,l,pos-1);
        }
        if(r>pos)
        {
            quicksort(nums,pos+1,r);
        }
        return;
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in1={1,2,5,7,3,4,9,8,11,6};
    Solution sol;
    sol.quicksort(in1, 0, in1.size()-1);
   
    cout<<"vector"<<endl;
    for(auto n:in1)
    {
        cout<<n<<" ";
    }
    return 0;
}
