//
//  main.cpp
//  Range Addition
//
//  Created by yangjingyi on 7/7/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<int>  rangeAddition(int length,vector<vector<int> > op)
    {
        vector<int> res(length+1,0);
        
        for(int i=0;i<op.size();i++)
        {
            res[op[i][0]]+=op[i][2];
            res[op[i][1]+1]-=op[i][2];
        }
        for(int i=1;i<length;i++)
        {
            res[i]=res[i]+res[i-1];
        }
        res.resize(length);
        return res;
    }
};

int main(int argc, const char * argv[]) {
    Solution sol;
    vector<vector<int> > in={{1,3,2},{2,4,3},{0,2,-2}};
    vector<int> out=sol.rangeAddition(5, in);
    for(auto n:out)
    {
        cout<<n<<" ";
    }
    return 0;
}
