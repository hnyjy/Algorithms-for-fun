//
//  main.cpp
//  Range Maximum Query
//
//  Created by yangjingyi on 4/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>
using namespace std;
class Solution
{
public:
    struct result
    {
        int p1=0;
        int p2=0;
        int maxval=INT_MIN;
        
        
    };
    result rangeMaximumQuery(vector<int>& num)
    {
        result re;
        int count;
        //re.maxval=num[0];
        count=0;
        int tmp1=0;
        int tmp2=0;
        for(int i=0;i<num.size();i++)
        {
            if(count<0)
            {
                count=num[i];
                tmp1=i;
                tmp2=i;
                if(count>re.maxval)
                {
                    re.maxval=count;
                    re.p1=tmp1;
                    re.p2=tmp2;
                }
            }
            else
            {
                count=count+num[i];
                tmp2=i;
                if(count>re.maxval)
                {
                    re.p1=tmp1;
                    re.maxval=count;
                    re.p2=tmp2;
                }
            }
        }
        return re;
    }
    
};

int main(int argc, const char * argv[]) {
    vector<int> in={3,-8,2,10,2,-4,5};
    Solution a;
    Solution::result re=a.rangeMaximumQuery(in);
    cout<<re.maxval<<endl;
    cout<<re.p1<<endl;
    cout<<re.p2<<endl;
    return 0;
}
