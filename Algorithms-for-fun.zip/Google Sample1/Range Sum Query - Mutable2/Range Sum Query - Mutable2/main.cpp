//
//  main.cpp
//  Range Sum Query - Mutable2
//
//  Created by yangjingyi on 4/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class NumArray
{
public:
    vector<int> tree;
    vector<int> tmp;
    
    int m;
    NumArray(vector<int> & nums)
    {
        if(nums.size()==0)
        {
            return;
        }
        m=nums.size();
        tree.resize(m+1,0);
        tmp.resize(m,0);
        for(int i=0;i<nums.size();i++)
        {
            update(i,nums[i]);
        }
        
    }
    void update(int i,int val)
    {
        if(m==0)
        {
            return;
        }
        int delta=val-tmp[i];
        tmp[i]=val;
        for(int x=i+1;x<=m;x+=x&(-x))
        {
            tree[x]+=delta;
        }
    }
    int sum1(int i)
    {
        if(m==0)
        {
            return 0;
        }
        int sum=0;
        for(int x=i;x>0;x-=x&(-x))
        {
            sum+=tree[x];
        }
        return sum;
    }
    int sumRange(int i,int j)
    {
        for(auto t:tree)
        {
            cout<<t<<","<<endl;
        }
        
        return sum1(j+1)-sum1(i);
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in={1,3,5,7};
    NumArray x(in);
    cout<<x.sumRange(0,2)<<endl;
    cout<<x.sum1(0)<<endl;
    cout<<x.sum1(2)<<endl;
    return 0;
}
