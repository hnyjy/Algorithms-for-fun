//
//  main.cpp
//  Range Sum Query 2D - Mutable
//
//  Created by yangjingyi on 4/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class NumMatrix
{
public:
    vector<vector<int> >tree;
    vector<vector<int> > nums;
    int m;
    int n;
    NumMatrix(vector<vector<int> > matrix)
    {
        if(matrix.size()==0||matrix[0].size()==0)
        {
            return;
        }
        m=matrix.size();
        n=matrix[0].size();
        tree.resize(m+1,vector<int>(n+1,0));
        nums.resize(m,vector<int>(n,0));
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<n;j++)
            {
                update(i,j,matrix[i][j]);
            }
        }
    }
    void update(int row, int col, int val)
    {
        if(m==0||n==0)
        {
            return ;
        }
        int delta=val-nums[row][col];
        nums[row][col]=val;
        for(int i=row+1;i<=m;i+=i&(-i))
        {
            for(int j=col+1;j<=n;j+=j&(-j))
            {
                tree[i][j]+=delta;
            }
        }
    }
    int sum(int row, int col)
    {
        int sum=0;
        for(int i=row;i>0;i-=i&(-i))
        {
            for(int j=col;j>0;j-=j&(-j))
            {
                sum+=tree[i][j];
            }
        }
        return sum;
    }

    int sumRegion(int row1, int col1,int row2,int col2)
    {
        if(m==0||n==0)
        {
            return 0;
        }
        return sum(row2+1,col2+1)+sum(row1,col1)-sum(row2,col1)-sum(row1,col2);
    }
};

int main(int argc, const char * argv[]) {
    
    
    return 0;
}
