//
//  main.cpp
//  Rearrange String k Distance Apart
//
//  Created by yangjingyi on 7/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <queue>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
    string rearrangeString(string str, int k)
    {
        if(k==0)
        {
            return str;
        }
        int length=(int)str.size();
        string res;
        unordered_map<char,int> dict;
        priority_queue<pair<int,char> > pq;
        for(char ch:str)
        {
            dict[ch]++;
        }
        for(auto it=dict.begin();it!=dict.end();it++)
        {
            pq.push(make_pair(it->second,it->first));
        }
        while(!pq.empty())
        {
            vector<pair<int,char> > cache;
            int count=min(k,length);
            for(int i=0;i<count;i++)
            {
                if(pq.empty())
                {
                    return "";
                }
                auto tmp=pq.top();
                pq.pop();
                res.push_back(tmp.second);
                if(--tmp.first>0)
                {
                    cache.push_back(tmp);
                }
                length--;
            }
            for(auto p:cache)
            {
                pq.push(p);
            }
        }
        return res;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
