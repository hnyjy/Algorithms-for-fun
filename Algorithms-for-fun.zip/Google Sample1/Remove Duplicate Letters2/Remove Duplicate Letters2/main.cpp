//
//  main.cpp
//  Remove Duplicate Letters2
//
//  Created by yangjingyi on 4/10/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    string removeDuplicateLetters(string s)
    {
        vector<int> cand(256,0);
        for(char c:s)
        {
            cand[c]++;
        }
        string result="0";
        for(char c:s)
        {
            if(cand[c]<0)
            {
                cand[c]++;
                continue;
                //cout<<"right"<<endl;
            }
            cand[c]--;
            while(cand[result.back()]<0&&c<result.back())
            {
                //cout<<"right"<<endl;
                cand[result.back()]=-cand[result.back()];

                result.pop_back();
                                
            }
            //cout<<c<<endl;
            result+=c;
            cand[c]=-cand[c];
            //cout<<cand[c]<<endl;
        }
        return result.substr(1);
    }
};

int main(int argc, const char * argv[]) {
    string in="bcabc";
    Solution a;
    string out=a.removeDuplicateLetters(in);
    cout<<out;
    return 0;
}
