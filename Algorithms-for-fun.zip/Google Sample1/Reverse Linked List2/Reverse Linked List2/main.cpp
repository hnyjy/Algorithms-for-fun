//
//  main.cpp
//  Reverse Linked List2
//
//  Created by yangjingyi on 6/30/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <stack>
using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
};
class Solution
{
public:
    ListNode* reverseList(ListNode* head)
    {
        if(!head)
        {
            return head;
        }
        stack<ListNode*> q;
        while(head)
        {
            q.push(head);
            head=head->next;
        }
        ListNode* fhead=new ListNode(0);
        ListNode* curr=fhead;
        while(!q.empty())
        {
            curr->next=new ListNode(q.top()->val);
            q.pop();
            curr=curr->next;
        }
        return fhead->next;
    }
};

int main(int argc, const char * argv[]) {
    Solution sol;
    ListNode* in1=new ListNode(1);
    in1->next=new ListNode(2);
    in1->next->next=new ListNode(3);
    ListNode* out1=sol.reverseList(in1);
    while(out1)
    {
        cout<<out1->val<<endl;
        out1=out1->next;
    }
    return 0;
}
