//
//  main.cpp
//  Reverse String
//
//  Created by yangjingyi on 7/3/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    string reverseString(string s)
    {
        int l=0, r=s.size()-1;
        while(r>=l)
        {
            char tmp=s[l];
            s[l]=s[r];
            s[r]=tmp;
            r--;
            l++;
        }
        return s;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
