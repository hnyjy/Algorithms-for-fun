//
//  main.cpp
//  Reverse Vowels of a String
//
//  Created by yangjingyi on 7/3/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution {
public:
    string reverseVowels(string s) {
        int i = 0, j = s.size() - 1;
        bool Isvowel[300];
        memset(Isvowel, 0, 300);
        Isvowel['A'] = true;
        Isvowel['E'] = true;
        Isvowel['I'] = true;
        Isvowel['O'] = true;
        Isvowel['U'] = true;
        Isvowel['a'] = true;
        Isvowel['e'] = true;
        Isvowel['i'] = true;
        Isvowel['o'] = true;
        Isvowel['u'] = true;
        while (i < j)
        {
            while (!Isvowel[s[i]] && i < j) i++;
            while (!Isvowel[s[j]] && i < j) j--;
            if (i < j)
                swap(s[i++],s[j--]);
        }
        return s;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
