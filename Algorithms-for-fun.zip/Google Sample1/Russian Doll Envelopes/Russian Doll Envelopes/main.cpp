//
//  main.cpp
//  Russian Doll Envelopes
//
//  Created by yangjingyi on 7/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    static bool cmp_first(const pair<int,int>& i, const pair<int,int>& j)
    {
        if(i.first==j.first)
        {
            return i.second>j.second;
        }
        else
        {
            return i.first<j.first;
        }
    }
    int maxEnvelops(vector<pair<int,int> >& envelopes)
    {
        
        sort(envelopes.begin(),envelopes.end(),cmp_first);
        vector<int> dp;
        for(int i=0;i<envelopes.size();i++)
        {
            auto itr=lower_bound(dp.begin(),dp.end(),envelopes[i].second);
            if(itr==dp.end())
            {
                dp.push_back(envelopes[i].second);
            }
            else
            {
                *itr=envelopes[i].second;
            }
        }
        return dp.size();
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
