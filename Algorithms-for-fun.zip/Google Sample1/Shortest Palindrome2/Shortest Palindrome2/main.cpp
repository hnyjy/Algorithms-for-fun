//
//  main.cpp
//  Shortest Palindrome2
//
//  Created by yangjingyi on 7/20/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    string shortestPalindrome(string s)
    {
        int n=s.size();
        if(n==0)
        {
            return s;
        }
        int i=n;
        string v=s;
        reverse(v.begin(),v.end());
        for(;i>=1;--i)
        {
            if(s.substr(0,i)==v.substr(n-i))
            {
                break;
            }
        }
        for(;i<s.size();i+=2)
        {
            s=s[i]+s;
            
        }
        return s;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
