//
//  main.cpp
//  Shortest Word DistanceII2
//
//  Created by yangjingyi on 3/21/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <climits>
using namespace std;
class WordDistance
{
public:
    WordDistance(vector<string>& words)
    {
        for(int i=0;i<words.size();i++)
        {
            wordInd[words[i]].push_back(i);
        }
    }
    int shortest(string word1, string word2)
    {
        vector<int> indexes1=wordInd[word1];
        vector<int> indexes2=wordInd[word2];
        int i=0,j=0,dist=INT_MAX;
        while(i<indexes1.size()&&j<indexes2.size())
        {
            dist=min(dist,abs(indexes1[i]-indexes2[j]));
            if(indexes1[i]<indexes2[j])
            {
                i++;
            }
            else
            {
                j++;
            }
        }
        return dist;
        
    }
private:
    unordered_map<string, vector<int> >wordInd;
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
