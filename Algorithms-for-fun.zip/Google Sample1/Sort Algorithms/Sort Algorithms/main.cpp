//
//  main.cpp
//  Sort Algorithms
//
//  Created by yangjingyi on 7/19/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Sort
{
public:
    void mergeSort(vector<int>& nums,int low,int high)
    {
        int mid;
        if(low<high)
        {
            mid=(low+high)/2;
            mergeSort(nums,low,mid);
            
            mergeSort(nums,mid+1,high);
            help_mergeSort(nums,low,high,mid);
        }
        return;
    }
    void help_mergeSort(vector<int>& nums,int low,int high, int mid)
    {
        vector<int> tmp;
        int i=low;
        int j=mid+1;
        int k=low;
//        cout<<"low="<<low<<endl;
//        cout<<"high="<<high<<endl;
//        cout<<"mid="<<mid<<endl;
        while(i<=mid&&j<=high)
        {
            if(nums[i]<=nums[j])
            {
                tmp.push_back(nums[i]);
                i++;
                k++;
            }
            else
            {
                tmp.push_back(nums[j]);
                j++;
                k++;
            }
        }
        while(i<=mid)
        {
            tmp.push_back(nums[i]);
            i++;
            k++;
        }
        while(j<=high)
        {
            tmp.push_back(nums[j]);
            j++;
            k++;
        }
        
        for(i=low,j=0;i<k;i++,j++)
        {
            //cout<<"tmp[i]="<<tmp[i]<<endl;
            nums[i]=tmp[j];
        }
//        for(auto num:tmp)
//        {
//            cout<<num<<" ";
//        }
        //cout<<endl;
        return;
        
    }
};

int main(int argc, const char * argv[]) {
    Sort sol;
    vector<int> in1={1,5,2,9,14,6,8};
    sol.mergeSort(in1,0,in1.size()-1);
    for(auto out:in1)
    {
        cout<<out<<" ";
    }
    return 0;
}
