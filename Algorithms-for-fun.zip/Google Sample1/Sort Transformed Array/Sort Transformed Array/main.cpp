//
//  main.cpp
//  Sort Transformed Array
//
//  Created by yangjingyi on 7/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<int> sortTransformedArray(vector<int> num, int a, int b, int c)
    {
        int n=num.size();
        vector<int> sorted(n);
        int i=0,j=n-1;
        int index=a>=0?n-1:0;
        while(i<=j)
        {
            if(a>=0)
            {
                sorted[index--]=quad(num[i],a,b,c)>=quad(num[j],a,b,c)?quad(num[i++],a,b,c):quad(num[j++],a,b,c);
                
            }
            else
            {
                sorted[index++]=quad(num[i],a,b,c)>=quad(num[j],a,b,c)?quad(num[j--],a,b,c):quad(num[i--],a,b,c);
            }
        }
        return sorted;
    }
    int quad(int x, int a, int b, int c)
    {
        return a*x*x+b*x+c;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
