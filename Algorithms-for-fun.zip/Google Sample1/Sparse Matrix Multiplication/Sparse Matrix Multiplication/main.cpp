//
//  main.cpp
//  Sparse Matrix Multiplication
//
//  Created by yangjingyi on 7/8/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<vector<int> > multiply(vector<vector<int> >& A, vector<vector<int> >& B)
    {
        if(A.empty()||B.empty())
        {
            return vector<vector<int> >();
        }
        vector<vector<int> > res(A.size(),vector<int>(B.size(),0));
        for(int i=0;i<A.size();i++)
        {
            for(int j=0;j<B.size();j++)
            {
                if(A[i][j]==0)
                {
                    continue;
                }
                for(int k=0;k<B[0].size();k++)
                {
                    if(B[j][k]==0)
                    {
                        continue;
                    }
                    res[i][k]+=(A[i][j]*B[j][k]);
                }
            }
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
