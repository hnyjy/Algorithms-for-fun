//
//  main.cpp
//  Square
//
//  Created by yangjingyi on 8/8/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
struct pixelPoint
{
    int x;
    int y;
    pixelPoint(int a,int b):x(a),y(b){}
};
int dis(pixelPoint a,pixelPoint b)
{
    return (a.x-b.x)^2+(a.y-b.y)^2;//length of side
}
bool mid(pixelPoint a,pixelPoint b, pixelPoint c, pixelPoint d)
{
    if(a.x+b.x==c.x+d.x&&a.y+b.y==c.y+d.y)//orthogonal
    {
        return true;
    }
    return false;
}
bool checkSquare(vector<pixelPoint> vec)
{
    for(int i=0;i<4;i++)
    {
        for(int j=i+1;j<4;j++)
        {
            if(vec[i].x==vec[j].x&&vec[i].y==vec[j].y)
            {
                return false;
            }
        }
    }
    if(dis(vec[0],vec[1])==dis(vec[2],vec[3])&&mid(vec[0],vec[1],vec[2],vec[3])&&dis(vec[0],vec[2])==dis(vec[0],vec[3]))
       {
           return true;
       }
    if(dis(vec[0],vec[2])==dis(vec[1],vec[3])&&mid(vec[0],vec[2],vec[1],vec[3])&&dis(vec[0],vec[1])==dis(vec[0],vec[3]))
    {
        return true;
    }
    if(dis(vec[0],vec[3])==dis(vec[2],vec[1])&&mid(vec[0],vec[3],vec[2],vec[1])&&dis(vec[0],vec[2])==dis(vec[0],vec[1]))
    {
        return true;
    }
    return false;
};




int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
