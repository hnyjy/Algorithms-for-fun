//
//  main.cpp
//  Step
//
//  Created by yangjingyi on 4/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;
class Solution
{
public:
    int findN(vector<int> in,int a_init,int n)
    {
        unordered_map<int,int> hash;
        if(n==0)
        {
            return a_init;
        }
        if(n==1)
        {
            return in[a_init];
        }
        int last=a_init;
        hash[0]=in[a_init];
        int i;
        unordered_map<int,int> hash1;
        for(i=1;i<=n;i++)
        {
            if(hash1.find(last)!=hash1.end())
            {
                break;
            }
            else
            {
                hash[i]=in[last];
                hash1[last]=i;
                last=in[last];
            }
        }
        if(i<n)
        {
            int loop_size=i-hash1[last];
            return hash[hash1[last]+(n-hash1[last])%loop_size];
        }
        return last;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
