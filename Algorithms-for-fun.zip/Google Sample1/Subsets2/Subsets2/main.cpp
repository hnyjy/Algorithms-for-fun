//
//  main.cpp
//  Subsets2
//
//  Created by yangjingyi on 4/8/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<vector<int> > subsets(vector<int>& nums)
    {
        vector<int> tmp;
        vector<vector<int> > res;
        int pos=0;
        sort(nums.begin(),nums.end());
        dfs(tmp,res,pos,nums);
        return res;
    }
    void dfs(vector<int> tmp, vector<vector<int> >& res, int pos,vector<int>& nums)
    {
        if(pos>=nums.size())
        {
            res.push_back(tmp);
            return;
        }
        else
        {
            tmp.push_back(nums[pos]);
            dfs(tmp,res,pos+1,nums);
            tmp.pop_back();
            dfs(tmp,res,pos+1,nums);
            
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
