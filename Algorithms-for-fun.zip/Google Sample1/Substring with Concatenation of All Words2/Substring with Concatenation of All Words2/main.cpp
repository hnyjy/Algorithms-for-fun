//
//  main.cpp
//  Substring with Concatenation of All Words2
//
//  Created by yangjingyi on 4/24/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;
class Solution
{
public:
    vector<int> findSubstring(string s, vector<string>& words)
    {
        int wsize,wlength;
        vector<int> res;
        if(!(wsize=words.size())||!(wlength=words[0].size()))
        {
            cout<<"right3"<<endl;
            return res;
        }
        unordered_map<string, int> dict;
        unordered_map<string, int> tmp;
        for(int i=0;i<words.size();i++)
        {
            dict[words[i]]++;
        }
        for(int i=0;i+wsize*wlength<=s.size();i++)
        {
            tmp=dict;
            int j;
            //cout<<"right2"<<endl;
            for(j=0;j<wsize;j++)
            {
                cout<<"i="<<i<<" and j="<<j<<endl;
                if(dict[s.substr(i+j*wlength,wlength)]>0)
                {
                    dict[s.substr(i+j*wlength,wlength)]--;
                    //cout<<"right"<<endl;
                }
                else
                {
                    cout<<"j="<<j<<endl;
                    break;
                }
            }
            if(j==wsize)
            {
                res.push_back(i);
            }
            dict=tmp;
        }
        return res;
        
    }
};

int main(int argc, const char * argv[]) {
    string in="lingmindraboofooowingdingbarrwingmonkeypoundcake";
    vector<string> inv=
    {"fooo","barr","wing","ding","wing"};
    Solution a;
    
    vector<int> out=a.findSubstring(in,inv);
    for(auto o:out)
    {
        cout<<o<<endl;
    }
    return 0;
}
