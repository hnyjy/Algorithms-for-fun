//
//  main.cpp
//  Sum of Two Integers
//
//  Created by yangjingyi on 7/3/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    int getSum(int a, int b)
    {
        if(b==0)
        {
            return a;
        }
        int sum, carry;
        sum=a^b;
        carry=(a&b)<<1;
        return getSum(sum,carry);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
