//
//  main.cpp
//  Super Pow
//
//  Created by yangjingyi on 7/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
    const int base=1337;
    int powmod(int a, int k)
    {
        a%=base;
        int result=1;
        for(int i=0;i<k;i++)
        {
            result=(result*a)%base;
        }
        return result;
    }
public:
    int superPow(int a,vector<int>& b)
    {
        if(b.empty())
        {
            return 1;
        }
        int last_digit=b.back();
        b.pop_back();
        return powmod(superPow(a,b),10)*powmod(a,last_digit)%base;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
