//
//  main.cpp
//  The Skyline Problem2
//
//  Created by yangjingyi on 4/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <map>
#include <set>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<pair<int,int> > getSkypline(vector<vector<int> >& buildings)
    {
        multimap<int,int> corners;
        for(auto building:buildings)
        {
            corners.emplace(building[0],building[2]);
            corners.emplace(building[1],-building[2]);
        }
        multiset<int> height;
        vector<pair<int,int> > res;
        int x=-1,y=0;
        for(auto c:corners)
        {
            if((x>=0)&&(c.first!=x)&&(res.empty()||res.rbegin()->second!=y))
            {
                res.emplace_back(x,y);
            }
            if(c.second>=0)
            {
                height.insert(c.second);
            }
            else
            {
                height.erase(height.find(-c.second));
            }
            x=c.first;
            y=*height.rbegin();
        }
        if((!res.empty())&&(res.rbegin()->second!=0))
        {
            res.emplace_back(x,0);
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
