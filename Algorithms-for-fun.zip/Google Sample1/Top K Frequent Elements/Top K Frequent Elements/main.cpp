//
//  main.cpp
//  Top K Frequent Elements
//
//  Created by yangjingyi on 5/3/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
#include <queue>
using namespace std;
class Solution
{
    
public:
    vector<int> topKFrequent(vector<int>& nums,int k)
    
    {
        unordered_map<int,int> map;
        for(int num:nums)
        {
            map[num]++;
        }
        vector<int> res;
        priority_queue<pair<int,int> >pq;
        for(auto it=map.begin();it!=map.end();it++)
        {
            pq.push(make_pair(it->second,it->first));
            if(pq.size()>map.size()-k)
            {
                res.push_back(pq.top().second);
                pq.pop();
            }
        }
        return res;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
