//
//  main.cpp
//  Trapping Rain Water2
//
//  Created by yangjingyi on 4/12/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <stack>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int trap(vector<int>& height)
    {
        stack<int> st;
        int start=0;
        int level=0;
        int res=0;
        int pre=0;
        for(int i=0;i<height.size();)
        {
            if(st.empty())
            {
                st.push(i++);
                start=height[i];
            }
            else if(height[i]<=height[st.top()])
            {
                st.push(i++);
            }
            else
            {
                int low=st.top();
                
                st.pop();
                
                res=res+(st.empty()?0:(min(height[i],height[st.top()])-height[low])*(i-st.top()-1));
                pre=low;
            }
        }
        return res;
    }
};
int main(int argc, const char * argv[]) {
    vector<int> in={4,2,0,3,2,4,3,4};
    Solution a;
    int out=a.trap(in);
    cout<<out<<endl;
    return 0;
}
