//
//  main.cpp
//  Try3
//
//  Created by yangjingyi on 4/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
    void tryheap()
    {
        int myints[]={1,2,3,5,6};
        vector<int> v(myints,myints+5);
        make_heap(v.begin(),v.end());
    };
    
};

int main(int argc, const char * argv[]) {
    int myints[]={1,2,3,5,3};
    vector<int> v(myints,myints+5);
    make_heap(v.begin(),v.end());
    return 0;
}
