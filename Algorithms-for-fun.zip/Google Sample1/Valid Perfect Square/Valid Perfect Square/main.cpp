//
//  main.cpp
//  Valid Perfect Square
//
//  Created by yangjingyi on 7/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
     bool isPerfectSquare(int x)
    {
        long r=x;
        while(r*r>x)
        {
            r=(r+x/r)/2;
        }
        return r*r==x;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
