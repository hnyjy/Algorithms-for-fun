//
//  main.cpp
//  Water and Jug Problem
//
//  Created by yangjingyi on 7/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
     bool canMeasureWater(int x, int y, int z)
    {
        return z==0||((z<=(long long)x+y)&&(z%gcd(x,y)==0));
    }
    int gcd(int a, int b)
    {
     return b==0?a:gcd(b,a%b);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
