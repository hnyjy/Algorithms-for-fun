//
//  main.cpp
//  Wiggle Sort2
//
//  Created by yangjingyi on 7/7/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    void wiggleSort(vector<int>& nums)
    {
        int n=nums.size();
        for(int i=0;i<nums.size()-1;i++)
        {
            if((i%2==0&&nums[i]>nums[i+1])||(i%2!=0&&nums[i]<nums[i+1]))
            {
                swap(nums[i],nums[i+1]);
            }
        }
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in={3,5,1,3,2,7,8};
    Solution sol;
    sol.wiggleSort(in);
    for(auto n:in)
    {
        cout<<n<<" ";
    }
    return 0;
}
