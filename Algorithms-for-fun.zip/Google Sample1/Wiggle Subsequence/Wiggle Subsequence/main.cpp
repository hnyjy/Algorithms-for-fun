//
//  main.cpp
//  Wiggle Subsequence
//
//  Created by yangjingyi on 7/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
     int wiggleMaxLength(vector<int>& nums)
    {
        int flag=0,count=1;
        for(int i=1;i<nums.size();i++)
        {
            if(nums[i]>nums[i-1]&&(flag==-1||flag==0))
            {
                count++;
                flag=1;
            }
            else if(nums[i]<nums[i-1]&&(flag==1||flag==0))
            {
                count++;
                flag=-1;
            }
        }
        return nums.size()==0?0:count;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
