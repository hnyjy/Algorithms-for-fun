//
//  main.cpp
//  Word BreakII2
//
//  Created by yangjingyi on 4/17/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_set>
#include <unordered_map>
#include <vector>
using namespace std;
class Solution
{
public:
    unordered_map<string, vector<string> > m;
    vector<string> wordBreak(string s, unordered_set<string>& wordDict)
    {
        //vector<string> tmp;
        vector<vector<string>> res;
        vector<string> ress;
        
        if(m.count(s))
        {
            return m[s];
        }
        if(wordDict.count(s))
        {
            ress.push_back(s);
        }
        for(int i=1;i<s.size();i++)
        {
            string word=s.substr(0,i);
            if(wordDict.count(word))
            {
                string rem=s.substr(i);
                vector<string> tmp=combine(word, wordBreak(rem,wordDict));
                ress.insert(ress.end(),tmp.begin(),tmp.end());
            }
        }
        m[s]=ress;
        return ress;
    }
    vector<string> combine(string word, vector<string> tmp)
    {
        for(int i=0;i<tmp.size();i++)
        {
            tmp[i]=word+" "+tmp[i];
        }
        return tmp;
    }
};

int main(int argc, const char * argv[]) {
    string in="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaabaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    unordered_set<string> indict={
        "a","aa","aaa","aaaa","aaaaa","aaaaaa","aaaaaaa","aaaaaaaa","aaaaaaaaa","aaaaaaaaaa"};
    Solution a;
    vector<string> out=a.wordBreak(in, indict);
    for(auto o:out)
    {
        cout<<o<<endl;
    }
    return 0;
}
