//
//  main.cpp
//  Word SearchII 2
//
//  Created by yangjingyi on 4/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_set>
using namespace std;
class Solution
{
public:
    struct TrieNode
    {
        bool end;
        vector<TrieNode*> children;
        TrieNode()
        {
            end=false;
            children.resize(26);
        }
    };
    int m,n;
    vector<vector<int> > dirs={{0,1},{0,-1},{-1,0},{1,0}};
    vector<string> findWords(vector<vector<char> >& board, vector<string>& words)
    {
        m=board.size();
        n=board[0].size();
        TrieNode* root=new TrieNode();
        for(string w:words)
        {
            TrieNode* curr=root;
            for(char c:w)
            {
                curr=curr->children[c-'a']?curr->children[c-'a']:curr->children[c-'a']=new TrieNode();
                
            }
            curr->end=true;
            
        }
        unordered_set<string> ans;
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<n;j++)
            {
                if(root->children[board[i][j]-'a'])
                {
                    dfs(board, i, j, root->children[board[i][j]-'a'],"",ans);
                }
                
                
    
            }
        }
        vector<string> res(ans.begin(),ans.end());
        return res;
    }
    void dfs(vector<vector<char> >& board, int i, int j, TrieNode* node,string currString, unordered_set<string>& ans)
    {
        currString+=board[i][j];
        board[i][j]-=27;
        if(node->end&&ans.find(currString)==ans.end())
        {
            ans.insert(currString);
        }
        for(auto dir:dirs)
        {
            int ii=i+dir[0],jj=j+dir[1];
            if(ii>=0&&ii<m&&jj>=0&&jj<n&&board[ii][jj]>='a'&&node->children[board[ii][jj]-'a'])
            {
                dfs(board,ii,jj,node->children[board[ii][jj]-'a'],currString, ans);
            }
        }
        board[i][j]+=27;
    }
    
    
    
    
    
    
};

int main(int argc, const char * argv[]) {
    int in=11;
    int count=0;
    for(int i=in;i>0;i-=i&(-i))
    {
        count++;
        //cout<<i<<endl;
    }
    cout<<count<<endl;
    
}
