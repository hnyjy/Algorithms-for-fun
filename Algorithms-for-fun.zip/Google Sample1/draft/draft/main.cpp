//
//  main.cpp
//  draft
//
//  Created by yangjingyi on 6/20/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
#include <vector>
#include <unordered_map>
using namespace std;
class myComparison
{
public:
    bool operator()(const int& l,const int& r)const
    {
        return l>r;
    }
};
class Solution
{
public:
    int genrand()
    {
        int v=rand()%2;
        return v;
    }
    int genrand2()
    {
        int v1=genrand();
        int v2=genrand();
        if(v1+v2!=1)
        {
            return v1+v2;
        }
        else
        {
            int v3=genrand();
            if(v3)
            {
                return v1+v2;
            }
            else
            {
                return genrand2();
            }
        }
    }
};


int main(int argc, const char * argv[]) {
    priority_queue<int,vector<int> ,myComparison> pq;
    vector<int> v;
    for(int i=0;i<10;i++)
    {
        pq.push(i);
        v.push_back(i);
    }
    make_heap(v.begin(),v.end(),myComparison());
    for(int i=0;i<10;i++)
    {
        //cout<<v[i]<<endl;
        
    }
    Solution sol;
    vector<int> res;
    for(int i=0;i<100000;i++)
    {
        int tmp=sol.genrand2();
        res.push_back(tmp);
    }
    unordered_map<int,int> hash;
    for(auto r:res)
    {
        hash[r]++;
    }
    for(auto it=hash.begin();it!=hash.end();it++)
    {
        cout<<it->first<<","<<it->second<<endl;
    }
}
