//
//  main.cpp
//  draft10
//
//  Created by yangjingyi on 8/1/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int maxCoinValue(vector<vector<int> > vec,int n)
    {
        int m=vec.size();
        vector<vector<int> > res(m,vector<int>(n,0));
        int maxval;
        for(int k=1;k<m;k++)
        {
            for(int i=0;i<n;i++)
            {
                vector<int> tmp(n,0);
                for(int j=0;j<n;j++)
                {
                    
                    tmp[j]+=vec[k][j];
                    res[k][i]=max(res[k-1][i],res[k-1][i-j-1]+tmp[j]);
                }
            }
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
