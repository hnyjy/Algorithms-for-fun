//
//  main.cpp
//  draft11
//
//  Created by yangjingyi on 8/1/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <set>
using namespace std;
class Solution
{
public:
    bool div36mod1(string s)
    {
        set<int> hash;
        int pre=0;
        for(int i=s.size()-1;i>=0;i++)
        {
            
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
