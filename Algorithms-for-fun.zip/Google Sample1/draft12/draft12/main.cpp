//
//  main.cpp
//  draft12
//
//  Created by yangjingyi on 8/4/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class A
{
public:
    int a;
    virtual void foo()
    {
        cout<<"1"<<endl;
    }
};
class B:public A
{
public:
    int b;
    void foo()
    {
        cout<<"2"<<endl;
    }
};

class Base1
{
public:
    virtual int virt1()
    {
        return 100;
    }
    int data1;
};
class Derived: public Base1
{
public:
    virtual int virt1()
    {
        return 150;
    }
    int derivedData;
};
int Global1(Base1* b1)
{
    return b1->virt1();
}
void main1()
{
    Derived* d=new Derived;
    Base1* b1=d;
    
    cout<<d->virt1()<<endl;
    cout<<Global1(d)<<endl;
}
class Base2
{
public:
    virtual int virt2()
    {
        return 200;
    }
    int data2=3;
};
class MultipleDerived:public Base1, public Base2
{
public:
    virtual int virt1()
    {
        return 150;
    }
    virtual int virt2()
    {
        return data2;
    }
    int virt3()
    {
        return 7;
    }
    int data2=4;
    int derivedData=5;
};
int Global2(Base2* b2)
{
    return b2->virt2();
}
void main2()
{
    MultipleDerived* md=new MultipleDerived();
    Base2* b3=md;
    
    cout<<md->virt1()<<endl;
    cout<<Global1(md)<<endl;
    cout<<md->virt2()<<endl;
    cout<<Global2(md)<<endl;
    
}


int main(int argc, const char * argv[]) {
    main1();
    main2();
    B* newb=new B();
    A* newa=newb;
    newa->a;
    return 0;
}
