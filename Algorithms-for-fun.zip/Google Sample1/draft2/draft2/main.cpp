//
//  main.cpp
//  draft2
//
//  Created by yangjingyi on 6/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class A
{
public:
    int aa;
public:
    A()
    {
        cout<<"1"<<endl;
    }
   virtual  ~A()
    {
        cout<<"2"<<endl;
    }
    virtual void foo()
    {
        cout<<"7"<<endl;
    }
    int ad;
};
class C
{
public:
    C()
    {
        cout<<"8"<<endl;
    }
    ~C()
    {
        cout<<"9"<<endl;
    }
    virtual void foo()
    {
        cout<<"10"<<endl;
    }
};
class B:public A,public C
{
public:
    int ba;
    int bb;
public:
    B()
    {
        
        cout<<"3"<<endl;
        
    
    }
    ~B()
    {
        cout<<"4"<<endl;
    }
    void foo()
    {
        cout<<"5"<<endl;
    }
    void foo1()
    {
        cout<<"6"<<endl;
    }
    
};
class Solution
{
public:
    int climb(int n,int m)
    {
        vector<int> res;
        res.push_back(0);
        
        for(int i=1;i<=m;i++)
        {
            res.push_back(1);
            for(int j=0;j<res.size()-1;j++)
            {
                res[i]=res[j]+res[i];
            }
        }
        for(auto n:res)
        {
            cout<<n<<endl;
        }
        res.resize(n+1);
        for(int i=m+1;i<=n;i++)
        {
            //cout<<"right"<<endl;
            res[i]=0;
            for(int j=1;j<=m;j++)
            {
                res[i]=res[i-j]+res[i];
            }
        }
        return res[n];
    }
};

int main(int argc, const char * argv[]) {
    vector<int> v;
    v.push_back(1);
    v.resize(5);
    Solution sol;
    int out=sol.climb(9, 3);
    cout<<out<<endl;
    return 0;
}
