//
//  main.cpp
//  draft3
//
//  Created by yangjingyi on 6/29/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
#include <stack>
using namespace std;
struct  ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}

};
class Solution
{
public:
    
     double squareRoot(double n)
    {
        double x=n;
        double y=1;
        double e=0.000000000001;
        if(n>=1)
        {
            while(x-y>e)
            {
                x=(x+y)/2;
                y=n/x;
            }
        }
        else
        {
            x=1/x;
            n=1/n;
            while(x-y>e)
            {
                x=(x+y)/2;
                y=n/x;
            }
            x=1/x;
        }
        return x;
    }
    void swap(int*  a, int* b)
    {
        int tmp=*a;
        
        *a=*b;
        //cout<<a<<endl;
        
        *b=tmp;
    }
};

int main(int argc, const char * argv[]) {
        Solution sol;
    int a[]={1,2};
    int* in1=new int(1);
    int* in2=new int (2);
    cout<<in1<<endl;
    cout<<in2<<endl;
    sol.swap(in1, in2);
    cout<<in1<<endl;
    cout<<in2<<endl;
    cout<<*in1<<" "<<*in2<<endl;
        return 0;
}
