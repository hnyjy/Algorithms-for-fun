//
//  main.cpp
//  draft4
//
//  Created by yangjingyi on 7/12/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
};
class Solution{
public:
bool palindromeLinkedlist(ListNode* head)
{
    ListNode* fast=head;
    ListNode* curr=head;
    return help(head,curr,fast);
}
bool help(ListNode* head,ListNode*& curr,ListNode* fast)
{
    if(fast&&(!fast->next))
    {
        bool res=(head->val==curr->val);
        curr=curr->next;
        return res;
    }
    else if(fast&&fast->next&&(!fast->next->next))
    {
       curr=curr->next;
        bool res=(head->val==curr->val);
        curr=curr->next;
        return res;
    }
    
    else if(fast&&fast->next&&fast->next->next)
        
    {
        curr=curr->next;
        bool res=help(head->next,curr,fast->next->next)&&head->val==curr->val;
        if(curr->next)
        {
            curr=curr->next;
        }
        
        return res;
    }
    return true;
    
}
};


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
