//
//  main.cpp
//  draft5
//
//  Created by yangjingyi on 7/18/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;


int main(int argc, const char * argv[]) {
    int* p=(int*) calloc(5,sizeof(int));
    int* head=p;
    for(int i=0;i<5;i++)
    {
        *p=i;
        p++;
    }
    for(int i=0;i<5;i++)
    {
        cout<<*head<<endl;
        head++;
    }
    return 0;
}
