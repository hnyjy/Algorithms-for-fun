//
//  main.cpp
//  draft6
//
//  Created by yangjingyi on 7/20/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <list>
#include <queue>
#include <map>
using namespace std;
class myComprison
{
public:
    bool operator()(const map<string,int> ::iterator& lhs, const map<string,int>:: iterator& rhs)
    {
        return lhs->second<rhs->second;
    }
};
class Transaction
{
    unordered_map<string,int> record;
    unordered_map<string,list<pair<string,int> >::iterator> topKHash;
    list<pair<string,int> > topK;
    //priority_queue<pair<string,int> > heapSort;
    int minVolume;
    int currSize=0;
    int listSize=0;
    const int k=3;
public:
    void addTransaction(string name, int volume)
    {
        minVolume=INT_MAX;
        record[name]+=volume;
        if(topK.size()==0)
        {
            topK.push_front({name,record[name]});
            topKHash[name]=topK.begin();
            minVolume=record[name];
        }
        if(!topKHash.count(name)&&topK.size()<k)
        {
            topK.push_front({name,record[name]});
            topKHash[name]=topK.begin();
            
        }
        else if(!topKHash.count(name)&&topK.size()>=k)
        {
            //cout<<name<<endl;
            auto it=topK.begin();
            string tmp;
            for(;it!=topK.end();it++)
            {
                if(it->second<minVolume)
                {
                    //cout<<"right"<<endl;
                    tmp=it->first;
                    minVolume=it->second;
                }
            }
            //cout<<"tmp="<<tmp<<endl;
            if(record[name]>minVolume)
            {
                
                topK.erase(topKHash[tmp]);
                topKHash.erase(tmp);
                topK.push_front({name,record[name]});
                topKHash[name]=topK.begin();
            }
            
            
        }
        else if(topKHash.count(name))
        {
            topK.erase(topKHash[name]);
            topK.push_front({name,record[name]});
            topKHash[name]=topK.begin();
        }
        
    }
    void printTopK()
    {
        for(auto it=topK.begin();it!=topK.end();it++)
        {
            cout<<it->first<<":"<<it->second<<endl;
        }
    }
    
};
int main(int argc, const char * argv[]) {
    Transaction newTrans;
    newTrans.addTransaction("Apple",30);
    newTrans.addTransaction("Bloomberg", 50);
    newTrans.addTransaction("IBM",20);
    newTrans.addTransaction("Google",60);
    newTrans.addTransaction("IBM", 80);
    newTrans.addTransaction("BoA", 20);
    newTrans.addTransaction("Google", 60);
    newTrans.addTransaction("Chase",120);
    newTrans.addTransaction("Starbucks", 10);
    newTrans.addTransaction("Starbucks", 120);
    newTrans.printTopK();
    return 0;
}
