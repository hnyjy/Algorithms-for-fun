//
//  main.cpp
//  draft7
//
//  Created by yangjingyi on 7/21/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
void swap(int* p1,int* p2)
{
    int* tmp=new int(0);
    *tmp=*p1;
    *p1=*p2;
    *p2=*tmp;
}

int main(int argc, const char * argv[]) {
    int* p1=new int(9);
    int* p2=new int(8);
    swap(p1,p2);
    cout<<*p1<<endl;
    cout<<*p2<<endl;
    return 0;
}
