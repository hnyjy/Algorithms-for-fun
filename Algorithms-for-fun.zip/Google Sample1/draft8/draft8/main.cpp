//
//  main.cpp
//  draft8
//
//  Created by yangjingyi on 7/22/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;
int binarySearch(vector<int> nums,int target)
{
    int left=0,right=nums.size();
    while(left<right)
    {
        int mid=(left+right+1)/2;
        if(nums[mid]>target)
        {
            right=mid-1;
        }
        else
        {
            left=mid+1;
        }
    }
    if(nums[right]==target)
    {
        return right;
    }
    return -1;
}

int main(int argc, const char * argv[]) {
//    vector<int> in={1,3,4,6,8,9,10};
//    cout<<binarySearch(in, 5)<<endl;
    vector<int> in={1,2,3,4};
    cout<<binarySearch(in, 3)<<endl;
    return 0;
}
