//
//  main.cpp
//  draft9
//
//  Created by yangjingyi on 7/24/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
};
class Solution
{
public:
    ListNode* reverseEveryKNode(ListNode* head,int k)
    {
        ListNode* fhead=new ListNode(0);
        fhead->next=head;
        ListNode* curr=head;
        int count=1;
        if(!head)
        {
            return head;
        }
        while(count<k&&curr->next)
        {
            ListNode* next=curr->next->next;
            curr->next->next=fhead->next;
            fhead->next=curr->next;
            curr->next=next;
            
            count++;
        }
        //cout<<"right"<<endl;
        curr->next=reverseEveryKNode(curr->next,k);
        return fhead->next;
    }
    
};

int main(int argc, const char * argv[]) {
    ListNode* in=new ListNode(0);
    ListNode* curr=in;
    for(int i=1;i<11;i++)
    {
        curr->next=new ListNode(i);
        curr=curr->next;
    }
    Solution sol;
    ListNode* out=sol.reverseEveryKNode(in->next, 3);
    curr=out;
    while(curr)
    {
        cout<<curr->val<<endl;
        curr=curr->next;
    }
    return 0;
}
