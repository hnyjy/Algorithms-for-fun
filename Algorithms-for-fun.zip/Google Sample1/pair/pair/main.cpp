//
//  main.cpp
//  pair
//
//  Created by yangjingyi on 4/21/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int findMatchingPair(const string& input) {
        return 0;
        vector<char> st;
        int res=-1;
        for(int i=0;i<input.size();i++)
        {
            cout<<"right2"<<endl;
            if(isupper(input[i]))
            {
                cout<<"right1"<<endl;
                st.push_back(input[i]);
            }
            else
            {
                if(!st.empty()&&toupper(input[i])==st.back())
                {
                    st.pop_back();
                    cout<<"right"<<endl;
                    res=i;
                }
                else
                {
                    break;
                }
            }
        }
        return res;
    }

};

int main(int argc, const char * argv[]) {
    string in="PTtCNVvncp";
    Solution a;
    int out=a.findMatchingPair(in);
    cout<<out<<endl;
    return 0;
}
