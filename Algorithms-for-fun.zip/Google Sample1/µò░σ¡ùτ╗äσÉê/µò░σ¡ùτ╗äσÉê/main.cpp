//
//  main.cpp
//  数字组合
//
//  Created by yangjingyi on 5/24/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <set>
using namespace std;
class Solution
{
public:
    vector<vector<int> > combinationSum(vector<int>& candidates, int target)
    
    {
        set<vector<int> > ress;
        vector<vector<int> > resv;
        if(candidates.size()==0)
        {
            return resv;
        }
        sort(candidates.begin(),candidates.end());
        if(candidates[0]>target)
        {
            return resv;
        }
        for(int i=0;i<candidates.size();i++)
        {
            if(target==candidates[i])
            {
                vector<int> tmp;
                tmp.push_back(candidates[i]);
                
                ress.insert(tmp);
            }
            else
            {
                vector<int> tmp;
                tmp.push_back(candidates[i]);
                
                help(candidates,ress,tmp,target-candidates[i]);
            }
        }
        return vector<vector<int> >(ress.begin(),ress.end());
    }
    void help(vector<int>& candidates, set<vector<int> >& ress,vector<int>& tmp,int target)
    {
        if(target<candidates[0])
        {
            return;
        }
        else
        {
            for(int i=0;i<candidates.size();i++)
            {
                if(target==candidates[i])
                {
                    tmp.push_back(candidates[i]);
                    ress.insert(tmp);
                    tmp.pop_back();
                }
                else
                {
                    tmp.push_back(candidates[i]);
                    
                    help(candidates,ress,tmp,target-candidates[i]);
                    tmp.pop_back();
                }
            }
        }
    }
    
};

int main(int argc, const char * argv[]) {
    vector<int> in={1,2};
    int target=2;
    Solution a;
    vector<vector<int> > out=a.combinationSum(in, target);
    for(int i=0;i<out.size();i++)
    {
        for(int j=0;j<out[i].size();j++)
        {
            cout<<out[i][j]<<",";
        }
        cout<<endl;
    }
    
    return 0;
}
