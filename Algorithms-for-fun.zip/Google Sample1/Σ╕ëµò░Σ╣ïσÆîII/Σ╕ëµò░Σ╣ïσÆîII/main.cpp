//
//  main.cpp
//  三数之和II
//
//  Created by yangjingyi on 5/3/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <climits>
#include <vector>
using namespace std;
class Solution
{
public:
     int threeSumClosest(vector<int>& nums, int target)
    {
        int res=0;
        int mindif=INT_MAX;
        sort(nums.begin(),nums.end());
        vector<int> result;
        for(int i=0;i<nums.size()-2;i++)
        {
            cout<<"i="<<i<<endl;
            for(int j=i+1,k=nums.size()-1;j<nums.size()-1&&k>j;)
            {
                
                if(nums[i]+nums[j]+nums[k]>target)
            {cout<<"right1"<<endl;
                if(abs(nums[i]+nums[j]+nums[k]-target)<mindif)
                {
                    res=nums[i]+nums[j]+nums[k];
                    mindif=abs(nums[i]+nums[j]+nums[k]-target);
                    result.clear();
                    result.push_back(i);
                    result.push_back(j);
                    result.push_back(k);
                    for(auto r:result)
                    {
                        cout<<r<<endl;
                    }
                    
                }
                k--;
            }
            else if(nums[i]+nums[j]+nums[k]<target)
            {cout<<"right2"<<endl;
                cout<<"abs(nums[i]+nums[j]+nums[k]-target)="<<abs(nums[i]+nums[j]+nums[k]-target)<<endl;
                cout<<"mindif="<<mindif<<endl;
                if(abs(nums[i]+nums[j]+nums[k]-target)<mindif)
                {
                    res=nums[i]+nums[j]+nums[k];
                    mindif=abs(nums[i]+nums[j]+nums[k]-target);
                    result.clear();
                    result.push_back(i);
                    result.push_back(j);
                    result.push_back(k);
                    for(auto r:result)
                    {
                        cout<<r<<endl;
                    }
                    
                }
                j++;
            }
            else
            {
                res=target;
                result.clear();
                result.push_back(i);
                result.push_back(j);
                result.push_back(k);
                for(auto r:result)
                {
                    cout<<r<<endl;
                }
                cout<<"right3"<<endl;
                return res;
            }
            }
        }
        for(auto r:result)
        {
            cout<<r<<endl;
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in={1,0,-1,-1,-1,-1,0,1,1,1,2};
    int target=7;
    Solution a;
    int out=a.threeSumClosest(in , target);
    cout<<out<<endl;
    return 0;
}
