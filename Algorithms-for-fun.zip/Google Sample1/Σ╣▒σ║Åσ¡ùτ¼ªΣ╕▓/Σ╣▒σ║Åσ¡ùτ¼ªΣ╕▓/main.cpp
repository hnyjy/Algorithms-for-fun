//
//  main.cpp
//  乱序字符串
//
//  Created by yangjingyi on 5/3/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
#include <set>
using namespace std;
class Solution
{
public:
    vector<string> anagrams(vector<string>& strs)
    {
        vector<unordered_map<char,int> > mapv;
        set<string> sets;
        vector<string> res;
        for(int i=0;i<strs.size();i++)
        {
            unordered_map<char,int> mapt;
            for(int j=0;j<strs[i].size();j++)
                
            {
                mapt[strs[i][j]]++;
            }
            mapv.push_back(mapt);
        }
        for(int i=0;i<mapv.size()-1;i++)
        {
            for(int j=i+1;j<mapv.size();j++)
            {
                if(mapv[i]==mapv[j])
                {
                    if(strs[i]=="")
                    {
                        res.push_back("");
                        res.push_back("");
                        //return res;
                    }
                    sets.insert(strs[i]);
                    sets.insert(strs[j]);
                }
            }
        }
        return vector<string> (sets.begin(),sets.end());
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
