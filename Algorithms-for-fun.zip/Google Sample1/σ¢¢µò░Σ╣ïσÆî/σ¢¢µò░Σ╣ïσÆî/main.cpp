//
//  main.cpp
//  四数之和
//
//  Created by yangjingyi on 5/3/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <set>

#include <vector>
using namespace std;
class Solution
{
public:
    vector<vector<int> >fourSum(vector<int> nums, int target)
    {
        sort(nums.begin(),nums.end());
        set<multiset<int> > rest;
        vector<vector<int> > res;
        for(int i=0;i<nums.size()-3;i++)
        {
            for(int j=i+1;j<nums.size()-2;j++)
            {
                for(int k=j+1,h=nums.size()-1;k<nums.size()-1&&h>k;)
                {
                    if(nums[i]+nums[j]+nums[k]+nums[h]<target)
                    {
                        k++;
                    }
                    else if(nums[i]+nums[j]+nums[k]+nums[h]>target)
                    {
                        h--;
                    }
                    else
                    {
                        multiset<int> tmp;
                        tmp.insert(nums[i]);
                        tmp.insert(nums[j]);
                        tmp.insert(nums[k]);
                        tmp.insert(nums[h]);
                        rest.insert(tmp);
                    }
                }
            }
        }
        for(auto it=rest.begin();it!=rest.end();it++)
        {
            vector<int> tmpv(it->begin(),it->end());
            res.push_back(tmpv);
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
