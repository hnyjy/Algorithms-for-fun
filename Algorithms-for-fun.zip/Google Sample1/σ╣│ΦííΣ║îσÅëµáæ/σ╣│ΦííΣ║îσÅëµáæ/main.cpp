//
//  main.cpp
//  平衡二叉树
//
//  Created by yangjingyi on 5/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    bool isBalanced(TreeNode* root)
    {
        if(!root)
        {
            return true;
        }
        return abs(depth(root->left)-depth(root->right))<=1&&isBalanced(root->left)&&isBalanced(root->right);
    }
    int depth(TreeNode* root)
    {
        return root?max(depth(root->left),depth(root->right))+1:0;
    }
};

int main(int argc, const char * argv[]) {
    TreeNode* root=new TreeNode(1);
    root->left=new TreeNode(2);
    root->right=new TreeNode(3);
    Solution a;
    bool out=a.isBalanced(root);
    if(out)
    {
        cout<<"right"<<endl;
    }
    return 0;
}
