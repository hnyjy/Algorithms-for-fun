//
//  main.cpp
//  Google Sample2
//
//  Created by yangjingyi on 3/7/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <stack>
#include <vector>
using namespace std;
struct TreeNode
{
    string val;
    int level;
    TreeNode *child;
    TreeNode(string x):val(x),level(1),child(NULL){}
};
int solution(string &S)
{
    stack<string> path;
    int lastchar=0;
    for(int i=0;i<S.size();i++)
    {
        int newl=S.find("\n");
        string tmp=S.substr(lastchar,i);
        
    }
    
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
/Users/yangjingyi/Downloads/电影/艾米.Amy.2015.BD720P.X264.AAC.English.CHS-ENG.Mp4Ba