//
//  main.cpp
//  Gray Code
//
//  Created by yangjingyi on 12/16/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<int> grayCode(int n)
    {
        vector<int> result(1,0);
        for(int i=0;i<n;i++)
        {
            int curCount=result.size();
            while(curCount)
            {
                curCount--;
                int curNum=result[curCount];
                curNum+=(1<<i);
                result.push_back(curNum);
            }
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
