//
//  main.cpp
//  Group Anagrams
//
//  Created by yangjingyi on 12/9/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;
class Solution
{
public:
    bool check(unordered_map<char,int> tmp1,string str1)
    {
        bool flag=true;
        int i;
        unordered_map<char,int>::iterator it=tmp1.begin();
        int length=str1.size();
                //unordered_map<char,int>::iterator it=tmp1.begin();
        for( i=0;i<length;i++)
        {
            if(tmp1.find(str1[i])!=tmp1.end())
            {
                //cout<<str1[i]<<endl;
                tmp1[str1[i]]--;
                //cout<<"i="<<i<<endl;
            }
            else
            {
                //cout<<"i1="<<i<<endl;
                break;
            }
            
        }
        //cout<<"length="<<length<<endl;
        //cout<<"i="<<i<<endl;
        if(i!=str1.size())
        {
            //cout<<"i="<<i<<" "<<"wrong"<<endl;
            return false;
        }
        for(;it!=tmp1.end();++it)
        {
            if(it->second!=0)
            {
                //cout<<"wrong"<<endl;
                return false;
            }
        }
        //cout<<"right"<<endl;
        return flag;
        
        
    }
    vector<vector<string> > groupAnagrams(vector<string>& strs)
    {
        vector<vector<string> > result;
        vector<string> resv;
        //int count=-1;
        for(int i=0;i<strs.size();i++)
        {
            if(strs[i]!="")
            {
                unordered_map<char, int> tmp;
                for(int k=0;k<strs[i].size();k++)
                {
                    tmp[strs[i][k]]++;
                }
                //unordered_map<char,int>::iterator it=tmp.begin();
                /*for(;it!=tmp.end();it++)
                {
                    cout<<it->first<<":"<<it->second<<endl;
                }*/
                //count++;
                //cout<<"index["<<i<<"]"<<"="<<strs[i]<<endl;
                resv.push_back(strs[i]);
                for(int j=i+1;j<strs.size();j++)
                {
                    if(strs[j]=="")
                    {
                        continue;
                    }
                    //cout<<"j="<<j<<endl;
                    if(check(tmp,strs[j]))
                    {
                        resv.push_back(strs[j]);
                        strs[j]="";
                        //cout<<"j2="<<j<<endl;
                    }
                    
                }
                //tmp.clear();
                result.push_back(resv);
                resv.clear();
            }
            
        }
        for(int y=0;y<result.size();y++)
        {
            sort(result[y].begin(),result[y].end());
        }
        return result;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    vector<string> in={"eat", "tea", "tan", "ate", "nat", "bat"};
    //sort(in.begin(),in.end());
    for(int i=0;i<in.size();i++)
    {
        cout<<in[i]<<endl;
    }
    cout<<"..........................................."<<endl;
    Solution a;
    vector<vector<string> > out;
    out=a.groupAnagrams(in);
    for(int i=0;i<out.size();i++)
    {
        for(int j=0;j<out[i].size();j++)
        {
            cout<<out[i][j]<<", ";
        }
        cout<<endl;
    }
    return 0;
}
