//
//  main.cpp
//  Group Anagrams2
//
//  Created by yangjingyi on 12/9/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
#include <set>
using namespace std;
class Solution
{
public:
    vector<vector<string> > groupAnagrams(vector<string>& strs)
    {
        unordered_map<string,vector<string>> mp;
        for(string s:strs)
        {
            string t=s;
            sort(t.begin(),t.end());
            mp[t].push_back(s);
                 
        }
        vector<vector<string> > anagrams;
        for(auto m:mp)
        {
            vector<string> anagram(m.second.begin(),m.second.end());
            anagrams.push_back(anagram);
        }
        return anagrams;
    }
};

int main(int argc, const char * argv[]) {
    vector<string> in={"eat", "tea", "tan", "ate", "nat", "bat"};
    //sort(in.begin(),in.end());
    for(int i=0;i<in.size();i++)
    {
        cout<<in[i]<<endl;
    }
    cout<<"..........................................."<<endl;
    Solution a;
    vector<vector<string> > out;
    out=a.groupAnagrams(in);
    for(int i=0;i<out.size();i++)
    {
        for(int j=0;j<out[i].size();j++)
        {
            cout<<out[i][j]<<", ";
        }
        cout<<endl;
    }
    return 0;
    return 0;

}
