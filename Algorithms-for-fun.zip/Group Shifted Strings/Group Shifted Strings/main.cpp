//
//  main.cpp
//  Group Shifted Strings
//
//  Created by yangjingyi on 1/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<vector<string> > grouStrings(vector<string>& strings)
    {
        unordered_map<string, vector<string> >mp;
        vector<vector<string> >res;
        for(auto str:strings)
        {
            mp[getString(str)].push_back(str);
        }
        for(auto str:mp)
        {
            vector<string> strs=str.second;
            sort(strs.begin(),strs.end());
            res.push_back(strs);
        }
        return res;
    }
    string getString(string s)
    {
        string res="";
        int shift=s[0]-'a';
        for(auto c:s)
        {
            res=res+char(int(c-'a'-shift+26)%26+'a');
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
