//
//  main.cpp
//  H-Index
//
//  Created by yangjingyi on 2/2/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
     int hIndex(vector<int>& citations)
    {
        int n=citations.size();
        int result;
        sort(citations.begin(),citations.end());
        for(int i=0;i<n;i++)
        {
            if(n-i<citations[i])
            {
                return max(result,n-i);
            }
            else
            {
                result=citations[i];
            }
        }
        return 0;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
