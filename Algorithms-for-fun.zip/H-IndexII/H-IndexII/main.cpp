//
//  main.cpp
//  H-IndexII
//
//  Created by yangjingyi on 2/2/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int hIndex(vector<int>& citations)
    {
        int n=citations.size();
        int left=0;
        int mid;
        int count=n;
        int step;
        while(count>0)
        {
            step=count/2;
            mid=left+step;
            if(citations[mid]<n-mid)
            {
                left=mid+1;
                count-=(step+1);
            }
            else
            {
                count =step;
            }
        }
        return n-left;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
