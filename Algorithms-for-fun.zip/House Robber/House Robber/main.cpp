//
//  main.cpp
//  House Robber
//
//  Created by yangjingyi on 1/1/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int rob(vector<int>& nums)
    {
        if(nums.size()==0)
        {
            return 0;
        }
        vector<int> result(nums.size()+3,0);
        for(int i=3;i<nums.size()+3;i++)
        {
            result[i]=max(result[i-2]+nums[i-3],result[i-3]+nums[i-3]);
        }
        return max(result[nums.size()+1],result[nums.size()+2]);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
