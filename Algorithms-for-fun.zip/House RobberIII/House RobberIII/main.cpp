//
//  main.cpp
//  House RobberIII
//
//  Created by yangjingyi on 3/13/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <climits>
#include <stack>
#include <vector>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    int rob(TreeNode* root)
    {
        return robDFS(root).second;
        
    }
    pair<int,int> robDFS(TreeNode* node)
    {
        if(!node)
        {
            return make_pair(0,0);
        }
        auto l=robDFS(node->left);
        auto r=robDFS(node->right);
        int f2=l.second+r.second;
        int f1=max(f2,l.first+r.first+node->val);
        return make_pair(f2,f1);
    }
    
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
