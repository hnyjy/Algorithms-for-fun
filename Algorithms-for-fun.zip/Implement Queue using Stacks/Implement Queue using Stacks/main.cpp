//
//  main.cpp
//  Implement Queue using Stacks
//
//  Created by yangjingyi on 1/16/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <stack>
using namespace std;
class Queue
{
public:
    stack<int> stk1;
    stack<int> stk3;
    stack<int> stk2;
    void push(int x)
    {
        stk1.push(x);
        stk3=stk1;
        int n1=stk1.size();
        int n2=stk2.size();
        for(int i=0;i<n2;i++)
        {
            stk2.pop();
        }
        for(int i=0;i<n1;i++)
        {
            stk2.push(stk3.top());
            stk3.pop();
        }
        
    }
    void pop(void)
    {
        stk2.pop();
        stk3=stk2;
        int n1=stk1.size();
        int n2=stk2.size();
        for(int i=0;i<n1;i++)
        {
            stk1.pop();
        }
        for(int i=0;i<n2;i++)
        {
            stk1.push(stk3.top());
            stk3.pop();
        }
    }
    int peek(void)
    {
        return stk2.top();
    }
    bool empty(void)
    {
        return stk2.empty();
    }
};

int main(int argc, const char * argv[]) {
    Queue in;
    in.push(1);
    in.push(2);
    in.pop();
    in.pop();
    if(in.empty())
    {
        cout<<"true"<<endl;
    }
    while(!in.empty())
    {
        cout<<in.peek()<<endl;
        in.pop();
    }
}
