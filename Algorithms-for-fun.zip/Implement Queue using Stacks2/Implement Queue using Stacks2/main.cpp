//
//  main.cpp
//  Implement Queue using Stacks2
//
//  Created by yangjingyi on 1/16/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <stack>
using namespace std;
class Queue
{
    stack<int> input,output;
public:
    void push(int x)
    {
        input.push(x);
    }
    void pop(void)
    {
        peek();
        output.pop();
    }
    int peek(void)
    {
        if(output.empty())
        {
            while(input.size())
            {
                output.push(input.top());
                input.pop();
            }
        }
        return output.top();
    }
    bool empty(void)
    {
        return input.empty()&&output.empty();
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
