//
//  main.cpp
//  Implement Stack using Queues
//
//  Created by yangjingyi on 1/14/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
using namespace std;
class Stack
{
public:
    queue<int> que;
    void push(int x)
    {
        que.push(x);
        for(int i=0;i<que.size()-1;i++)
        {
            que.push(que.front());
            que.pop();
        }
    }
    void pop()
    {
        que.pop();
    }
    int top()
    {
        return que.front();
    }
    bool empty()
    {
        return que.empty();
    }

};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
