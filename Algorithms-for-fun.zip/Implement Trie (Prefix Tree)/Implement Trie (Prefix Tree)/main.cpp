//
//  main.cpp
//  Implement Trie (Prefix Tree)
//
//  Created by yangjingyi on 1/2/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class TrieNode
{
public:
    char content;
    bool isend;
    int shared;
    vector<TrieNode*> children;
    TrieNode(): content(' '),isend(false),shared(0){}
    TrieNode(char ch):content(ch),isend(false),shared(0){}
    TrieNode* subNode(char ch)
    {
        if(!children.empty())
        {
            for(auto child:children)
            {
                if(child->content==ch)
                {
                    return child;
                }
            }
        }
        return nullptr;
    }
    ~TrieNode()
    {
        for(auto child:children)
        {
            delete child;
        }
    }
};
class Trie
{
public:
    Trie()
    {
        root=new TrieNode();
    }
    void insert(string word)
    {
        if(search(word))
        {
            return ;
        }
        TrieNode* curr=root;
        for(auto ch:word)
        {
            TrieNode* child=curr->subNode(ch);
            if(child!=nullptr)
            {
                curr=child;
            }
            else
            {
                TrieNode *newNode=new TrieNode(ch);
                curr->children.push_back(newNode);
                curr=newNode;
                ++curr->shared;
            }
            
        }
        curr->isend=true;
        
    }
    bool search(string word)
    {
        TrieNode* curr=root;
        for(auto ch:word)
        {
            curr=curr->subNode(ch);
            if(curr==nullptr)
            {
                return false;
            }
        }
        return curr->isend==true;
        
    }
    bool startsWith(string prefix)
    {
        TrieNode* curr=root;
        for(auto ch:prefix)
        {
            curr=curr->subNode(ch);
            if(curr==nullptr)
            {
                return false;
            }
            
        }
        return true;
        
    }
    ~Trie()
    {
        delete root;
    }
private:
    TrieNode* root;
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
