//
//  main.cpp
//  Implement Trie (Prefix Tree)2
//
//  Created by yangjingyi on 1/4/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class TrieNode
{
public:
    TrieNode *next[26];
    bool is_word;
    TrieNode(bool b=false)
    {
        memset(next,0,sizeof(next));
        is_word=b;
    }
};
class Trie
{
    TrieNode *root;
public:
    Trie()
    {
        root=new TrieNode();
    }
    void insert(string s)
    {
        TrieNode* p=root;
        for(int i=0;i<s.size();++i)
        {
            if(p->next[s[i]-'a']==NULL)
            {
                p->next[s[i]-'a']=new TrieNode();
            }
            p=p->next[s[i]-'a'];
        }
        p->is_word=true;
    }
    bool search(string key)
    {
        TrieNode *p=find(key);
        return p!=NULL&&p->is_word;
    }
    bool startsWith(string prefix)
    {
        return find(prefix)!=NULL;
    }
private:
    TrieNode* find(string key)
    {
        TrieNode *p=root;
        for(int i=0;i<key.size()&&p!=NULL;++i)
        {
            p=p->next[key[i]-'a'];
        }
        return p;
    }
};


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
