//
//  main.cpp
//  Implement Trie (Prefix Tree)3
//
//  Created by yangjingyi on 1/4/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
using namespace std;
class TrieNode
{
public:
    TrieNode(bool end=false)
    {
        isEnd=end;
    }
    unordered_map<char,TrieNode*> branches;
    bool isEnd;
};
class Trie
{
public:
    Trie()
    {
        root= new TrieNode();
    }
    ~Trie()
    {
        destroy(root);
    }
    void destroy(TrieNode* node)
    {
        for(auto entry: node->branches)
        {
            destroy(entry.second);
        }
        delete node;
    }
    void insert(string s)
    {
        TrieNode *node=root;
        int i;
        for(i=0;i<s.size();i++)
        {
            if(node->branches.find(s[i])==node->branches.end())
            {
                break;
            }
            else
            {
                node=node->branches[s[i]];
                node->isEnd=((i==s.size()-1)?true:node->isEnd);
            }
        }
        for(;i<s.size();i++)
        {
            node->branches[s[i]]=new TrieNode(i==s.size()-1?true:false);
            node=node->branches[s[i]];
            
        }
    }
    bool search(string key)
    {
        TrieNode* node=root;
        for(int i=0;i<key.size();i++)
        {
            if(node->branches.find(key[i])==node->branches.end())
            {
                return false;
            }
            else
            {
                node=node->branches[key[i]];
            }
        }
        if(node->isEnd)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    bool startsWith(string prefix)
    {
        TrieNode* node=root;
        for(int i=0;i<prefix.size();i++)
        {
            if(node->branches.find(prefix[i])==node->branches.end())
            {
                return false;
            }
            else
            {
                node=node->branches[prefix[i]];
            }
        }
        return true;
    }
private:
    TrieNode* root;
    
};
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
