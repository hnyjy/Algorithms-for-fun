//
//  main.cpp
//  Implement strStr()
//
//  Created by yangjingyi on 10/8/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    int strStr(string haystack, string needle)
    {
        int i,j;
        int pos=0;
        j=0;
        if(needle.size()==0)
            return 0;
        for(i=0;i<=haystack.size()-needle.size();i++)
        {
            for(j=0;j<needle.size();j++)
            {
                if(haystack[i+j]!=needle[j])
                    break;
            }
            if(j==needle.size())
            {
                return i;
            }
        }
        return -1;
    }
};

int main() {
    // insert code here...
    string in1="abaaa";
    string in2="abb";
    Solution a;
    int count;
    count=a.strStr(in1,in2);
    cout<<count<<endl;
}
