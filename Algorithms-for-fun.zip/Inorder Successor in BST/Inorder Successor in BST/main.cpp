//
//  main.cpp
//  Inorder Successor in BST
//
//  Created by yangjingyi on 2/6/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    TreeNode* inorderSuccessor(TreeNode* root, TreeNode* p)
    {
        TreeNode* candidate=NULL;
        while(root)
        {
            root=(root->val>p->val)?(candidate=root)->left:root->right;
        }
        return candidate;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
