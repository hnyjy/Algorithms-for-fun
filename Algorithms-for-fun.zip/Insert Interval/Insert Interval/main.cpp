//
//  main.cpp
//  Insert Interval
//
//  Created by yangjingyi on 12/10/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
struct Interval
{
    int start;
    int end;
    Interval():start(0),end(0){}
    Interval(int s, int e):start(s),end(e){}
};
class Solution
{
public:
    vector<Interval> insert(vector<Interval>& intervals, Interval newInterval)
    {
        int i,j;
        for(i=0;i<intervals.size();i++)
        {
            if(newInterval.start>=intervals[i].start&&newInterval.start<=intervals[i].end)
            {
                for(j=i;j<intervals.size();j++)
                {
                    if(newInterval.end>=intervals[j].start&&newInterval.end<=intervals[j].end)
                    {
                        intervals[i].end=intervals[j].end;
                        vector<Interval>::iterator it=intervals.begin()+i;
                        for(int k=0;k<j-i;k++)
                        {
                            intervals.erase(it+1);
                        }
                        return intervals;
                    }
                    else if(newInterval.end<intervals[j].start)
                    {
                        intervals[i].end=newInterval.end;
                        vector<Interval>::iterator it=intervals.begin()+i;
                        for(int k=0;k<j-i-1;k++)
                        {
                            intervals.erase(it+1);
                        }
                        return intervals;
                    }
                }

            }
            else if(newInterval.start>intervals[i].end&&newInterval.start<=intervals[i+1].start&&newInterval.end>=intervals[i+1].start&&i<intervals.size()-1)
            {
                for(j=i+1;j<intervals.size();j++)
                {
                    if(newInterval.end>=intervals[j].start&&newInterval.end<=intervals[j].end)
                    {
                        intervals[i+1].start=newInterval.start;
                        vector<Interval>::iterator it=intervals.begin()+i+1;
                        for(int k=0;k<j-i-i;k++)
                        {
                            intervals.erase(it+1);
                        }
                        return intervals;
                    }
                    else if(newInterval.end<intervals[j].start)
                    {
                        intervals[i+1].end=newInterval.end;
                        vector<Interval>::iterator it=intervals.begin()+i+1;
                        for(int k=0;k<j-i-2;k++)
                        {
                            intervals.erase(it+1);
                        }
                        return intervals;
                    }
                        
                }
            }
            else
            {
                vector<Interval>::iterator it=intervals.begin()+i+1;
                intervals.insert(it,newInterval);
                return intervals;
            }
        }
        return intervals;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
