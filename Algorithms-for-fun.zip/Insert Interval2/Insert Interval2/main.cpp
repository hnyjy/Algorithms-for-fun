//
//  main.cpp
//  Insert Interval2
//
//  Created by yangjingyi on 12/10/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
struct Interval
{
    int start;
    int end;
    Interval():start(0),end(0){}
    Interval(int s, int e):start(s),end(e){}
};
class Solution
{
public:
    vector<Interval> insert(vector<Interval>& intervals, Interval newInterval)
    {
        vector<Interval>::iterator it=intervals.begin();
        vector<Interval> result;
        for(;it!=intervals.end();it++)
        {
            if(newInterval.end<(*it).start)
            {
                break;
            }
            else if(newInterval.start>(*it).end)
            {
                result.push_back(*it);
            }
            else
            {
                newInterval.start=min(newInterval.start,(*it).start);
                newInterval.end=max(newInterval.end,(*it).end);
            }
        }
        result.push_back(newInterval);
        for(;it!=intervals.end();++it)
        {
            result.push_back(*it);
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
