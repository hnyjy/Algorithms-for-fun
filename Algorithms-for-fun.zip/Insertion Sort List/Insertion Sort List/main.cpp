//
//  main.cpp
//  Insertion Sort List
//
//  Created by yangjingyi on 12/24/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode(int x):val(x), next(NULL){}
};
class Solution
{
public:
    ListNode* insertionSortList(ListNode* head)
    {
        if(head==NULL)
        {
            return head;
            
        }
        ListNode helper(0);
        ListNode* cur=head;
        ListNode* pre=&helper;
        ListNode* next=NULL;
        while(cur)
        {
            next=cur->next;
            while(pre->next&&pre->next->val<cur->val)
            {
                pre=pre->next;
            }
            cur->next=pre->next;
            pre->next=cur;
            pre=&helper;
            cur=next;
        }
        return helper.next;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
