//
//  main.cpp
//  Interger to Roman
//
//  Created by yangjingyi on 3/14/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    string intToRoman(int num)
    {
        string table[4][10]={{"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"},
            {"", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC"},
            {"", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM"},
            {"", "M", "MM", "MMM"}};
        string result;
        int count=0;
        while(num>0)
        {
            int temp=num%10;
            result=table[count][temp]+result;
            num/=10;
            count++;
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
