//
//  main.cpp
//  Interleaving String
//
//  Created by yangjingyi on 12/18/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <stack>
using namespace std;
class Solution
{
public:
    bool isInterleave(string s1, string s2, string s3)
    {
        int sp1=0, sp2=0, sp3=0;
        stack<int> stk1,stk2,stk3;
        while(true)
        {
            if(s3[sp3]=='\0'&&(s1[sp1]=='\0'||s2[sp2]=='\0'))
            {
                cout<<"1"<<endl;
                return true;
            }
            if(s3[sp3]!=s1[sp1]&&s3[sp3]!=s2[sp2])
            {
                if(stk1.size())
                {
                    cout<<"2"<<endl;
                    sp3=stk3.top()+1;
                    stk3.pop();
                    sp1=stk1.top();
                    stk1.pop();
                    sp2=stk2.top()+1;
                    stk2.pop();
                }
                else
                {
                    cout<<"3"<<endl;
                    return false;
                }
                
            }
            if(s3[sp3]==s1[sp1]&&s3[sp3]==s2[sp2])
            {
                cout<<"4"<<endl;
                stk1.push(sp1);
                stk2.push(sp2);
                stk3.push(sp3);
                sp1=sp1+1;
                sp3=sp3+1;
            }
            else if(s3[sp3]==s1[sp1]&&s3[sp3]!=s2[sp2])
            {
                cout<<"5"<<endl;
                sp1=sp1+1;
                sp3=sp3+1;
            }
            else if(s3[sp3]==s2[sp2]&&s3[sp3]!=s1[sp1])
            {
                cout<<"6"<<endl;
                sp2=sp2+1;
                sp3=sp3+1;
            }
            
        }
    }
};

int main(int argc, const char * argv[]) {
    string in1="bbbbbabbbbabaababaaaabbababbaaabbabbaaabaaaaababbbababbbbbabbbbababbabaabababbbaabababababbbaaababaa",in2=
    "babaaaabbababbbabbbbaabaabbaabbbbaabaaabaababaaaabaaabbaaabaaaabaabaabbbbbbbbbbbabaaabbababbabbabaab",in3="babbbabbbaaabbababbbbababaabbabaabaaabbbbabbbaaabbbaaaaabbbbaabbaaabababbaaaaaabababbababaababbababbbababbbbaaaabaabbabbaaaaabbabbaaaabbbaabaaabaababaababbaaabbbbbabbbbaabbabaabbbbabaaabbababbabbabbab";
    Solution a;
    bool out=a.isInterleave(in1,in2, in3);
    if(out==true)
    {
        cout<<"true"<<endl;
        
    }
    if(out==false)
    {
        cout<<"false"<<endl;
    }
    return 0;
}
