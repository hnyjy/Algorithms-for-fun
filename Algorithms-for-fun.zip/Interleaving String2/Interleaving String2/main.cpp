//
//  main.cpp
//  Interleaving String2
//
//  Created by yangjingyi on 12/18/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    bool isInterleave(string s1, string s2, string s3)
    {
        int i,j, len1=s1.size(),len2=s2.size(),len3=s3.size();
        if(len1+len2!=len3)
            
        {
            return false;
        }
        bool isPath[len2+1];
        fill_n(isPath, len2+1,false);
        for(isPath[0]=true, i=0;i<=len1;i++)
        {
            for(j=1,isPath[0]=(i==0)||(isPath[0]&&(s1[i-1]==s3[i-1]));j<=len2;j++)
            {
                isPath[j]=(isPath[j-1]&&(s2[j-1]==s3[i+j-1]))||(isPath[j]&&(s1[i-1]==s3[i+j-1]));
            }
                
        }
        return isPath[len2];
    }
};

int main(int argc, const char * argv[]) {
   
    std::cout << "Hello, World!\n";
    return 0;
}
