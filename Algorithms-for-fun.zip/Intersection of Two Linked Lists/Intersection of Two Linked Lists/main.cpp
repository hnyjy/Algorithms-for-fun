//
//  main.cpp
//  Intersection of Two Linked Lists
//
//  Created by yangjingyi on 12/27/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode(int x):val(x),next(NULL){}
};
class Solution
{
public:
    ListNode *getIntersectionNode(ListNode *headA,ListNode *headB)
    {
        ListNode *tmp=headB;
        int amt=0,lengthofB=0;
        while(tmp)
        {
            amt +=tmp->val;
            lengthofB++;
            tmp=tmp->next;
        }
        tmp=headA;
        while(tmp)
        {
            tmp->val++;
            tmp=tmp->next;
        }
        tmp=headB;
        int newamt=0;
        while(tmp)
        {
            newamt +=tmp->val;
            tmp=tmp->next;
        }
        tmp=headA;
        while(tmp)
        {
            tmp->val--;
            tmp=tmp->next;
        }
        if(newamt==amt)
        {
            return NULL;
        }
        else
        {
            tmp=headB;
            for(int i=0;i<lengthofB-(newamt-amt);i++)
            {
                tmp=tmp->next;
                
            }
            return tmp;
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
