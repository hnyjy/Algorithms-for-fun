//
//  main.cpp
//  Invert Binary Tree
//
//  Created by yangjingyi on 1/14/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    TreeNode* invertTree(TreeNode* root)
    {
        if(!root)
        {
            return root;;
            
        }
        TreeNode* releft=invertTree(root->left);
        TreeNode* reright=invertTree(root->right);
        root->left=releft;
        root->right=reright;
        return root;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
