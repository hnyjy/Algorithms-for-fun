//
//  main.cpp
//  Isomorphic Strings
//
//  Created by yangjingyi on 1/2/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
using namespace std;
class Solution
{
public:
    bool isIsomorphic(string s, string t)
    {
        if(s.size()!=t.size())
        {
            return false;
        }
        if(s.size()==0)
        {
            return true;
        }
        unordered_map<char,char> hash1;
        unordered_map<char,char> hash2;
        for(int i=0;i<s.size();i++)
        {
            if(!hash1[s[i]]&&!hash2[t[i]])
            {
                hash1[s[i]]=t[i];
                hash2[t[i]]=s[i];
            }
            else if(hash1.count(s[i])&&hash1[s[i]]==t[i]&&hash2.count(t[i])&&hash2[t[i]]==s[i])
                
            {
                continue;
            }
            else
            {
                return false;
            }
        }
        return true;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
