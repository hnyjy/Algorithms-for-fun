//
//  main.cpp
//  Jump Game
//
//  Created by yangjingyi on 12/10/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    bool canJump(vector<int>& nums)
    {
        int truepos=nums.size()-1;
        for(int i=nums.size()-2;i>=0;i--)
        {
            truepos=(i+nums[i])>=truepos?i:truepos;
        }
        return (truepos==0);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
