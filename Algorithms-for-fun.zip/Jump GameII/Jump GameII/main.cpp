//
//  main.cpp
//  Jump GameII
//
//  Created by yangjingyi on 12/9/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
class Solution
{
public:
    int find(vector<int>& index,int start)
    {
        int maxstep=0;
        int maxin=0;
        
        for(int i=0;i<index[start]+1;i++)
        {
            if(maxstep<=start+i+index[i+start])
            {
                maxstep=start+i+index[i+start];
                maxin=start+i;
            }
            //cout<<"max="<<maxin<<endl;
        }
        return maxin;
    }
    int jump(vector<int>& nums)
    {
        int result;
        int i=0;
        int count=0;
        if(nums[0]==0||nums.size()==1)
            return 0;
        if(nums[0]>=nums.size()-1)
            return 1;
        while(i<nums.size())
        {
            
            i=find(nums,i);
            //cout<<"i="<<i<<endl;
            count++;
            //cout<<"count="<<count<<endl;
            if(i+nums[i]>=nums.size()-1)
            {
                
                return count+1;
            }
            
        }
        return count;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    vector<int> in={7,0,9,6,9,6,1,7,9,0,1,2,9,0,3};
    Solution a;
    cout<<a.jump(in)<<endl;
}
