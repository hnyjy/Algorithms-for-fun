//
//  main.cpp
//  Knight Moves
//
//  Created by yangjingyi on 12/10/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <cstring>
#include <queue>
#define MAX 10
#define WHITE 0
#define BLACK 1
using namespace std;
typedef struct
{
    int x,y,count;
}Point;

Point star, endp, cur, nextp;
int color[MAX][MAX];
int ck[8][2]={-1,-2,1,-2,2,1,2,-1,1,2,-1,2,-2,1,-2,-1};
int bfs(void)
{
    memset(color,WHITE,sizeof(color));
    color[star.x][star.y]=BLACK;
    star.count=0;
    queue<Point> q;
    q.push(star);
    while(!q.empty())
    {
        cur=q.front();
        q.pop();
        if(cur.x==endp.x&&cur.y==endp.y)
        {
            return cur.count;
        }
        for(int i=0;i<8;i++)
        {
            nextp.x=cur.x+ck[i][0];
            nextp.y=cur.y+ck[i][1];
            if(color[nextp.x][nextp.y]==BLACK)
            {
                continue;
            }
            if(nextp.x<1||nextp.x>8||nextp.y<1||nextp.y>8)
            {
                continue;
            }
            color[nextp.x][nextp.y]=BLACK;
            nextp.count=cur.count+1;
            if(nextp.x==endp.x&&nextp.y==endp.y)
            {
                return nextp.count;
            }
            q.push(nextp);
        }
    }
    return -1;
}

int main(int argc, const char * argv[]) {
    char st,en;
    int s,e,step;
    while(cin>>st>>s>>en>>e)
    {
        star.x=st-'a'+1;
        star.y=s;
        endp.x=en-'a'+1;
        endp.y=e;
        if(star.x==endp.x&&star.y==endp.y)
        {
            step=0;
        }
        else
        {
            step=bfs();
        }
        cout<<"To get from"<<st<<s<<" to "<<en<<e<<" takes "<<step<<" knight moves."<<endl;
    }
    return 0;
}
