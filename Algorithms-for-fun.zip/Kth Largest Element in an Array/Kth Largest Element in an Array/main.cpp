//
//  main.cpp
//  Kth Largest Element in an Array
//
//  Created by yangjingyi on 1/10/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
#include <vector>
using namespace std;
class Solution
{
public:
    int findKthLargest(vector<int>& nums, int k)
    {
        priority_queue<int> kth(nums.begin(),nums.end());
        for(int i=0;i<k-1;i++)
        {
            kth.pop();
        }
        return kth.top();
        
        
    }
};
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
