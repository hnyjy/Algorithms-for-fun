//
//  main.cpp
//  Kth Smallest Element in a BST
//
//  Created by yangjingyi on 1/16/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    int kthSmallest(TreeNode* root, int& k)
    {
        if(root)
        {
            int x=kthSmallest(root->left,k);
            return !k?x:!--k?root->val:kthSmallest(root->right,k);
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
