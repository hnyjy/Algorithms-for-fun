//
//  main.cpp
//  Kth Smallest Element in a BST2
//
//  Created by yangjingyi on 1/16/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <stack>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    int kthSmallest(TreeNode* root, int k)
    {
        stack<TreeNode*> st;
        TreeNode* p=root;
        while(p||!st.empty())
        {
            while(p)
            {
                st.push(p);
                p=p->left;
            }
            p=st.top();
            if(--k==0)
            {
                return p->val;
            }
            st.pop();
            p=p->right;
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
