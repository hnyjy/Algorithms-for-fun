//
//  main.cpp
//  LRU Cache
//
//  Created by yangjingyi on 12/24/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <list>
#include <unordered_map>
using namespace std;
class LRUCache
{
private:
    typedef list<int> LI;
    typedef pair<int,LI::iterator>PII;
    typedef unordered_map<int ,PII> HIPII;
    HIPII cache;
    LI used;
    int _capacity;
    void touch(HIPII::iterator it)
    {
        int key=it->first;
        used.erase(it->second.second);
        used.push_front(key);
        it->second.second=used.begin();
    }
public:
    LRUCache(int capacity):_capacity(capacity){}
    int get(int key)
    {
        auto it=cache.find(key);
        if(it==cache.end())
        {
            return -1;
        }
        touch(it);
        return it->second.first;
        
    }
    void set(int key, int value)
    {
        auto it=cache.find(key);
        if(it!=cache.end())
        {
            touch(it);
        }
        else
        {
            if(cache.size()==_capacity)
            {
                cache.erase(used.back());
                used.pop_back();
            }
            used.push_front(key);
            
        }
        cache[key]={value,used.begin()};
    }
    
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
