//
//  main.cpp
//  LRU Cache2
//
//  Created by yangjingyi on 12/24/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
using namespace std;
struct LRUCacheNode
{
    int key;
    int value;
    LRUCacheNode *pre;
    LRUCacheNode *next;
    LRUCacheNode():key(0),value(0),pre(NULL),next(NULL){}
};
class LRUCache
{
private:
    unordered_map<int,LRUCacheNode*> m;
    LRUCacheNode* head;
    LRUCacheNode* tail;
    int capacity;
    int count;
public:
    LRUCache(int capacity);
    ~LRUCache();
    int get(int key);
    void set(int key, int value);
private:
    void removeLRUNode();
    void detachNode(LRUCacheNode* node);
    void insertToFront(LRUCacheNode* node);
    
};
LRUCache::LRUCache(int capacity)
{
    this->capacity=capacity;
    this->count=0;
    head=new LRUCacheNode;
    tail=new LRUCacheNode;
    head->pre=NULL;
    head->next=tail;
    tail->next=NULL;
    tail->pre=head;
}
LRUCache::~LRUCache()
{
    delete head;
    delete tail;
}
int LRUCache::get(int key)
{
    if(m.find(key)==m.end())
    {
        return -1;
    }
    else
    {
        LRUCacheNode* node=m[key];
        detachNode(node);
        insertToFront(node);
        return node->value;
    }
}
void LRUCache::set(int key, int value)
{
    if(m.find(key)==m.end())
    {
        LRUCacheNode* node=new LRUCacheNode;
        if(count==capacity)
        {
            removeLRUNode();
        }
        node->key=key;
        node->value=value;
        m[key]=node;
        insertToFront(node);
        ++count;
    }
    else
    {
        LRUCacheNode *node=m[key];
        detachNode(node);
        node->value=value;
        insertToFront(node);
    }
}
void LRUCache::removeLRUNode()
{
    LRUCacheNode* node=tail->pre;
    detachNode(node);
    m.erase(node->key);
    --count;
}
void LRUCache::detachNode(LRUCacheNode* node)
{
    node->pre->next=node->next;
    node->next->pre=node->pre;
}
void LRUCache::insertToFront(LRUCacheNode* node)
{
    node->next=head->next;
    node->pre=head;
    head->next=node;
    node->next->pre=node;
}


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
