//
//  main.cpp
//  Largest BST Substree
//
//  Created by yangjingyi on 3/12/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    int largestBSTSubtree(TreeNode* root)
    {
        int res=0;
        int minval,maxval;
        bool flag=isBST(root,res,minval,maxval);
        return res;
    }
    bool isBST(TreeNode* node, int& res, int &minval,int &maxval)
    {
        if(!node)
        {
            return true;
        }
        int left_size=0,right_size=0;
        int left_minval,left_maxval,right_minval,right_maxval;
        bool left_flag=isBST(node->left,left_size,left_minval,left_maxval);
        bool right_flag=isBST(node->right,right_size,right_minval,right_maxval);
        if(left_flag&&right_flag)
        {
            if((!node->left||node->val>=left_maxval)&&(!node->right||node->val<=right_minval))
            {
                res=left_size+right_size+1;
                minval=node->left?left_minval:node->val;
                maxval=node->right?right_maxval:node->val;
                return true;
            }
        }
        res=max(left_size,right_size);
        return false;
    }
};
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
