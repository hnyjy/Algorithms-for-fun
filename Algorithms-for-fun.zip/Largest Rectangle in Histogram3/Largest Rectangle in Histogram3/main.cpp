//
//  main.cpp
//  Largest Rectangle in Histogram3
//
//  Created by yangjingyi on 12/16/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <stack>
using namespace std;
class Solution
{
public:
int largestRectangleArea(vector<int>& height)
{
   
    height.push_back(0);
    const int size_h=height.size();
    stack<int> stk;
    int i=0,max_a=0;
    while(i<size_h)
    {
        if(stk.empty()||height[i]>=height[stk.top()])
        {
            stk.push(i++);
            
        }
        else
        {
            int h=stk.top();
            stk.pop();
            max_a=max(max_a,height[h]*(stk.empty()?i:i-stk.top()-1));
        }
    }
    return max_a;
}
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
