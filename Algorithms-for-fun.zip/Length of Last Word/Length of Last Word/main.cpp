//
//  main.cpp
//  Length of Last Word
//
//  Created by yangjingyi on 12/12/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    int lengthOfLastWord( string s)
    {
        int result=0;
        if(s.length()==0)
            return 0;
        for(int i=s.length()-1;i>=0;i--)
        {
            if(s[i]!=' ')
            {
                result++;
            }
            if(s[i]==' '&&result!=0)
            {
                return result;
            }
        }
        return result;
    }
};


int main(int argc, const char * argv[]) {
    // insert code here...
    string in=" ";
    Solution a;
    int out=a.lengthOfLastWord(in);
    cout<<out<<endl;
    return 0;
}
