//
//  main.cpp
//  Letter Combinations of a Phone Number
//
//  Created by yangjingyi on 6/30/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//
#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<string> letterCombinations(string digits)
    {
        vector<string> result;
        vector<string> v={"","", "abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};
        result.push_back("");
        for(int i=0;i<digits.size();i++)
        {
            int num=digits[i]-'0';
            if(num<0||num>9)
                break;
            string candidate = v[num];
            if(candidate.empty())
                continue;
            vector<string> tmp;
            for(int j=0;j<candidate.size();j++)
            {
                for(int k=0;k<result.size();k++)
                {
                    tmp.push_back(result[k]+candidate[j]);
                }
            }
            result.swap(tmp);
        }
        return result;
    }
};



int main() {
    
}
