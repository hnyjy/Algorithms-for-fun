//
//  main.cpp
//  Longest Consecutive Sequence
//
//  Created by yangjingyi on 12/22/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
using namespace std;
class Solution
{
public:
    struct int_compare
    {
        bool operator()(const int a, const int b) const
        {
            return a<b;
        }
    };
    int longestConsecutive(vector<int>& nums)
    {
        sort(nums.begin(),nums.end());
        for(int i=0;i<nums.size();i++)
        {
            cout<<nums[i]<<"  ";
        }
        cout<<endl;
        int count=1;
        int pre=nums[0];
        int temp=1;
        for(int i=1;i<nums.size();)
        {
            
            
            while(nums[i]==nums[i-1])
            {
                cout<<"step1"<<endl;
                i++;
            }
            if(nums[i]==pre+1)
            {   cout<<"step2"<<endl;
                temp++;
                count=max(count,temp);
                pre=nums[i];
                i++;
                continue;
            }
            else
            {
                cout<<"step3"<<endl;
                count=max(count,temp);
                cout<<temp<<endl;
                temp=1;
                pre=nums[i];
                i++;
                continue;
            }
        }
        return count;
        
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in={-2,-3,-3,7,-3,0,5,0,-8,-4,-1,2};
    auto it=in.begin()+1;
    Solution a;
    int out=a.longestConsecutive(in);
    cout<<out<<endl;
    
    return 0;
}
