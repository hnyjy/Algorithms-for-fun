//
//  main.cpp
//  Longest Consecutive Sequence2
//
//  Created by yangjingyi on 12/22/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;
class Solution
{
public:
    int longestConsecutive(vector<int> num)
    {
        unordered_map<int,int> m;
        int ret=0;
        for(auto& n:num)
        {
            if(m[n])
            {
                continue;
            }
            if(m.find(n-1)==m.end()&&m.find(n+1)==m.end())
            {
                ret=max(ret,m[n]=1);
                continue;
            }
            if(m.find(n-1)==m.end())
            {
                int r=m[n]=m[n+m[n+1]]=m[n+1]+1;
                ret=max(ret,r);
                continue;
            }
            if(m.find(n-1)==m.end())
            {
                int r=m[n]=m[n-m[n-1]]=m[n-1]+1;
                ret=max(ret,r);
                continue;
            }
            int r=m[n]=m[n-m[n-1]]=m[n+m[n+1]]=1+m[n+1]+m[n-1];
            ret=max(ret,r);
        }
        return ret;
    }
};
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
