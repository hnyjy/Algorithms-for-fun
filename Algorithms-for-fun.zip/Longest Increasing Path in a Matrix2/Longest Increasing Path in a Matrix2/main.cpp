//
//  main.cpp
//  Longest Increasing Path in a Matrix2
//
//  Created by yangjingyi on 3/15/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Soluton
{
public:
    vector<vector<int> >dirs={{1,0},{-1,0},{0,1},{0,-1}};
    int longestIncreasingPath(vector<vector<int> >& matrix)
    {
        int n=matrix.size();
        if(n==0)
        {
            return 0;
        }
        int m=matrix[0].size();
        vector<vector<int> >dp(n,vector<int>(m,0));
        int res=0;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<m;j++)
            {
                res=max(res,help(i,j,matrix,dp));
            }
        }
        return res;
    }
    int help(int i, int j, vector<vector<int> >&matrix, vector<vector<int> > & dp)
    {
        if(dp[i][j])
        {
            return dp[i][j];
        }
        for(auto &dir:dirs)
        {
            int ii=i+dir[0],jj=j+dir[1];
            if(ii<0||ii>=matrix.size()||jj<0||jj>=matrix[0].size())
            {
                continue;
            }
            if(matrix[ii][jj]<=matrix[i][j])
            {
                continue;
            }
            dp[i][j]=max(dp[i][j],help(ii,jj,matrix,dp));
        }
        return ++dp[i][j];
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
