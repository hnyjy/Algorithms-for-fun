//
//  main.cpp
//  Longest Increasing Subsequence
//
//  Created by yangjingyi on 2/12/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int lengthOfLIS(vector<int>& nums)
    {
        vector<int> res;
        for(int i=0;i<nums.size();i++)
        {
            auto it=lower_bound(res.begin(),res.end(),nums[i]);
            if(it==res.end())
            {
                res.push_back(nums[i]);
                
            }
            else
            {
                *it=nums[i];
            }
        }
        return res.size();
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
