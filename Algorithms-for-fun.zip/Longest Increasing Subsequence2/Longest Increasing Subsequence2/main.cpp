//
//  main.cpp
//  Longest Increasing Subsequence2
//
//  Created by yangjingyi on 2/13/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int lengthOfLIS(vector<int>& nums)
    {
        const int size=nums.size();
        if(size==0)
        {
            return 0;
            
        }
        vector<int> dp(size,1);
        int res=1;
        for(int i=1;i<size;i++)
        {
            for(int j=0;j<i;j++)
            {
                if(nums[j]<nums[i])
                {
                    dp[i]=max(dp[i],dp[j]+1);
                }
            }
            res=max(res,dp[i]);
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
