//
//  main.cpp
//  Longest Palindromic Substring
//
//  Created by yangjingyi on 4/16/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    string longestPalindrome(string s)
    {
        string result="";
        string tmp="";
        //int loc=0;
        int i,j;
        //char x;
        const char *inchar=s.c_str();
        for(i=0;i<s.length();i++)
        {
            if(result.length()>(s.length()+3)/2&& i > (s.length()/2)+1)
            {
                //cout<<"i="<<i<<endl;
                break;
            }
            
            
            tmp="";
            
            if(i==0)
            {
                if(*(inchar+i)==*(inchar+i+1))
                {
                    result=s.substr(0,2);
                    
                }
                else
                {
                    result=s.substr(0,1);
                    
                }
                    
            }
            else
            {
                
                  if(*(inchar+i-1)==*(inchar+i+1))
                  {   //cout<<i<<endl;
                      tmp=s.substr(i-1,3);
                      //cout<<*(inchar+i-1)<<endl;
                      //cout<<tmp<<endl;
                     for(j=2;j<i+1&&j<s.length()-i;j++)
                     {
                   
                         if(*(inchar+i-j)==*(inchar+i+j))
                        {
                            tmp=s.substr(i-j,j+j+1);
                        }
                    
                         else
                             break;
                      }
                      //cout<<"i="<<i<<" tmp="<<tmp<<endl;
                    if(tmp.length()>result.length())
                    {
                        result=tmp;
                    }
                  }
                if(i<s.length()-1)
                {
                    if(*(inchar+i)==*(inchar+i+1))
                    {
                        //cout<<"right"<<endl;
                        tmp=s.substr(i,2);
                        for(j=1;j<i+1&&j<s.length()-1-i;j++)
                        {
                            if(*(inchar+i-j)==*(inchar+i+1+j))
                            {
                                tmp=s.substr(i-j,j+j+2);
                            }
                            else
                                break;
                        }
                        if(tmp.length()>result.length())
                        {
                            result=tmp;
                        }
                    }
                }
                
            }
        }
        return result;
    };
};

int main()
{
    Solution a;
    cout<<a.longestPalindrome("ababababa")<<endl;
   
}
