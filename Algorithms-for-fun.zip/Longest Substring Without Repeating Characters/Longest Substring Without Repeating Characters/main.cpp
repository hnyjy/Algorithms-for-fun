//
//  main.cpp
//  Longest Substring Without Repeating Characters
//
//  Created by yangjingyi on 4/9/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <map>

using namespace std;
class Solution
{
public:
    int lengthOfLongestSubstring(string s)
    {
        int len=0;
        int curr=0;
        map<char, int> umap;
        const char *inchar=s.c_str();
        int i,j,k,loc;
        loc=0;
        char x;
        for(i=0;i<s.length();i++)
        {
            x=*(inchar+i);
            if(umap.find(x)==umap.end())
            {
                //cout<<"i="<<i<<endl;
                umap.insert(pair<char, int> (x, i));
                curr++;
                if(curr>len)
                {
                    len=curr;
                }
            }
            else
            {
                //cout<<"i'="<<i<<endl;
                if(curr>len)
                {
                    len=curr;
                }
                k=umap.find(x)->second;
                umap[x]=i;
                for(j=loc;j<k;j++)
                {
                    umap.erase(*(inchar+j));
                }
                loc=k+1;
                curr=i-k;
            }
            //cout<<"when i="<<i<<", curr="<<curr<<" and len="<<len<<endl;
            
        }
        return len;
    }
};
int main()
{
    Solution a;
    string inp="kdgjkjhglfp";
    int outp;
    outp=a.lengthOfLongestSubstring(inp);
    cout<<outp<<endl;
};
