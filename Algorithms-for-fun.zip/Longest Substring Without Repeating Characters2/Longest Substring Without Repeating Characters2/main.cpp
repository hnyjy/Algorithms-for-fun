//
//  main.cpp
//  Longest Substring Without Repeating Characters2
//
//  Created by yangjingyi on 3/13/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int lengthOfLongestSubstring(string s)
    {
        if(s.size()==0)
        {
            return 0;
        }
        int result=0,r=0,l=INT_MIN;
        unordered_map<char, int> map;
        for(int i=0;i<s.size();i++)
        {
            if(map.find(s[i])!=map.end()&&map[s[i]]>=l)
            {
                result=max(result, r-l);
                r++;
                
                l=map[s[i]]+1;
                map[s[i]]=i;
            }
            else
            {
                map[s[i]]=i;
                
                result=max(result,l>=0?r-l+1:r+1);
                
                r++;
            }
        }
        return result;
    }
};
int main(int argc, const char * argv[]) {
    string in="tmmzuxt";
    Solution a;
    int out=a.lengthOfLongestSubstring(in);
    cout<<out<<endl;
    return 0;
}
