//
//  main.cpp
//  Longest Substring with At Most Two Distinct Characters
//
//  Created by yangjingyi on 12/27/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <map>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int lengthOfLongestSubstringTwoDistinct(string s)
    {
        int longest=0;
        int istart=0;
        int i=0;
        map<char,int> cand;
        for(i;i<s.size();i++)
        {
            if(cand.size()==2&&cand.count(s[i])==0)
            {
                longest=max(longest,i-istart);
                for(int j=istart;j<i; j++)
                {
                    if(--cand[s[j]]==0)
                    {
                        cand.erase(s[j]);
                        istart=j+1;
                        break;
                    }
                }
            }
            cand[s[i]]++;
        }
        longest=max(longest,i-istart);
        return longest;
    }
    
};


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
