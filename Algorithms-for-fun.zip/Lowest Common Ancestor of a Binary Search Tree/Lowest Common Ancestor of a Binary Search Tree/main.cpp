//
//  main.cpp
//  Lowest Common Ancestor of a Binary Search Tree
//
//  Created by yangjingyi on 1/17/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q)
    {
        int n=p->val>q->val?p->val:q->val;
        int m=p->val>q->val?q->val:p->val;
        while(root)
        {
            if(n>=root->val&&m<=root->val)
            {
                return root;
            }
            else if(n<root->val)
            {
                root=root->left;
            }
            else
            {
                root=root->right;
            }
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
