//
//  main.cpp
//  Lowest Common Ancestor of a Binary Tree
//
//  Created by yangjingyi on 1/17/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <stack>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
    
};
class Solution
{
public:
    TreeNode* lowestCommonAncestor(TreeNode* root, TreeNode* p, TreeNode* q)
    {
        int n=p->val>q->val?p->val:q->val;
        int m=p->val<q->val?p->val:q->val;
        TreeNode* curr=NULL;
        TreeNode* anc=NULL;
        stack<TreeNode*> stk;
        stack<TreeNode*> stk1;
        stack<TreeNode*> stk2;
        while(root||!stk.empty())
        {
            while(root)
            {
                if(root->val!=n&&root->val!=m)
                {
                    stk.push(root);
                    root=root->left;
                }
                else if(root->val==p->val)
                {
                    curr=p;
                    stk.push(p);
                    break;
                }
                else if(root->val==q->val)
                {
                    curr=q;
                    stk.push(q);
                    break;
                }
            }
            if(!curr)
            {
                root=stk.top();
                stk.pop();
                root=root->right;
                continue;
            }
            else if(curr==p||curr==q)
            {
                break;
            }
        }
        if(curr==p)
        {
            anc=p;
            root=p;
            while(root||stk1.empty())
            {
                while(root)
                {if(root->val!=q->val)
                {
                    stk1.push(root);
                    root=root->left;
                }
                else
                {
                    return anc;
                }}
                root=stk1.top();
                stk1.pop();
                root=root->right;
            }
            while(!stk.empty())
            {
                anc=stk.top();
                stk.pop();
                root=anc->right;
                stack<TreeNode*> stk3;
                while(root||stk3.empty())
                {
                    while(root)
                    {
                        if(root->val!=q->val)
                        {
                            stk3.push(root);
                            root=root->left;
                        }
                        else
                        {
                            return anc;
                        }
                    }
                    root=stk3.top();
                    stk3.pop();
                    root=root->right;
                }
            }
            
        }
        if(curr==q)
        {
            anc=q;
            root=q;
            while(root||stk2.empty())
            {
                while(root)
                {if(root->val!=p->val)
                {
                    stk2.push(root);
                    root=root->left;
                }
                else
                {
                    return anc;
                }}
                root=stk2.top();
                stk2.pop();
                root=root->right;
            }
            while(!stk.empty())
            {
                anc=stk.top();
                stk.pop();
                root=anc->right;
                stack<TreeNode*> stk3;
                while(root||stk3.empty())
                {
                    while(root)
                    {
                        if(root->val!=p->val)
                        {
                            stk3.push(root);
                            root=root->left;
                        }
                        else
                        {
                            return anc;
                        }
                    }
                    root=stk3.top();
                    stk3.pop();
                    root=root->right;
                }
            }
            
        }
        return anc;

    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
