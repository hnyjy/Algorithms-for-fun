//
//  main.cpp
//  MInimum Path Sum
//
//  Created by yangjingyi on 12/12/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int minPathSum(vector<vector<int> >& grid)
    {
        vector<vector<int> > result=grid;
        for(int i=1;i<grid.size();i++)
        {
            result[i][0]=result[i][0]+result[i-1][0];
        }
        for(int i=0;i<grid[0].size();i++)
        {
            result[0][i]=result[0][i]+result[0][i-1];
        }
        for(int i=1;i<grid.size();i++)
        {
            for(int j=1;j<grid[0].size();j++)
            {
                result[i][j]=result[i][j]+min(result[i][j-1],result[i-1][j]);
            }
        }
        return result[grid.size()-1][grid[0].size()-1];
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
