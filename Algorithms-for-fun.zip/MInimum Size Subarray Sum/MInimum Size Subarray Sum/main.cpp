//
//  main.cpp
//  MInimum Size Subarray Sum
//
//  Created by yangjingyi on 1/4/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <climits>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int minSubArrayLen(int s,vector<int>& nums)
    {
        int start=0;
        int res=INT_MAX;
        int sum=0;
        for(int i=0;i<nums.size();i++)
        {
            sum +=nums[i];
            while(sum>=s)
            {
                res=min(res, i-start+1);
                sum-=nums[start++];
                
            }
        }
        return res==INT_MAX?0:res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
