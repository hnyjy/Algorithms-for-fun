//
//  main.cpp
//  MInimum Size Subarray Sum2
//
//  Created by yangjingyi on 1/4/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <climits>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int minSubArrayLen(int s, vector<int>& nums)
    {
        int sum=0;
        int i=1;
        int j=nums.size();
        int min=0;
        while(i<=j)
        {
            int mid=(i+j)/2;
            if(windowExist(mid,nums,s))
            {
                j=mid-1;
                min=mid;
            }
            else
            {
                i=mid+1;
            }
        }
        return min;
    }
private:
    bool windowExist(int size, vector<int>& nums, int s)
    {
        int sum=0;
        for(int i=0;i<nums.size();i++)
        {
            if(i>=size)
            {
                sum -=nums[i-size];
            }
            sum +=nums[i];
            if(sum>=s)
                return true;
        }
        return false;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
