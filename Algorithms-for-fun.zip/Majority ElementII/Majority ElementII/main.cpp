//
//  main.cpp
//  Majority ElementII
//
//  Created by yangjingyi on 1/16/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<int> majorityElement(vector<int>& nums)
    {
        int cnt1=0,cnt2=0;
        int a,b;
        for(int n:nums)
        {
            if(cnt1==0||n==a)
            {
                cnt1++;
                a=n;
            }
            else if(cnt2==0||n==b)
            {
                cnt2++;
                b=n;
                
            }
            else
            {
                cnt1--;
                cnt2--;
            }
        }
        cnt1=cnt2=0;
        for(int n:nums)
        {
            if(n==a)
            {
                cnt1++;
            }
            else if(n==b)
            {
                cnt2++;
            }
        }
        vector<int> result;
        if(cnt1>nums.size()/3)
        {
            result.push_back(a);
        }
        if(cnt2>nums.size()/3)
        {
            result.push_back(b);
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in={1,2,3,2,1,1,1,5,6,7};
    Solution a;
    vector<int> out=a.majorityElement(in);
    for(int i=0;i<out.size();i++)
    {
        cout<<out[i]<<endl;
    }
    
}
