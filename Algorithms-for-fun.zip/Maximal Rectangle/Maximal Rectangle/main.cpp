//
//  main.cpp
//  Maximal Rectangle
//
//  Created by yangjingyi on 12/16/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <stack>
using namespace std;
class Solution
{
public:
    int maximalRectangle(vector<vector<char> >& matrix)
    {
        if(matrix.size()==0||matrix[0].size()==0)
        {
            return 0;
        }
        int clen=matrix[0].size();
        int rlen=matrix.size();
        vector<int> h(clen+1,0);
        int res=0;
        for(int i=0;i<rlen;i++)
        {
            stack<int> stk;
            for(int j=0;j<clen+1;j++)
            {
                if(j<clen)
                {
                    if(matrix[i][j]=='1')
                    {
                        h[j]+=1;
                    }
                    else
                    {
                        h[j]=0;
                    }
                }
                if(stk.empty()||h[stk.top()]<=h[j])
                {
                    stk.push(j);
                }
                else
                {
                    while(!stk.empty()&&h[j]<h[stk.top()])
                    {
                        int top=stk.top();
                        stk.pop();
                        int area=h[top]*(stk.empty()?j:(j-stk.top()-1));
                        if(area>res)
                        {
                            res=area;
                        }
                    }
                    stk.push(j);
                }
            }
            
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
