//
//  main.cpp
//  Maximal Square
//
//  Created by yangjingyi on 1/14/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int maximalSquare(vector<vector<char> >& matrix)
    {
        int m=matrix.size();
        if(!m)
        {
            return 0;
        }
        int n=matrix[0].size();
        vector<int> pre(m,0);
        vector<int> cur(m,0);
        int maxsize=0;
        for(int i=0;i<m;i++)
        {
            pre[i]=matrix[i][0]-'0';
            maxsize=max(maxsize,pre[i]);
        }
        for(int j=1;j<n;j++)
        {
            cur[0]=matrix[0][j]-'0';
            maxsize=max(maxsize,cur[0]);
            for(int i=1;i<m;i++)
            {
                if(matrix[i][j]=='1')
                {
                    cur[i]=min(cur[i-1],min(pre[i-1],pre[i]))+1;
                    maxsize=max(maxsize, cur[i]);
                }
            }
            swap(pre,cur);
            fill(cur.begin(),cur.end(),0);
        }
        return maxsize*maxsize;
        
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
