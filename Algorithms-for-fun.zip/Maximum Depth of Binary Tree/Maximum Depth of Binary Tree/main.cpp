//
//  main.cpp
//  Maximum Depth of Binary Tree
//
//  Created by yangjingyi on 12/19/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    int maxDepth(TreeNode* root)
    {
        return root?1+max(maxDepth(root->left),maxDepth(root->right)):0;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
