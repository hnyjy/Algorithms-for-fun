//
//  main.cpp
//  Maximum Gap
//
//  Created by yangjingyi on 12/27/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>
using namespace std;
class Solution
{
public:
    int maximumGap(vector<int>& nums)
    {
        if(nums.size()<=2)
        {
            return 0;
        }
        int n=nums.size();
        auto lu=minmax_element(nums.begin(),nums.end());
        int l=*lu.first,u=*lu.second;
        int gap=max((u-l)/(n-1),1);
        int m=(u-l)/gap+1;
        vector<int> bucketsMin(m,INT_MAX);
        vector<int> bucketsMax(m,INT_MIN);
        for(int num:nums)
        {
            int k=(num-l)/gap;
            if(num<bucketsMin[k]) bucketsMin[k]=num;
            if(num>bucketsMax[k]) bucketsMax[k]=num;
        }
        int i=0,j;
        gap=bucketsMax[0]-bucketsMin[0];
        while(i<m)
        {
            j=i+1;
            while(j<m && bucketsMin[j]==INT_MAX && bucketsMax[j]==INT_MIN)
            {
                j++;
            }
            if(j==m)
            {
                break;
            }
            gap=max(gap,bucketsMin[j]-bucketsMax[i]);
            i=j;
        }
        return gap;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
