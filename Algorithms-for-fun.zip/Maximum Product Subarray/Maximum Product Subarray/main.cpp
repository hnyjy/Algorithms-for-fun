//
//  main.cpp
//  Maximum Product Subarray
//
//  Created by yangjingyi on 12/26/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int maxProduct(vector<int>& nums)
    {
        int r=nums[0];
        for(int i=1, imax=r,imin=r;i<nums.size();i++)
        {
            if(nums[i]<0)
            {
                swap(imax,imin);
            }
            imax=max(nums[i],imax*nums[i]);
            imin=min(nums[i],imin*nums[i]);
            r=max(r,imax);
        }
        return r;
    }
                  
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
