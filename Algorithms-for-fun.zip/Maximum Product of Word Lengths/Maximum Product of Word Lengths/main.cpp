//
//  main.cpp
//  Maximum Product of Word Lengths
//
//  Created by yangjingyi on 2/24/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>
using namespace std;
class Solution
{
public:
     int maxProduct(vector<string>& words)
    {
        vector<int> mask(words.size());
        int result=0;
        for(int i=0;i<words.size();i++)
        {
            for(char c:words[i])
            {
                mask[i]|=(1<<(c-'a'));
            }
            for(int j=0;j<i;j++)
            {
                if(!(mask[i]&mask[j]))
                {
                    result=max(result,int(words[i].size()*words[j].size()));
                }
            }
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
