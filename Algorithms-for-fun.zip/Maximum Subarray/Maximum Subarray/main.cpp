//
//  main.cpp
//  Maximum Subarray
//
//  Created by yangjingyi on 12/10/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int maxSubArray(vector<int>& nums)
    {
        int result,count;
        result=count=nums[0];
        int i;
        for(i=0;i<nums.size();i++)
        {
            if(count<0)
            {
                count=nums[i];
                result=max(result,count);
                
            }
            else
            {
                count=count+nums[i];
                result=max(result,count);
            }
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    vector<int> in={-2,1,-3,4,-1,2,1,-5,4};
    Solution a;
    int out;
    out=a.maxSubArray(in);
    cout<<out<<endl;
    return 0;
}
