//
//  main.cpp
//  Median of Two Sorted Arrays
//
//  Created by yangjingyi on 4/11/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    double findMedian(int C[], int o)
    {
        if(o%2==0)
        {
            return((static_cast<double>(C[o/2-1]+C[o/2]))/2);
            
        }
    
        else
            return(static_cast<double>(C[(o-1)/2]));
    }
    double findMedianSortedArrays(int A[], int m, int B[],int n)
    {
        double resoult;
        
        if(m<n)
        {
            //cout<<"step1"<<endl;
            return findMedianSortedArrays(B,n,A,m);
            
        }
        if((n%2==0&&m%2==0&&B[n/2-1]>A[m/2-1]&&B[n/2]<A[m/2]))
        {
            //cout<<"step"<<endl;
            return (static_cast<double>(B[n/2-1]+B[n/2]))/2;
        }
        else if((n%2==0&&m%2==0&&B[n/2-1]<A[m/2-1]&&B[n/2]>A[m/2]))
        {
            
            return (static_cast<double>(A[m/2-1]+A[m/2]))/2;
        }
        else if(n==1&&m>1&&m%2!=0)
        {
            if (A[m/2-1]>B[0]||A[m/2-1]==B[0])
            {
                return findMedian(A,m-1);
            }
           
            else if(A[m/2+1]<B[0]||A[m/2+1]==B[0])
                return findMedian(A+1,m-1);
            else
                return (static_cast<double>(A[m/2]+B[0]))/2;
        }
        else if(n==1&&m>1&&m%2==0)
        {
            if (A[m/2-1]>B[0]||A[m/2-1]==B[0])
            {
                return A[m/2-1];
            }
            else if((A[m/2-1]<B[0]||A[m/2-1]==B[0])&&(A[m/2]>B[0]||A[m/2]==B[0]))
                    return B[0];
            else
                return A[m/2];
            
        }
       
      
        else if(n==1&&m==1)
            
        {
            cout<<"step1"<<endl;
            return (static_cast<double> (A[0]+B[0]))/2;
        }
        if(n==0)
        {
            return findMedian(A,m);
        }
        if(findMedian(A,m)>findMedian(B,n))
        {
            //cout<<"step2"<<endl;
            return findMedianSortedArrays (A,m-n/2,B+n/2,n-n/2);
            
        }
        else if(findMedian(A,m)==findMedian(B,n))
        {
            
            return findMedian(A,m);
        }
        
        else
        {
            return findMedianSortedArrays(A+n/2,m-n/2,B,n-n/2);
        }
    };
};

int main()
{
    Solution a;
    int in1[4]={1,2,6,7};
    int in2[4]={3,4,5,8};
    cout<<a.findMedianSortedArrays(in1,4,in2,4)<<endl;
    
}
