//
//  main.cpp
//  Median of Two Sorted Arrays2
//
//  Created by yangjingyi on 3/13/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    double findMedianSortedArrays(vector<int>& nums1, vector<int>& nums2)
    {
        vector<int>::iterator a=nums1.begin();
        vector<int>::iterator b=nums2.begin();
        int total=nums1.size()+nums2.size();
        if(total&0x1)
        {
            return findkth(a,nums1.size(),b,nums2.size(),total/2+1);
        }
        else
        {
            return (findkth(a,nums1.size(),b,nums2.size(),total/2)+findkth(a,nums1.size(),b,nums2.size(),total/2+1));
        }
    }
    double findkth(vector<int>::iterator a, int m, vector<int>::iterator b, int n, int k)
    {
        if(m>n)
        {
            return findkth(b,n,a,m,k);
        }
        if(m==0)
        {
            return b[k-1];
        }
        if(k==1)
        {
            return min(*a,*b);
        }
        int pa=min(k/2,m),pb=k-pa;
        if(*(a+pa-1)<*(b+pa-1))
        {
            return findkth(a+pa,m-pa,b,n,k-pa);
        }
        else if(*(a+pa-1)>*(b+pb-1))
        {
            return findkth(a,m,b+pa,n-pb,k-pb);
        }
        else
        {
            return *(a+pa-1);
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
