//
//  main.cpp
//  Meeting Rooms
//
//  Created by yangjingyi on 1/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <map>
using namespace std;
struct Interval
{
    int start;
    int end;
    Interval():start(0),end(0){}
    Interval(int x, int y):start(x),end(y){}
};
class Solution
{
public:
    bool canAttendMeetings(vector<Interval>& intervals)
    {
        map<int,int> m;
        for(int i=0;i<intervals.size();i++)
        {
            m[intervals[i].start]=intervals[i].end;
        }
        if(m.size()<intervals.size())
        {
            return false;
        }
        int tmp=0;
        for(map<int,int>::iterator it=m.begin();it!=m.end();++it)
        {
            if(tmp>it->first)
            {
                return false;
            }
            tmp=it->second;
        }
        return true;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
