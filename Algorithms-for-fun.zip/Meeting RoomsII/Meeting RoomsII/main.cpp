//
//  main.cpp
//  Meeting RoomsII
//
//  Created by yangjingyi on 1/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
#include <vector>
using namespace std;
struct Interval
{
    int start;
    int end;
    Interval():start(0),end(0){}
    Interval(int x,int y):start(x),end(y){}
};
class Solution
{
public:
    int minMeetingRooms(vector<Interval>& intervals)
    {
        sort(intervals.begin(),intervals.end(),[](Interval &i, Interval &j){return i.start<j.start;});
        priority_queue<int,vector<int>, greater<int>> min_heap;
        for(Interval interval:intervals)
        {
            if(!min_heap.empty()&&min_heap.top()<=interval.start)
            {
                min_heap.pop();
            }
            min_heap.push(interval.end);
        }
        return min_heap.size();
    }
};


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
