//
//  main.cpp
//  Meeting RoomsII2
//
//  Created by yangjingyi on 1/26/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
using namespace std;
struct Interval
{
    int start;
    int end;
    Interval():start(0),end(0){}
    Interval(int x,int y):start(x),end(y){}
};
class Solution
{
public:
    int minMeetingRooms(vector<Interval> & intervals)
    {
        map<int,int> mp;
        for(int i=0;i<intervals.size();i++)
        {
            mp[intervals[i].start]++;
            mp[intervals[i].end]--;
        }
        int cnt=0,maxCnt=0;
        for(auto it=mp.begin();it!=mp.end();it++)
        {
            cnt +=it->second;
            maxCnt=max(cnt,maxCnt);
        }
        return maxCnt;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
