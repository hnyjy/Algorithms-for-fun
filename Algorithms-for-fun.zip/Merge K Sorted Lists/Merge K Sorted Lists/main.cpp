//
//  main.cpp
//  Merge K Sorted Lists
//
//  Created by yangjingyi on 9/4/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode(int x):val(x),next(NULL)
    {
        
    }
};

class Solution
{
public:
    ListNode* mergeTwoLists(ListNode* l1, ListNode* l2)
    {
        ListNode head(0);
        ListNode* cur=&head;
        
        if(l1==NULL)
            return l2;
        if(l2==NULL)
            return l1;
        while(l1!=NULL&&l2!=NULL)
        {
            if(l1->val<l2->val)
            {
                cur->next=l1;
                l1=l1->next;
            }
            else
            {
                cur->next=l2;
                l2=l2->next;
            }
            cur=cur->next;
            
        }
        cur->next=l1!=NULL?l1:l2;
        return head.next;
    }

    /*ListNode* mergeLists(vector<ListNode*>& lists,vector<ListNode*>& vec )
    {
        
        lists=vec;
        vec.clear();
        if(lists.size()%2==0)
        {
            for(int i=0;i<lists.size()-1;i+=2)
            {
                vec.push_back(mergeTwoLists(lists[i],lists[i+1]));
            }
        
        }
        else
        {
            for(int i=0;i<lists.size()-2;i+=2)
            {
                vec.push_back(mergeTwoLists(lists[i],lists[i+1]));
            }
            vec.push_back(lists[lists.size()-1]);
        }
        if(vec.size()==1)
        {
            return vec[0];
        }
        else
        {
            return mergeLists(lists,vec);
        }
    }*/
    ListNode* mergeKLists(vector<ListNode*>& lists)
    {
       if(lists.size()==0)
        {
            return NULL;
        }
        for(int num=lists.size();num>1;)
        {
            for(int i=0;i<=num/2-1;i++)
            {
                lists[i]=mergeTwoLists(lists[i],lists[num-1-i]);
            }
            if(num%2==0)
            {
                num/=2;
            }
            else
            {
                num=num/2+1;
            }
        }
        return lists[0];
    }
};
int main()
{
    
}
