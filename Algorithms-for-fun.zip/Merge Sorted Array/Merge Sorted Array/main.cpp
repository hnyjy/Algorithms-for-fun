//
//  main.cpp
//  Merge Sorted Array
//
//  Created by yangjingyi on 12/16/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    void merge(vector<int>& nums1, int m, vector<int>& nums2, int n)
    {
        int i=m-1,j=n-1,tar=m+n-1;
        while(j>=0)
        {
            nums1[tar--]= i>=0&&nums1[i]>nums2[j]?nums1[i--]:nums2[j--];
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
