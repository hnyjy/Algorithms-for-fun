//
//  main.cpp
//  Merge k Sorted Lists2
//
//  Created by yangjingyi on 9/10/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
#include <vector>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode(int x):val(x),next(NULL)
    {
        
    }
};
struct compare
{
    bool operator()(const ListNode *l1,const ListNode *l2)
    {
        return l1->val > l2->val;
    }
   
};
ListNode* mergeKLists(vector<ListNode*> &lists)
{
    priority_queue<ListNode *, vector<ListNode *>, compare> min_heap;
    for(auto l:lists)
    {
        if(l)
        {
            min_heap.push(l);
        }
    }
    ListNode *head=nullptr;
    ListNode **prev=&head;
    while(!min_heap.empty())
    {
        *prev = min_heap.top();
        min_heap.pop();
        prev=&(*prev)->next;
        if(*prev)
        {
            min_heap.push(*prev);
        }
        
    }
    return head;
}

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
