//
//  main.cpp
//  Min Stack
//
//  Created by yangjingyi on 12/27/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <climits>
using namespace std;
struct MinStackNode
{
    int val;
    MinStackNode * pre;
    MinStackNode * next;
    MinStackNode():val(0),pre(NULL),next(NULL){}
    MinStackNode(int x):val(x),pre(NULL),next(NULL){}
};
class MinStack
{
    int minval;
    int size;
    MinStackNode * head;
    MinStackNode * tail;
    
public:
    MinStack()
    {
        this->size=0;
        this->minval=INT_MAX;
        head=new MinStackNode;
        tail=new MinStackNode;
        head->next=tail;
        head->pre=NULL;
        tail->pre=head;
        tail->next=NULL;
        
        
    }
    MinStack(int size)
    {
        this->size=size;
        this->minval=INT_MAX;
        head=new MinStackNode;
        tail=new MinStackNode;
        head->next=tail;
        head->pre=NULL;
        tail->pre=head;
        tail->next=NULL;
    }
    /*~MinStack()
    {
        delete head;
        delete tail;
    }*/
    void push(int x)
    {
        MinStackNode *tmp=new MinStackNode(x);
        //MinStackNode *tmp1=tail->pre;
        tail->next=tmp;
        tmp->pre=tail;
        
        tail=tmp;
        tail->next=NULL;
        size++;
        if(x<minval)
        {
            minval=x;
        }
    }
    int findMin(MinStackNode* head)
    {
        MinStackNode *tmp=head->next;
        while(tmp)
        {
            minval=min(minval,tmp->val);
            tmp=tmp->next;
            
        }
        return minval;
    }
    void pop()
    {
        
        //MinStackNode *tmp=tail;
        if(tail)
        {
            MinStackNode *tmp2=tail->pre;
            tmp2->next=NULL;
            delete tail;
            tail=tmp2;
            size--;
        }
        
        minval=findMin(head);
    }
    int top()
    {
        return tail->val;
    }
    int getMin()
    {
        return minval;
    }
};

int main(int argc, const char * argv[]) {
    MinStack a;
    a.push(2);
    a.push(0);
    a.push(3);
    a.push(0);
    
    int out=a.getMin();
    a.pop();
    cout<<out<<endl;
    int out2=a.getMin();
    cout<<out2<<endl;
    a.pop();
    int out3=a.getMin();
    
    cout<<out3<<endl;
    a.pop();
    int out4=a.getMin();
    cout<<out4<<endl;
    
}
