//
//  main.cpp
//  Min Stack2
//
//  Created by yangjingyi on 12/27/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <stack>
using namespace std;
class MinStack
{
private:
    stack<int> s1;
    stack<int> s2;
public:
    void push(int x)
    {
        s1.push(x);
        if(s2.empty()||x<=getMin())
        {
            s2.push(x);
        }
    }
    void pop()
    {
        if(s1.top()==getMin())
        {
            s2.pop();
        }
        s1.pop();
    }
    int top()
    {
        return s1.top();
    }
    int getMin()
    {
        return s2.top();
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
