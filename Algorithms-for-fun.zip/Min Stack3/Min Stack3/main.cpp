//
//  main.cpp
//  Min Stack3
//
//  Created by yangjingyi on 12/27/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
using namespace std;
struct Node
{
    int value;
    int minval;
    Node* next;
    Node(int x, int y):value(x),minval(y),next(NULL){}
};
class Minstack
{
public:
    Node* head=NULL;
    void push(int x)
    {
        if(!head)
        {
            head=new Node(x,x);
        }
        else
        {
            Node* n=new Node(x,min(head->minval,x));
            n->next=head;
            head=n;
        }
    }
    void pop()
    {
        if(head)
        {
            head=head->next;
        }
    }
    int top()
    {
        if(head)
        {
            return head->value;
        }
        else
        {
            return -1;
        }
    }
    int getMin()
    {
        if(head)
        {
            return head->minval;
        }
        else
        {
            return -1;
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
