//
//  main.cpp
//  Missing Number
//
//  Created by yangjingyi on 2/1/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <numeric>
using namespace std;
class Solution
{
public:
    int missingNumber(vector<int>& nums)
    {
        long n=nums.size();
        return n*(n+1)/2- accumulate(nums.begin(),nums.end(),0);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
