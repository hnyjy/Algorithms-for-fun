//
//  main.cpp
//  Missing Ranges
//
//  Created by yangjingyi on 12/27/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<string> findMissingRanges(vector<int>& nums, int lower, int upper)
    {
        lower--;
        upper++;
        vector<string> res;
        nums.push_back(upper);
        int pre=lower;
        for(int i=0;i<nums.size();++i)
        {
            if(nums[i]<pre+1)
            {
                pre=nums[i];
                continue;
            }
            if(nums[i]==pre+2)
            {
                res.push_back(to_string(pre+1));
            }
            else
            {
                res.push_back(to_string(pre+1)+"->"+to_string(nums[i]-1));
            }
            pre=nums[i];
        }
        nums.pop_back();
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
