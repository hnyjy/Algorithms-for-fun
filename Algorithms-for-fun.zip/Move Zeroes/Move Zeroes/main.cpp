//
//  main.cpp
//  Move Zeroes
//
//  Created by yangjingyi on 2/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    void moveZeroes(vector<int>& nums)
    {
        if(nums.size()==0)
        {
            return;
        }
        int pre=0,cur=0;
        while(cur<nums.size())
        {
            if(nums[cur]!=0)
            {
                swap(nums[pre],nums[cur]);
                pre++;
            }
            cur++;
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
