//
//  main.cpp
//  Multiply Strings
//
//  Created by yangjingyi on 12/8/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    string multiply(string num1, string num2)
    {
        string res;
        int i,j;
        int m=num1.size(), n=num2.size();
        vector<int> resv(m+n,0);
        reverse(num1.begin(),num1.end());
        reverse(num2.begin(),num2.end());
        for(i=0;i<m;i++)
        {
            for(j=0;j<n;j++)
            {
                resv[i+j]+=(num1[i]-'0')*(num2[j]-'0');
                resv[i+j+1]+=resv[i+j]/10;
                resv[i+j]%=10;
            }
        }
        for(i=m+n-1;i>0&&resv[i]==0;i--)
        {
            ;
        }
        for(;i>=0;i--)
        {
            res+=to_string(resv[i]);
        }
        
        return res;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
