//
//  main.cpp
//  N-Queens
//
//  Created by yangjingyi on 12/10/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
//#include <stdlib.h>
//#include <stdio.h>
#include <cmath>
using namespace std;
class Solution
{
    bool check(int y, vector<int> step)
    {
        //bool flag=true;
        int i;
        int j=step.size();
        if(step.size()==0)
        {
            return true;
        }
        for(i=0;i<step.size();i++)
        {
            if((y==step[i])||abs(i-j)==abs(step[i]-y))
            {
                return false;
            }
        }
        //int result=abs(0-4);
        return true;
    };
    void constructQueen(int row,int x,vector<int>& step,vector<vector<string> >& resstr)
    {
        
        
        
        if(row==x+1)
        {
            vector<string> tmpvstr;
            //resf.push_back(resv);
            for(int i=0;i<step.size();i++)
            {
                
                string tmp(x,'.');
                tmp[step[i]-1]='Q';
                tmpvstr.push_back(tmp);
                
            }
            resstr.push_back(tmpvstr);
            tmpvstr.clear();
        }
        
        else
        {
            for(int k=0;k<x;k++)
            {
                if(check(k,step))
                {
                    step.push_back(k);
                    constructQueen(step.size()+1,x,step,resstr);
                    step.pop_back();
                }
                   
            }
        }
    }
    
public:
    vector<vector<string> > solveNQueens(int n)
    {
        vector<int> st;
        vector<vector<int> > resv;
        vector<vector<string> >result;
        constructQueen(0,n,st,result);
        return result;
        
    }
};

int main(int argc, const char * argv[]) {
    int in=4;
    vector<vector<string> > out;
    Solution a;
    out=a.solveNQueens(in);
    for(int i=0;i<out.size();i++)
    {
        cout<<"solution "<<"i:"<<endl;
        for(int j=0;j<out[i].size();i++)
        {
            cout<<out[i][j]<<endl;
        }
    }
    return 0;
}
