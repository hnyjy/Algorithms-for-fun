//
//  main.cpp
//  Next Permutation
//
//  Created by yangjingyi on 12/6/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    void nextPermutation(vector<int>& nums)
    {
        int l, r;
        l=r=nums.size()-1;
        while(r>0&&nums[r]<=nums[r-1])
            r--;
        if(r==0)
        {
            reverse(nums.begin(), nums.end());
            return;
        }
        while(l>=r&&nums[l]<=nums[r-1])
            l--;
        swap(nums[l],nums[r-1]);
        sort(nums.begin()+r,nums.end());
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
