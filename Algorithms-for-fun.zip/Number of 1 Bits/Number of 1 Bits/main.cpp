//
//  main.cpp
//  Number of 1 Bits
//
//  Created by yangjingyi on 1/1/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    int hammingWeight(uint32_t n)
    {
        n=((n&0xAAAAAAAA)>>1)+(n&0x55555555);
        n=((n&0xCCCCCCCC)>>2)+(n&0x33333333);
        n=((n&0xF0F0F0F0)>>4)+(n&0x0F0F0F0F);
        n=((n&0xFF00FF00)>>8)+(n&0x00FF00FF);
        n=((n&0xFFFF0000)>>16)+(n&0x0000FFFF);
        return n;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
