//
//  main.cpp
//  Number of Connected Components in an Undirected Graph
//
//  Created by yangjingyi on 2/26/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <numeric>
using namespace std;
class Solution
{
public:
    int countComponents(int n, vector<pair<int, int> >& edges)
    {
        vector<int> p(n);
        vector<int> root(n,-1);
        iota(p.begin(),p.end(),0);
        for(auto& edge:edges)
        {
            int v=edge.first,w=edge.second;
            while(p[v]!=v)
            {
                v=p[v]=p[p[v]];
            }
            while(p[w]!=w)
            {
                w=p[w]=p[p[w]];
            }
            p[v]=w;
            n-=v!=w;
        }
        return n;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
