//
//  main.cpp
//  Number of Digit One
//
//  Created by yangjingyi on 1/16/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    int countDigitOne(int n)
    {
        int ones=0,m=1,r=1;
        while(n>0)
        {
            ones +=(n+8)/10*m+(n%10==1)*r;
            r +=n%10*m;
            m *=10;
            n /=10;
        }
        return ones;
        
    }
};

int main(int argc, const char * argv[]) {
    int in=200;
    Solution a;
    int out=a.countDigitOne(in);
    cout<<out<<endl;
    return 0;
}
