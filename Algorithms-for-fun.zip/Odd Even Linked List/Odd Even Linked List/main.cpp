//
//  main.cpp
//  Odd Even Linked List
//
//  Created by yangjingyi on 3/4/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode(int x):val(x),next(NULL){}
};
class Solution
{
public:
    ListNode* oddEvenList(ListNode* head)
    {
        int count=1;
        ListNode *cur=head;
        ListNode *pre=head;
        ListNode *fhead=head->next;
        while(cur&&cur->next)
        {
            if(count%2!=0)
            {
                
                cur=cur->next;
                count++;
            }
            else
            {
                ListNode *temp1=cur->next;
                ListNode *temp2=cur->next->next;
                pre->next=temp1;
                temp1->next=fhead;
                cur->next=temp2;
                pre=pre->next;
                //cur=cur->next;
                count++;
            }
        }
        return head;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
