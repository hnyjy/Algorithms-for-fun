//
//  main.cpp
//  One Edit Distance
//
//  Created by yangjingyi on 12/27/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    bool isOneEditDistance(string s,string t)
    {
        int i,j;
        for( i=0,j=0;i<s.length();i++,j++)
        {
            if(s[i]!=t[j])
            {
                break;
            }
        }
        i--;
        j--;
        int dis=s.length()-t.length();
        if(dis>=0)
        {
            i++;
        }
        if(dis<=0)
        {
            j++;
        }
        return s[i]!=t[j]&&!strcmp(&s[i],&t[j]);
    }
};

int main(int argc, const char * argv[]) {
    int i=0;
    for(i=0;i<5;)
    {
        i++;
        cout<<i<<endl;
    }
    //cout<<i<<endl;
    return 0;
}
