//
//  main.cpp
//  Paint Fence
//
//  Created by yangjingyi on 2/2/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    int numWays(int n, int k)
    {
        if(n<=1||k==0)
        {
            return n*k;
        }
        int a=k,b=k*(k-1),c=0,d=0;
        for(int i=2;i<n;i++)
        {
            d=(k-1)*(a+b);
            a=b;
            b=d;
        }
        return a+b;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
