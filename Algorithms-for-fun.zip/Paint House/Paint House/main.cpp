//
//  main.cpp
//  Paint House
//
//  Created by yangjingyi on 1/27/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int minCost(vector<vector<int> >& costs)
    {
        if(costs.empty())
        {
            return 0;
        }
        int n=costs.size();
        for(int i=1;i<n;i++)
        {
            costs[i][0]+=min(costs[i-1][1],costs[i-1][2]);
            costs[i][1]+=min(costs[i-1][0],costs[i-1][2]);
            costs[i][2]+=min(costs[i-1][0],costs[i-1][1]);
        }
        return min(costs[n-1][0],min(costs[n-1][1],costs[n-1][2]));
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
