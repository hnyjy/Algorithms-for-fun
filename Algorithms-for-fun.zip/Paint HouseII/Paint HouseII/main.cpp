//
//  main.cpp
//  Paint HouseII
//
//  Created by yangjingyi on 1/31/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int minCostII(vector<vector<int> >& costs)
    {
        if(costs.size()==0)
        {
            return 0;
        }
        int n=costs.size();
        int k=costs[0].size();
        int min1=-1,min2=-1;
        for(int i=0;i<n;i++)
        {
            int lastmin1=min1,lastmin2=min2;
            min1=min2=-1;
            for(int j=0;j<k;j++)
            {
                if(lastmin1!=j)
                {
                    costs[i][j]+=(lastmin1==-1)?0:costs[i-1][lastmin1];
                    
                }
                else
                {
                    costs[i][j]+=(lastmin2==-1)?0:costs[i-1][lastmin2];
                }
                if(min1==-1||costs[i][min1]>costs[i][j])
                {
                    min2=min1;
                    min1=j;
                }
                else if(min2==-1||costs[i][min2]>costs[i][j])
                {
                    min2=j;
                }
            }
        }
        return costs[n-1][min1];
    }
    
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
