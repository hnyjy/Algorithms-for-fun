//
//  main.cpp
//  Palindroe Partitioning
//
//  Created by yangjingyi on 12/22/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    void dfs(int index,string& s,vector<string>& tmp,vector<vector<string> >&result)
    {
        if(index==s.size())
        {
            result.push_back(tmp);
            return;
        }
        for(int i=index;i<s.size();++i)
        {
            if(isPalindrome(s,index,i))
            {
                tmp.push_back(s.substr(index,i-index+1));
                dfs(i+1,s,tmp,result);
                tmp.pop_back();
            }
               
        }
    }
    bool isPalindrome(const string& s, int start,int end)
    {
        while(start<=end)
        {
            if(s[start++]!=s[end--])
            {
                return false;
            }
        }
        return true;
    }
    vector<vector<string> > partition(string s)
    {
        vector<vector<string> > result;
        if(s.empty())
        {
            return result;
        }
        vector<string> tmp;
        dfs(0,s,tmp,result);
        return result;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
