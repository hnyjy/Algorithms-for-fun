//
//  main.cpp
//  Palindrome Number
//
//  Created by yangjingyi on 3/14/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    bool isPalindrome(int x)
    {
        if(x<0||(x!=0&&x%10==0))
        {
            return false;
        }
        int sum=0;
        while(x>sum)
        {
            sum=sum*10+x%10;
            x=x/10;
        }
        return (x==sum)||(x=sum/10);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
