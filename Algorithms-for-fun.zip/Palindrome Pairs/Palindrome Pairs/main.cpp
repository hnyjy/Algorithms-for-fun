//
//  main.cpp
//  Palindrome Pairs
//
//  Created by yangjingyi on 3/12/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
#include <set>
using namespace std;
class Solution
{
public:
    vector<vector<int> > palindromePairs(vector<string>& words)
    {
        vector<vector<int> > result;
        if(words.size()==0)
        {
            return result;
            
        }
        unordered_map<string, int> map;
        for(int i=0;i<words.size();i++)
        {
            map[words[i]]=i;
        }
        for(int i=0;i<words.size();i++)
        {
            
            int l=0,r=0;
            while(l<=r)
            {
                string tmp=words[i].substr(l,r-l);
                reverse(tmp.begin(),tmp.end());
                
                if(map.find(tmp)!=map.end()&&map[tmp]!=i&&isPalindrome(words[i].substr(l==0?r:0,l==0?words[i].size()-r+1:l)))
                {
                    int j=map[tmp];
                    vector<int> tresult1={i,j};
                    vector<int> tresult2={j,i};
                    result.push_back(l==0?tresult1:tresult2);
                }
                if(r<words[i].size())
                {
                    r++;
                }
                else
                {
                    l++;
                }
                
                
            }
            
        }
        return result;
        
    }
    bool isPalindrome(string s)
    {
        for(int i=0;i<s.length()/2;i++)
        {
            if(s[i]!=s[s.length()-1-i])
            {
                return false;
            }
        }
        return true;
    }
};

int main(int argc, const char * argv[]) {
    vector<string> in={"abcd", "dcba", "lls", "s", "sssll"};
    Solution a;
    vector<vector<int> > out=a.palindromePairs(in);
    for(auto out1:out)
    {
        for(int i=0;i<out1.size();i++)
        {
            cout<<out1[i]<<" ";
        }
        cout<<endl;
    }
    return 0;
}
