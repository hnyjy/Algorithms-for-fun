//
//  main.cpp
//  Palindrome Partitioning
//
//  Created by yangjingyi on 12/22/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<vector<string> > partition(string s)
    {
        vector<vector<string> > res;
        vector<string> tmp;
        getPartition(s,0,tmp,res);
        return res;
        
    }
private:
    void getPartition(string s, int idx, vector<string>& tmp,vector<vector<string> >& res)
    {
        if(idx==s.size())
        {
            res.push_back(tmp);
            return;
        }
        for(int i=idx,n=s.length();i<n;i++)
        {
            int l=idx,r=i;
            while(l<r&&s[l]==s[r])
            {
                l++;
                r--;
            }
            if(l>=r)
            {
                tmp.push_back(s.substr(idx,i-idx+1));
                getPartition(s,i+1,tmp,res);
                tmp.pop_back();
            }
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
