//
//  main.cpp
//  Palindrome Permutation
//
//  Created by yangjingyi on 1/31/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
using namespace std;
class Solution
{
public:
    bool canPermutePalindrome(string s)
    {
        unordered_map<char, int> hash;
        for(auto i:s)
        {
            hash[i]++;
        }
        int odd=0;
        for(auto j:hash)
        {
            if(j.second%2!=0)
            {
                odd++;
            }
        }
        if(odd>1)
            return false;
        else
            return true;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
