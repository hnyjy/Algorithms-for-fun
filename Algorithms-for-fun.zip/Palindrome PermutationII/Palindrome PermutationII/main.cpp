//
//  main.cpp
//  Palindrome PermutationII
//
//  Created by yangjingyi on 2/1/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;
class Solution
{
public:
    vector<string> generatePalindromes(string s)
    {
        vector<string> result;
        unordered_map<char,int> charCount;
        int oddCnt=0,N=0;
        string mid;
        for(int i=0;i<s.size();i++)
        {
            charCount[s[i]]++;
            
        }
        for(auto &c:charCount)
        {
            if(c.second&1)
            {
                mid=c.first;
                oddCnt++;
            }
            c.second/=2;
            N+=c.second;
        }
        for(auto c:charCount)
        {
            cout<<c.first<<"="<<c.second<<endl;
        }
        if(oddCnt>1)
        {
            return result;
        }
        helper(charCount,"",mid, N,result);
        return result;
    }
private:
    void helper(unordered_map<char,int>& charCount, string s,string& mid,int& N, vector<string>& result)
    {
        if(s.size()==N)
        {
            string rev=s;
            reverse(rev.begin(),rev.end());
            result.push_back(s+mid+rev);
            return;
        }
        for(auto &c:charCount)
        {
            if(c.second>0)
            {
                c.second--;
                helper(charCount, s+c.first,mid, N,result);
                c.second++;
            }
        }
    }
};

int main(int argc, const char * argv[]) {
    string in="aabbc";
    Solution a;
    vector<string> out=a.generatePalindromes(in);
    for(int i=0;i<out.size();i++)
    {
        cout<<out[i]<<endl;
    }
    return 0;
}
