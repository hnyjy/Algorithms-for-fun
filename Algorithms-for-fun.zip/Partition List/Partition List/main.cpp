//
//  main.cpp
//  Partition List
//
//  Created by yangjingyi on 12/16/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL)
    {
        
    }
};
class Solution
{
public:
    ListNode* partition(ListNode* head, int x)
    {
        ListNode fh(0);
        ListNode* sp=new ListNode (0);
        ListNode* sh=sp;
        ListNode* bp=new ListNode(0);
        ListNode* bh=bp;
        while(head)
        {
            if(head->val>=x)
            {
                bp->next=head;
                bp=bp->next;
                head=head->next;
                cout<<bp->val<<endl;
            }
            else
            {
                sp->next=head;
                
                sp=sp->next;
                head=head->next;
                cout<<sp->val<<endl;
            }
            
        }
        if(sh->next==NULL)
        {
            fh.next=bh;
        }
        else
        {
            fh.next=sh->next;
            sp->next=bh->next;
            bp->next=NULL;
        }
        return fh.next;
    }
};

int main(int argc, const char * argv[]) {
    ListNode he(0);
    ListNode* in=(&he);
    
    /*for(int i=1;i<6;i++)
     {
     ListNode* newNode=new ListNode(i);
     in->next=newNode;
     in=in->next;
     }*/
    ListNode* tmp1=new ListNode(2);
    in->next=tmp1;
    in=in->next;
    ListNode* tmp2=new ListNode(1);
    in->next=tmp2;
    in=in->next;
    /*ListNode* tmp3=new ListNode(2);
    in->next=tmp3;
    in=in->next;
    ListNode* tmp4=new ListNode(2);
    in->next=tmp4;
    in=in->next;*/
    Solution a;
    ListNode* out=a.partition((&he)->next,2);
    while(out)
    {
        //cout<<"wrong";
        cout<<out->val;
        out=out->next;
    }

    return 0;
}
