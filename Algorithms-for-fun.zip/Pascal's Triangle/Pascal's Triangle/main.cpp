//
//  main.cpp
//  Pascal's Triangle
//
//  Created by yangjingyi on 12/20/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<vector<int> > generate(int numRows)
    {
        vector<vector<int> > result;
        if(numRows==0)
        {
            return result;
        }
        vector<int> v1;
        v1.push_back(1);
        result.push_back(v1);
        if(numRows==1)
        {
            
            
            return result;
        }
        v1.push_back(1);
        result.push_back(v1);
        if(numRows==2)
        {
            return result;
        }
        for(int i=2;i<numRows;i++)
        {
            vector<int> tmp;
            tmp.push_back(1);
            for(int j=1;j<i;j++)
            {
                tmp.push_back(result[i-1][j-1]+result[i-1][j]);
            }
            tmp.push_back(1);
            result.push_back(tmp);
        }
        return result;
            
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    
    int in=4;
    Solution a;
    vector<vector<int> > out;
    out=a.generate(in);
    for(int i=0;i<out.size();i++)
    {
        for(int j=0;j<out[i].size();j++)
        {
            cout<<out[i][j]<<",";
        }
        cout<<endl;
    }
    return 0;
}
