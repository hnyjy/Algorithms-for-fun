//
//  main.cpp
//  Pascal's TriangleII
//
//  Created by yangjingyi on 12/20/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<int> getRow(int numRows)
    {
        vector<int> vi(numRows+1);
        vi[0]=1;
        for(int i=0;i<=numRows;i++)
        {
            for(int j=i;j>0;j--)
            {
                vi[j]=vi[j]+vi[j-1];
            }
        }
        return vi;
        
    }
};


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
