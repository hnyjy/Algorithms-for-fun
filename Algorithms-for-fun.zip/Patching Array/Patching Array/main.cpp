//
//  main.cpp
//  Patching Array
//
//  Created by yangjingyi on 3/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int minPatches(vector<int>& nums, int n)
    {
        if(n==0)
        {
            return 0;
        }
        int num=nums.size();
        long reach=0;
        int patch=0;
        for(int i=0;i<num;)
        {
            while(nums[i]>reach+1)
            {
                reach+=reach+1;
                ++patch;
                if(reach>=n)
                {
                    return patch;
                }
            }
            reach+=nums[i];
            if(reach>=n)
            {
                return patch;
            }
            ++i;
        }
        while(reach<n)
        {
            reach+=reach+1;
            ++patch;
        }
        return patch;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
