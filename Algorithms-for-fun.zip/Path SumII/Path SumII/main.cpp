//
//  main.cpp
//  Path SumII
//
//  Created by yangjingyi on 12/19/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x): val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    void pathSum(TreeNode* root, int sum,vector<int>& temp, vector<vector<int> >& result)
    {
        if(!root)
        {
            return;
        }
        if(root&&!root->left&&!root->right)
        {
            temp.push_back(root->val);
            result.push_back(temp);
            temp.pop_back();
            return;
        }
        else
        {
            temp.push_back(root->val);
            pathSum(root->left,sum-root->val,temp,result);
            pathSum(root->right,sum-root->val,temp,result);
            temp.pop_back();
            return;
        }
    }
    vector<vector<int> >pathSum(TreeNode* root, int sum)
    {
        vector<vector<int> > result;
        vector<int> temp;
        pathSum(root, sum, temp, result);
        return result;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}

