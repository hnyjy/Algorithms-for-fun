//
//  main.cpp
//  Peeking Iterator
//
//  Created by yangjingyi on 2/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Iterator
{
    struct Data;
    Data* data;
public:
    Iterator(const vector<int>& nums);
    Iterator(const Iterator& iter);
    virtual ~Iterator();
    int next();
    bool hasNext() const;
};
class PeekingIterator:public Iterator
{
public:
    PeekingIterator(const vector<int>& nums):Iterator(nums)
    {
        
    }
    int peek()
    {
        return Iterator(*this).next();
    }
    int next()
    {
        return Iterator::next();
    }
    bool hasNext() const
    {
        return Iterator::hasNext();
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
