//
//  main.cpp
//  Perfect Squares
//
//  Created by yangjingyi on 2/5/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <climits>
using namespace std;
class Solution
{
public:
    int numSquares(int n)
    {
        if(n<=0)
        {
            return 0;
        }
        static vector<int> cntPerfectSquares({0});
        while(cntPerfectSquares.size()<=n)
        {
            int m=cntPerfectSquares.size();
            int cntSquares=INT_MAX;
            for(int i=1;i*i<=m;i++)
            {
                cntSquares=min(cntSquares, cntPerfectSquares[m-i*i]+1);
                
            }
            cntPerfectSquares.push_back(cntSquares);
        }
        return cntPerfectSquares[n];
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
