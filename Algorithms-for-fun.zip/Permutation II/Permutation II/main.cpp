//
//  main.cpp
//  Permutation II
//
//  Created by yangjingyi on 12/9/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include<algorithm>
#include<functional>
#include <vector>
using namespace std;
class Solution
{
public:
    void permutionUnique(vector<int>& num, vector<int> numt2,vector<vector<int> >& res)
    {
        int i;
        vector<int> era=num;
        vector<int>::iterator iter=unique(era.begin(),era.end());
        era.erase(iter,era.end());
        //sort(num.begin(),num.end());
        if(num.size()==1)
        {
            numt2.push_back(num[0]);
            res.push_back(numt2);
            numt2.pop_back();
            return;
        }
        else
        {
            int x=0;
            vector<int> numt1;
            
            for(i=0;i<era.size();i++)
            {
                /*while(num[i]==num[i+1]&&i<num.size())
                {
                    i++;
                }*/
                cout<<"i="<<i<<endl;
                numt2.push_back(num[0]);
                cout<<"numt2=";
                for(int tmp=0;tmp<numt2.size();tmp++)
                {
                    cout<<numt2[tmp]<<", ";
                }
                for(int j=1;j<num.size();j++)
                {
                    numt1.push_back(num[j]);
                }
                cout<<endl;
                permutionUnique(numt1,numt2,res);
                numt2.pop_back();
                vector<int>::iterator k=num.begin();
                int count=0;
                while(num[0]==num[1]&&count<num.size())
                {
                    x=num[0];
                    num.erase(k);
                    num.push_back(x);
                    //i++;
                    count++;
                }
                cout<<num.size()<<"next"<<endl;
                x=num[0];
                numt1.clear();
                num.erase(k);
                num.push_back(x);
            }
        }
    }
    vector<vector<int> > permuteUnique(vector<int>& nums)
    {
        sort(nums.begin(),nums.end());
        vector<vector<int> > res1;
        vector<int> t;
        permutionUnique(nums,t,res1);
        return res1;
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in={3,3,0,0,2,3,2};
    vector<vector<int> > out;
    Solution a;
    out=a.permuteUnique(in);
    //sort(out.begin(),out.end());
    for(int i=0;i<out.size();i++)
    {
        for(int j=0;j<out[i].size();j++)
        {
            cout<<out[i][j]<<", ";
        }
        cout<<endl;
    }
        
    
    return 0;
}
