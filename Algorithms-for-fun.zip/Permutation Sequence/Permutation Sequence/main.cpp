//
//  main.cpp
//  Permutation Sequence
//
//  Created by yangjingyi on 12/12/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    string getPermutation(int n, int k)
    {
        vector<int> setv;
        for(int i=0;i<n;i++)
        {
            setv.push_back(i+1);
        }
        string result="";
        int count=1;
        for(int i=1;i<n;i++)
        {
            count *=i;
        }
        int pos=0;
        int start=n-1;
        /*if(n==1&&k)
        {
            return "1";
        }
        if(!k)
        {
            return "";
        }*/
        while(k&&count&&start)
        {
            
            
            result=result+to_string(setv[(k-1)/count]);
            vector<int>::iterator it=setv.begin()+(int)((k-1)/count);
            setv.erase(it);
            //cout<<"right"<<endl;
            k=k-(k/count)*count;
            //cout<<"k="<<k<<endl;
            count=count/start;
            start--;
            //pos++;
        }
        for(int j=setv.size()-1;j>-1;j--)
        {
            result=result+to_string(setv[j]);
        }
        return result;
        
    }
};

int main(int argc, const char * argv[]) {
    int in1=2;
    int in2=2;
    Solution a;
    string out=a.getPermutation(in1,in2);
    cout<<out<<endl;
    return 0;
}
