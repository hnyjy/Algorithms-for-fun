//
//  main.cpp
//  Permutation
//
//  Created by yangjingyi on 3/9/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>

using namespace std;

void permution(vector<int> &num,vector<int> numt2,vector<vector<int> > &res)
{
    int i;
    //vector<vector<int> > res;
    //vector<int> numt2;
    if(num.size()==1)
    {
        numt2.push_back(num[0]);
        int con;
        /*for(con=0;con<numt2.size();con++)
         {
         cout<<numt2[con]<<" and ";
         }*/
        res.push_back(numt2);
        numt2.pop_back();
        cout<<"return"<<endl;
        //i=5;
        return;
    }
    else
    {
        int x=0;
        
        vector<int> numt1;
        
        for(i=0;i<num.size();i++)
        {
            cout<<"i‘="<<i<<endl;
            numt2.push_back(num[0]);
            for(int j=1;j<num.size();j++)
            {
                
                numt1.push_back(num[j]);
                //permute(numt1,numt2);
                
            }
            //cout<<numt1.size()<<endl;
            //cout<<numt1[0]<<"+"<<numt1[1]<<endl;
            permution(numt1,numt2,res);
            numt2.pop_back();
            x=num[0];
            //int h;
            numt1.clear();
            //cout<<"numt1' first="<<numt1[0]<<endl;
            //cout<<"numt1 size"<<numt1.size()<<endl;
            vector<int>::iterator k=num.begin();
            num.erase(k);
            num.push_back(x);
            /*for(int p=0;p<num.size();p++)
             {
             cout<<"the"<<p<<"="<<num[p]<<endl;
             }*/
            //cout<<"num size"<<num.size()<<endl;
            
            //cout<<"cout"<<endl;
            //cout<<"i="<<i<<endl;
        }
        
    }
    
};




class Solution {
public:
    vector<vector<int> > permute(vector<int> &num)
    {
        vector<vector<int> > res1;
        vector<int> t;
        permution(num,t,res1);
        return res1;
    }
};



int main()
{
    vector<vector<int> > res1;
    
    int dataa[7]={1,2,3,4,10,34,67};
    vector<int> datav(dataa,dataa+7);
    //vector<int>::iterator b=datav.begin();
    //int x=datav[0];
    //datav.erase(b);
    //datav.push_back(x);
    /*for(int i=0;i<datav.size();i++)
    {
        cout<<datav[i];
    }*/
    vector<int> t;
    //cout<<t.size();
    permute(datav,t,res1 );
    int q,p;
    for(q=0;q<res1.size();q++)
    {
        for(p=0;p<res1[q].size();p++)
        {
            cout<<res1[q][p]<<"  ";
        }
        cout<<endl;
    }
    cout<<res1.size()<<endl;
    //cout<<"wrong"<<endl;
}
