//
//  main.cpp
//  Permutations
//
//  Created by yangjingyi on 12/9/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
void permution(vector<int> &num,vector<int> numt2,vector<vector<int> > &res)
{
    int i;
    if(num.size()==1)
    {
        numt2.push_back(num[0]);
        int con;
        res.push_back(numt2);
        numt2.pop_back();
        return;
    }
    else
    {
        int x=0;
        vector<int> numt1;
        for(i=0;i<num.size();i++)
        {
            numt2.push_back(num[0]);
            for(int j=1;j<num.size();j++)
            {
                numt1.push_back(num[j]);
            }
            permution(numt1,numt2,res);
            numt2.pop_back();
            x=num[0];
            numt1.clear();
            vector<int>::iterator k=num.begin();
            num.erase(k);
            num.push_back(x);
        }
    }
};
class Solution {
public:
    vector<vector<int> > permute(vector<int> &num)
    {
        vector<vector<int> > res1;
        vector<int> t;
        permution(num,t,res1);
        return res1;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
