//
//  main.cpp
//  Populating Next Right Pointers in Each Node
//
//  Created by yangjingyi on 12/20/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
struct TreeLinkNode
{
    int val;
    TreeLinkNode *left, *right, *next;
    TreeLinkNode(int x): val(x), left(NULL), right(NULL), next(NULL){}
};
class Solution
{
public:
    void buildTree(vector<vector<TreeLinkNode* > >&result)
    {
        int m=result.size();
        vector<TreeLinkNode* >tmp;
        if(!result[m-1][0]->left)
        {
            return;
        }
        for(int i=0;i<result[m-1].size();i++)
        {
            tmp.push_back(result[m-1][i]->left);
            tmp.push_back(result[m-1][i]->right);
        }
        result.push_back(tmp);
        buildTree(result);
        
    }
    void connext(TreeLinkNode * root)
    {
        if(!root)
        {
            return;
        }
        vector<vector<TreeLinkNode* > > result;
        vector<TreeLinkNode*> tmp;
        tmp.push_back(root);
        result.push_back(tmp);
        buildTree(result);
        for(int i=0;i<result.size();i++)
        {
            for(int j=0;j<result[i].size()-1;j++)
            {
                result[i][j]->next=result[i][j+1];
              
            }
        }
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
