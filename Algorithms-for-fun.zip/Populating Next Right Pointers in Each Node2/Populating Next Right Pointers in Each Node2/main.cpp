//
//  main.cpp
//  Populating Next Right Pointers in Each Node2
//
//  Created by yangjingyi on 12/20/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct TreeLinkNode
{
    int val;
    TreeLinkNode *left, *right, *next;
    TreeLinkNode(int x): val(x), left(NULL), right(NULL), next(NULL){}
};
class Solution
{
public:
    void connect (TreeLinkNode* root)
    {
        if(root==NULL)
        {
            return;
        }
        TreeLinkNode *pre=root;
        TreeLinkNode *cur=NULL;
        while(pre->left)
        {
            cur=pre;
            while(cur)
            {
                cur->left->next=cur->right;
                if(cur->next)
                {
                    cur->right->next=cur->next->left;
                }
                cur=cur->next;
            }
            pre=pre->left;
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
