//
//  main.cpp
//  Pow(x,n)
//
//  Created by yangjingyi on 12/10/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    double myPow(double x, int n)
    {
        double ans=1;
        unsigned long long p;
        if(n<0)
        {
            p=-n;
            x=1/x;
        }
        else
        {
            p=n;
        }
        while(p)
        {
            if(p&1)
            {
                ans *=x;
            }
            x *=x;
            p>>=1;
        }
        return ans;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
