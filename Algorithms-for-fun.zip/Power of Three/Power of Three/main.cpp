//
//  main.cpp
//  Power of Three
//
//  Created by yangjingyi on 2/27/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;
class Solution
{
public:
    bool isPowerOfThree(int n)
    {
        return fmod(log10(n)/log10(3),1)==0;
    }
};


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
