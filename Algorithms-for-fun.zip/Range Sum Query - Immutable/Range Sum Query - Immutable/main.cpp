//
//  main.cpp
//  Range Sum Query - Immutable
//
//  Created by yangjingyi on 2/16/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class NumArray
{
public:
    vector<int> sum;
    NumArray(vector<int>& nums)
    {
        sum.push_back(0);
        for(int num:nums)
        {
            sum.push_back(sum.back()+num);
        }
    }
    int sumRange(int i, int j)
    {
        return sum[j+1]-sum[i];
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
