//
//  main.cpp
//  Range Sum Query 2D - Immutable
//
//  Created by yangjingyi on 2/16/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class NumMatrix
{
public:
    vector<vector<int> > sum;
    NumMatrix(vector<vector<int> >& matrix)
    {
        int n=matrix.size(),m=matrix[0].size();
        vector<int> tmp1(m+1,0);
        sum.push_back(tmp1);
        vector<int> tmp2(1,0);
        for(int i=0;i<n;i++)
        {
            sum.push_back(tmp2);
            //sum[i+1].push_back(0);
            for(int j=0;j<m;j++)
            {
                sum[i+1].push_back(sum[i+1].back()+matrix[i][j]);
            }
        }
        /*for(int i=0;i<sum.size();i++)
        {
            for(int j=0;j<sum[i].size();j++)
            {
                cout<<sum[i][j]<<" , ";
            }
            cout<<endl;
        }*/
        
        
    }
    int sumRegion(int row1, int col1, int row2,int col2)
    {
        int result=0;
        for(int i=row1;i<=row2;i++)
        {
            result=sum[i+1][col2+1]-sum[i+1][col1]+result;
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    vector<vector<int> > in={{3,0,1,4,2},{5,6,3,2,1},{1,2,0,1,5},{4,1,0,1,7},{1,0,3,0,5}};
    NumMatrix nummatrix(in);
    cout<<nummatrix.sumRegion(2,1,4,3)<<endl;
    cout<<nummatrix.sumRegion(1, 1, 2, 2)<<endl;
    cout<<nummatrix.sumRegion(1, 2, 2, 4)<<endl;
    
    return 0;
}
