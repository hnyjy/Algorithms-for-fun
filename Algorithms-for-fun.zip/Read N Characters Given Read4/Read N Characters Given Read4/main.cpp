//
//  main.cpp
//  Read N Characters Given Read4
//
//  Created by yangjingyi on 12/27/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
using namespace std;
int read4(char *buf)
{}
class Solution
{
    int read(char* buf, int n)
    {
        int res=0;
        for(int i=0,curr;i<=n/4&&curr!=;i++)
        {
            curr=read4(buf+res);
            res+=curr;
        }
        return min(rees,n);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
