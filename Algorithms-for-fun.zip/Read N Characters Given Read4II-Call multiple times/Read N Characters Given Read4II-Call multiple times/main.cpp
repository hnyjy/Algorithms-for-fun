//
//  main.cpp
//  Read N Characters Given Read4II-Call multiple times
//
//  Created by yangjingyi on 12/27/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
int read4(char *buf);
class Solution
{
public:
    int remain=0;
    char buffer[4];
    int idx=0;
    int read(char *buf, int n)
    {
        int count=0;
        char *org_buf=buf;
        int i,j;
        for(i=idx,j=0;j<remain&&count<n;i++,j++)
        {
            if(i==4)
            {
                i=0;
            }
            buf[j]=buffer[i];
            count++;
        }
        idx=i;
        remain -=count;
        buf +=count;
        if(count==n)
        {
            return n;
        }
        while(count<n)
        {
            int r=read4(buf);
            count +=r;
            buf+=r;
            if(r<4)
            {
                break;
            }
        }
        int len=min(count,n);
        remain=max(count-len,0);
        if(remain)
        {
            memcpy(buffer,org_buf+len,remain);
            idx=0;
        }
        return len;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
