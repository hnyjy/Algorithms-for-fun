//
//  main.cpp
//  Reconstruct Itinerary
//
//  Created by yangjingyi on 3/6/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <set>
#include <unordered_map>
using namespace std;
class Solution
{
public:
    vector<string> findItinerary(vector<pair<string,string> > tickets)
    {
        vector<string> res;
        if(tickets.size()==0)
        {
            return res;
        }
        unordered_map<string,multiset<string>> pairs;
        unordered_map<string,int> count1, count2;
        for(auto ticket:tickets)
        {
            pairs[ticket.first].insert(ticket.second);
            count1[ticket.first]++;
            count2[ticket.second]++;
        }
        res.push_back("JFK");
        set<vector<string> > ress;
        help(ress,res,tickets.size(),pairs,count1,count2);
        return *ress.begin();
    
    }
    void help(set<vector<string> >&ress, vector<string>& res, int n,unordered_map<string,multiset<string> >pairs,unordered_map<string,int> count1, unordered_map<string, int> count2)
    {
        if(res.size()==n+1)
        {
            ress.insert(res);
            //cout<<"right"<<endl;
            return;
        }
        else if(count1[res.back()]<=0&&res.size()<n+1)
        {
            return;
        }
        else
        {
            //cout<<res.back()<<endl;
            string tmp=res.back();
            
            count1[tmp]--;
            
            for(auto it=pairs[tmp].begin();it!=pairs[tmp].end();it++)
            {
                ;
                if(count2[*it]<=0)
                {
                    //cout<<"right"<<endl;
                    continue;
                }
                else
                {
                    
                    count2[*it]--;
                    
                    res.push_back(*it);
                    help(ress,res,n,pairs,count1,count2);
                    if(ress.size()>0)
                    {
                        return;
                    }
                    res.pop_back();
                    count2[*it]++;
                }
            }
            return;
        }
    }
};

int main(int argc, const char * argv[]) {
    vector<pair<string,string> >in={{"AXA","EZE"},{"EZE","AUA"},{"ADL","JFK"},{"ADL","TIA"},{"AUA","AXA"},{"EZE","TIA"},{"EZE","TIA"},{"AXA","EZE"},{"EZE","ADL"},{"ANU","EZE"},{"TIA","EZE"},{"JFK","ADL"},{"AUA","JFK"},{"JFK","EZE"},{"EZE","ANU"},{"ADL","AUA"},{"ANU","AXA"},{"AXA","ADL"},{"AUA","JFK"},{"EZE","ADL"},{"ANU","TIA"},{"AUA","JFK"},{"TIA","JFK"},{"EZE","AUA"},{"AXA","EZE"},{"AUA","ANU"},{"ADL","AXA"},{"EZE","ADL"},{"AUA","ANU"},{"AXA","EZE"},{"TIA","AUA"},{"AXA","EZE"},{"AUA","SYD"},{"ADL","JFK"},{"EZE","AUA"},{"ADL","ANU"},{"AUA","TIA"},{"ADL","EZE"},{"TIA","JFK"},{"AXA","ANU"},{"JFK","AXA"},{"JFK","ADL"},{"ADL","EZE"},{"AXA","TIA"},{"JFK","AUA"},{"ADL","EZE"},{"JFK","ADL"},{"ADL","AXA"},{"TIA","AUA"},{"AXA","JFK"},{"ADL","AUA"},{"TIA","JFK"},{"JFK","ADL"},{"JFK","ADL"},{"ANU","AXA"},{"TIA","AXA"},{"EZE","JFK"},{"EZE","AXA"},{"ADL","TIA"},{"JFK","AUA"},{"TIA","EZE"},{"EZE","ADL"},{"JFK","ANU"},{"TIA","AUA"},{"EZE","ADL"},{"ADL","JFK"},{"ANU","AXA"},{"AUA","AXA"},{"ANU","EZE"},{"ADL","AXA"},{"ANU","AXA"},{"TIA","ADL"},{"JFK","ADL"},{"JFK","TIA"},{"AUA","ADL"},{"AUA","TIA"},{"TIA","JFK"},{"EZE","JFK"},{"AUA","ADL"},{"ADL","AUA"},{"EZE","ANU"},{"ADL","ANU"},{"AUA","AXA"},{"AXA","TIA"},{"AXA","TIA"},{"ADL","AXA"},{"EZE","AXA"},{"AXA","JFK"},{"JFK","AUA"},{"ANU","ADL"},{"AXA","TIA"},{"ANU","AUA"},{"JFK","EZE"},{"AXA","ADL"},{"TIA","EZE"},{"JFK","AXA"},{"AXA","ADL"},{"EZE","AUA"},{"AXA","ANU"},{"ADL","EZE"},{"AUA","EZE"}};
    Solution a;
    vector<string> out;
    out=a.findItinerary(in);
    for(auto it:out)
    {
        cout<<it<<" ,";
    }
    return 0;
}
