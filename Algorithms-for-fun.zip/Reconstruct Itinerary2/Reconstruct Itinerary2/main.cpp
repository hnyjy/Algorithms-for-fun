//
//  main.cpp
//  Reconstruct Itinerary2
//
//  Created by yangjingyi on 3/6/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <map>
#include <set>
using namespace std;
class Solution
{
public:
    vector<string> findItinerary(vector<pair<string, string>> tickets) {
        for (auto ticket : tickets)
            targets[ticket.first].insert(ticket.second);
        visit("JFK");
        return vector<string>(route.rbegin(), route.rend());
    }
    
    map<string, multiset<string>> targets;
    vector<string> route;
    
    void visit(string airport) {
        while (targets[airport].size()) {
            string next = *targets[airport].begin();
            cout<<next<<endl;
            targets[airport].erase(targets[airport].begin());
            visit(next);
        }
        route.push_back(airport);
    }
};

int main(int argc, const char * argv[]) {
    vector<pair<string, string> > in={{"JFK","NYK"},{"NYK","JFK"},{"JFK","AOP"}};
    Solution a;
    vector<string> out=a.findItinerary(in);
    for(auto outs:out)
    {
        cout<<outs<<" ,";
    }
    return 0;
}
