//
//  main.cpp
//  Reconstruct Itinerary3
//
//  Created by yangjingyi on 3/12/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <set>
#include <stack>
#include <unordered_map>
using namespace std;
class Solution
{
public:
    vector<string> finItinerary(vector<pair<string, string> > tickets)
    {
        unordered_map<string, multiset<string> >graph;
        vector<string> itinerary;
        if(tickets.size()==0)
        {
            return itinerary;
        }
        for(pair<string,string> ticket:tickets)
        {
            graph[ticket.first].insert(ticket.second);
        }
        stack<string> dfs;
        dfs.push("JFK");
        while(!dfs.empty())
        {
            string topAirport=dfs.top();
            if(graph[topAirport].empty())
            {
                itinerary.push_back(topAirport);
                dfs.pop();
            }
            else
            {
                dfs.push(*(graph[topAirport].begin()));
                graph[topAirport].erase(graph[topAirport].begin());
            }
            
        }
        reverse(itinerary.begin(),itinerary.end());
        return itinerary;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
