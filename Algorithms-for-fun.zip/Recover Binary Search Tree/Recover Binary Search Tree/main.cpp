//
//  main.cpp
//  Recover Binary Search Tree
//
//  Created by yangjingyi on 12/18/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <stack>
#include <climits>
#include <queue>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode * left;
    TreeNode * right;
    TreeNode(int x): val(x), left(NULL),right(NULL)
    {}
};
class Solution
{
    TreeNode* firstElement=NULL;
    TreeNode* secondElement=NULL;
    TreeNode* prevElement=new TreeNode(INT_MIN);
public:
    void recoverTree(TreeNode* root)
    {
        traverse(root);
        int temp=firstElement->val;
        firstElement->val=secondElement->val;
        queue<TreeNode*> q;
        
        
        secondElement->val=temp;
    }
private:
    void traverse(TreeNode* root)
    {
        if(root==NULL)
        {
            return;
        }
        traverse(root->left);
        if(firstElement==NULL&&prevElement->val>=root->val)
        {
            firstElement=prevElement;
        }
        if(firstElement!=NULL&&prevElement->val>=root->val)
        {
            secondElement=root;
        }
        prevElement=root;
        traverse(root->right);
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
