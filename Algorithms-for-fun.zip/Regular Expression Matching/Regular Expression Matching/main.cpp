//
//  main.cpp
//  Regular Expression Matching
//
//  Created by yangjingyi on 4/22/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    bool isMatch(string s, string p)
    {
        if(p.empty()) return s.empty();
        if(p[1]!='*')
        {
            if(s[0]==p[0]||(p[0]=='.'&&s[0]!='\0')) return isMatch(s.substr(1),p.substr(1));
            else return false;
            
        }
        else
        {
            if(isMatch(s,p.substr(2))) return true;
            int index=0;
            while(index <s.size() && (s[index]==p[0]||p[0]=='.'))
            {
                if(isMatch(s.substr(++index),p.substr(2))) return true;
                
            }
            return false;
        
        }
    }
};


int main()
{
    string ins="ab";
    string inp=".*";
    Solution a;
    if(a.isMatch(ins,inp)==true)
    {
        cout<<"true"<<endl;
    }
    else
    {
        cout<<"false"<<endl;
    }
    
}
