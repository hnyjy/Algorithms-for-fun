//
//  main.cpp
//  Remove Duplicate Letters
//
//  Created by yangjingyi on 2/23/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <set>
#include <vector>
using namespace std;
class Solution
{
public:
    string removeDuplicateLetters(string s)
    {
        vector<int> cand(256,0);
        vector<bool> visited(256,false);
        for(char c:s)
        {
            cand[c]++;
        }
        string result="0";
        for(char c:s)
        {
            cand[c]--;
            if(visited[c])
            {
                continue;
            }
            while(c<result.back()&&cand[result.back()])
            {
                visited[result.back()]=false;
                result.pop_back();
            }
            result+=c;
            visited[c]=true;
        }
        return result.substr(1);
       
    }
};

int main(int argc, const char * argv[]) {
    string in="bbcaac";
    Solution a;
    string out=a.removeDuplicateLetters(in);
    cout<<out<<endl;
    return 0;
}
