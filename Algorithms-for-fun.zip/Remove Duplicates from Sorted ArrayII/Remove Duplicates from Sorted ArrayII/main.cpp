//
//  main.cpp
//  Remove Duplicates from Sorted ArrayII
//
//  Created by yangjingyi on 12/15/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int removeDuplicates(vector<int>& nums)
    {
        int i=0;
        for(int n:nums)
        {
            if(i<2||n>nums[i-2])
            {
                nums[i++]=n;
            }
        }
        return i;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
