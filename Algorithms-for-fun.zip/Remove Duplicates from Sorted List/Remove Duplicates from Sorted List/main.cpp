//
//  main.cpp
//  Remove Duplicates from Sorted List
//
//  Created by yangjingyi on 12/15/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x): val(x),next(NULL)
    {}
};
class Solution
{
public:
    ListNode* deleteDuplicates(ListNode* head)
    {
        ListNode fh(0);
        //ListNode* curr;
        ListNode* cop=&fh;
        if(!head)
        {
            return head;
        }
        if(head->next==NULL||head==NULL)
        {
            return head;
        }
        //curr=head;
        
        ListNode* pre=head;
        //cop->next=pre;
        //cop=cop->next;
        /*while(cop)
        {
            cout<<cop->val;
            cop=cop->next;
        }*/
        //cout<<endl;
        ListNode* next;
        while(pre->next)
        {
            cop->next=pre;
            cout<<pre->val<<endl;
            cop=cop->next;
            next=pre->next;
            cout<<"right"<<endl;
            while(pre->val==next->val)
            {
                //cout<<"right"<<endl;
                if(!next->next)
                {
                    //cout<<"right"<<endl;
                    //cop=cop->next;
                    cop->next=NULL;
                    return fh.next;
                }
                next=next->next;
            }
            if(!next->next)
            {
                cop->next=next;
                return fh.next;
            }
            //cout<<next->val<<endl;
            pre=next;
            //next=next->next;
            //cop=cop->next;
            
        }
        return fh.next;

    }
};

int main(int argc, const char * argv[]) {
    ListNode he(0);
    ListNode* in=(&he);
    
    /*for(int i=1;i<6;i++)
     {
     ListNode* newNode=new ListNode(i);
     in->next=newNode;
     in=in->next;
     }*/
    ListNode* tmp1=new ListNode(1);
    in->next=tmp1;
    in=in->next;
    ListNode* tmp2=new ListNode(1);
    in->next=tmp2;
    in=in->next;
    ListNode* tmp3=new ListNode(2);
    in->next=tmp3;
    in=in->next;
    ListNode* tmp4=new ListNode(2);
    in->next=tmp4;
    in=in->next;
    Solution a;
    ListNode* out=a.deleteDuplicates((&he)->next);
    while(out)
    {
        //cout<<"wrong";
        cout<<out->val;
        out=out->next;
    }
    

    return 0;
}
