//
//  main.cpp
//  Remove Duplicates from Sorted ListII
//
//  Created by yangjingyi on 12/15/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
    
};
class Solution
{
public:
    ListNode* deleteDuplicates(ListNode* head)
    {
        ListNode fh(0);
        //ListNode* curr;
        ListNode* cop=&fh;
        if(!head)
        {
            return head;
        }
        if(head->next==NULL||head==NULL)
        {
            return head;
        }
        //curr=head;
        
        ListNode* pre=head;
        ListNode* next=head->next;
        while(pre->next)
        {
            //cout<<"right"<<endl;
            while(pre->val==next->val)
            {
                cout<<"wrong"<<endl;
                if(next->next==NULL)
                {
                    cop->next=NULL;
                    return fh.next;
                }
                next=next->next;
            }
            if(pre->next!=next)
            {
                if(next->next)
                {
                    pre=next;
                    next=next->next;
                }
                else
                {
                    cop->next=next;
                    break;
                }
            }
            else
            {
                cop->next=pre;
                cop=cop->next;
                pre=pre->next;
                next=next->next;
                cout<<"right"<<endl;
            }
            
        }
        return fh.next;
        
    }
};

int main(int argc, const char * argv[]) {
    ListNode he(0);
    ListNode* in=(&he);
    
    /*for(int i=1;i<6;i++)
    {
        ListNode* newNode=new ListNode(i);
        in->next=newNode;
        in=in->next;
    }*/
    ListNode* tmp1=new ListNode(1);
    in->next=tmp1;
    in=in->next;
    ListNode* tmp2=new ListNode(1);
    in->next=tmp2;
    in=in->next;
    //ListNode* tmp3=new ListNode(7);
    //in->next=tmp3;
    //in=in->next;
    
    Solution a;
    ListNode* out=a.deleteDuplicates((&he)->next);
    while(out)
    {
        cout<<out->val;
        out=out->next;
    }

    return 0;
}
