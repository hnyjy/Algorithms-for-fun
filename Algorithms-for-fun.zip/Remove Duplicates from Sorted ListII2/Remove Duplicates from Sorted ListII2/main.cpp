//
//  main.cpp
//  Remove Duplicates from Sorted ListII2
//
//  Created by yangjingyi on 12/15/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode* next;
    ListNode(int x):val(x),next(NULL){}
    
};
ListNode *deleteDuplicates(ListNode * head)
{
    if(!head||!head->next)
    {
        return head;
    }
    ListNode *newhead=0, **phead=&newhead;
    while(head)
    {
        if(head->next&&head->val==head->next->val)
        {
            int dupval=head->val;
            while(head&&head->val==dupval)
            {
                head=head->next;
            }
            continue;
        }
        else
        {
            *phead=head;
            phead=&((*phead)->next);
            
        }
        head=head->next;
    }
    *phead=0;
    return newhead;
}
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
