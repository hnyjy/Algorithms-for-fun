//
//  main.cpp
//  Remove Duplicates
//
//  Created by yangjingyi on 10/8/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int removeDuplicates(vector<int>& nums)
    {
        int count=0;
        for(int i=0;i<nums.size();i++)
        {
            if(i==0||nums[i]!=nums[count-1])
            {
                nums[count++]=nums[i];
            }
        }
        return count;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
