//
//  main.cpp
//  Remove Linked List Elements
//
//  Created by yangjingyi on 1/1/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode(int x):val(x),next(NULL){}
};
class Solution
{
public:
    ListNode * removeElements(ListNode* head, int val)
    {
        if(!head)
        {
            return head;
        }
        ListNode fh(0);
        ListNode* pre=&fh;
        pre->next=head;
        ListNode* curr=head;
        while(curr)
        {
            if(curr->val==val)
            {
                ListNode * tmp=curr->next;
                pre->next=tmp;
                delete curr;
                curr=tmp;
                if(!curr)
                {
                    break;
                }
            }
            else
            {
                curr=curr->next;
                pre=pre->next;
            }
        }
        return fh.next;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
