//
//  main.cpp
//  Remove Nth Node From End of List
//
//  Created by yangjingyi on 8/28/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode(int x):val(x),next(NULL)
    {
        
    }
};
class Solution
{
public:
    ListNode* removeNthFromEnd(ListNode* head, int n)
    {
        ListNode* fast=head;
        for(int i=0; i<n;i++)
        {
            fast=fast->next;
        }
        ListNode fakeHead(INT_MIN);
        fakeHead.next=head;
        ListNode* cur=head;
        ListNode* prev=&fakeHead;
        while(fast)
        {
            prev=cur;
            cur=cur->next;
            fast=fast->next;
        }
        prev->next = cur->next;
        delete cur;
        return fakeHead.next;
        
    }
};

int main()
{
    
}
