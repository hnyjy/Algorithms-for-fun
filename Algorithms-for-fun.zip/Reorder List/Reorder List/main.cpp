//
//  main.cpp
//  Reorder List
//
//  Created by yangjingyi on 12/24/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode(int x):val(x),next(NULL)
    {}
};
class Solution
{
public:
    void reorderList(ListNode* head)
    {
        ListNode* cur=head;
        ListNode* end=head->next;
        if(!head||!head->next)
        {
            return;
        }
        while(end&&end->next)
        {
            cur=cur->next;
            end=end->next->next;
        }
        ListNode *head2=cur->next;
        cur->next=NULL;
        end=head2->next;
        head2->next=NULL;
        while(end)
        {
            cur=end->next;
            end->next=head2;
            head2=end;
            end=cur;
        }
        for(cur=head,end=head2;cur;)
        {
            auto t=cur->next;
            cur->next=end;
            cur=cur->next;
            end=t;
        }
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
