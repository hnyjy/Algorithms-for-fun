//
//  main.cpp
//  Repeated DNA Sequences
//
//  Created by yangjingyi on 12/30/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

class Solution
{
public:
    vector<string> findRepeatedDnaSequences(string s)
    {
        unordered_map<string,int> mp;
        hash<string> hash_fn;
        vector<string> ret;
        for(int i=0;i<int(s.size())-9;++i)
        {
            if(mp[s.substr(i,10)]++==1)
            {
                ret.push_back(s.substr(i,10));
            }
        }
        return ret;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
