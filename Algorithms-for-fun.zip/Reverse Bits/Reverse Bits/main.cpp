//
//  main.cpp
//  Reverse Bits
//
//  Created by yangjingyi on 1/1/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
class Solution
{
public:
    uint32_t reverseBits(uint32_t n)
    {
        n=((n&0xAAAAAAAA)>>1)|((n&0x55555555)<<1);
        n=((n&0xcccccccc)>>2)|((n&0x33333333)<<2);
        n=((n&0xF0F0F0F0)>>4)|((n&0x0F0F0F0F)<<4);
        n=((n&0xFF00FF00)>>8)|((n&0x00FF00FF)<<8);
        n=((n&0xFFFF0000)>>16)|((n&0x0000FFFF)<<16);
        return n;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
