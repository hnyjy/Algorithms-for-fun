//
//  main.cpp
//  Reverse Integer
//
//  Created by yangjingyi on 3/14/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <climits>
using namespace std;
class Solution
{
public:
    int reverse(int x)
    {
        long long res=0;
        while(x)
        {
            res=res*10+x%10;
            x/=10;
        }
        return (res<INT_MIN||res>INT_MAX)?0:res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
