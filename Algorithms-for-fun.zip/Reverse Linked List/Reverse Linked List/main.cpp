//
//  main.cpp
//  Reverse Linked List
//
//  Created by yangjingyi on 1/2/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode(int x):val(x), next(NULL){}
};
class Solution
{
public:
    ListNode* reverseList(ListNode* head)
    {
        ListNode fh(0);
        if(!head||!head->next)
        {
            return head;
        }
        int count=0;
        ListNode* pre=head;
        while(pre)
        {
            pre=pre->next;
            count++;
        }
        ListNode* curr=&fh;
        curr->next=head;
        curr=curr->next;
        pre=head->next;
        for(int i=0;i<count-1;i++)
        {
            ListNode* tmp=pre->next;
            ListNode* tmp2=fh.next;
            fh.next=pre;
            pre->next=tmp2;
            curr->next=tmp;
            pre=tmp;
            
        }
        return fh.next;
        
    }
};

int main(int argc, const char * argv[]) {
    ListNode fh(0);
    ListNode* in=new ListNode(1);
    fh.next=in;
    for(int i=2;i<8;i++)
    {
        in->next=new ListNode(i);
        in=in->next;
    }
    in=fh.next;
    while(in)
    {
        cout<<in->val<<" ";
        in=in->next;
    }
    cout<<endl;
    Solution a;
    ListNode* out=a.reverseList(fh.next);
    while(out)
    {
        cout<<out->val<<" ";
        out=out->next;
    }
    
    return 0;
}
