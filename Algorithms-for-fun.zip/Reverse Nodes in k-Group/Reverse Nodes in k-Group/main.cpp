//
//  main.cpp
//  Reverse Nodes in k-Group
//
//  Created by yangjingyi on 9/17/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode(int x):val(x), next(NULL)
    {
        
    }
};
class Solution
{
public:
    inline ListNode *reverse(ListNode *head, int size)
    {
        if(size==1)
            return head;
        ListNode *b, *a, *pre;
        b=head;
        a=head->next;
        while(--size)
        {
            b->next=a->next;
            pre=a;
            pre->next=head;
            a=b->next;
            head=pre;
        }
        return head;
        
    }
    ListNode* reverseKGroup(ListNode* head, int k)
    {
        if(head==NULL||head->next==NULL)
            return head;
        ListNode* h;
        h=head;
        int size=0;
        while(h)
        {
            size++;
            h=h->next;
        }
        if(k>size)
            return head;
        h=head;
        int i=0;
        if(i+k<=size)
            head=reverse(h,k);
        h=head;
        i+=k;
        while(i+k<=size)
        {
            int temp=k;
            while(--temp)
                h=h->next;
            ListNode *back=h->next;
            h->next=back;
            h->next=back;
            h=h->next;
            i+=k;
        }
        return head;
    }
};

int main()
{
    ListNode n1(1);
    ListNode n2(2);
    n1.next=&n2;
    int in=2;
    ListNode* re=NULL;
    Solution a;
    re=a.reverseKGroup(&n1,in);
    while(re)
    {
        cout<<re->val<<endl;
        re=re->next;
    }
    
    
}
