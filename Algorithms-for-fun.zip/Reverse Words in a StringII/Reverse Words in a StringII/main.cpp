//
//  main.cpp
//  Reverse Words in a StringII
//
//  Created by yangjingyi on 12/30/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
    void reverseWords(string &s)
    {
        reverse(s.begin(),s.end());
        for(int i=0,j=0;i<s.size();i=j+1)
        {
            for(j=i;j<s.size()&&isblank(s[j]);++j);
            reverse(s.begin()+i,s.begin()+j);
            
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
