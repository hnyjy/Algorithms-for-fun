//
//  main.cpp
//  Rotate Image
//
//  Created by yangjingyi on 12/9/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    void rotate(vector<vector<int> >& matrix)
    {
        if(matrix.size()==0||matrix[0].size()==0)
            return;
        for(int i=0;i<matrix.size()/2;i++)
        {
            for(int j=0;i<(matrix[i].size()+1);j++)
            {
                int tmp=matrix[i][j];
                matrix[i][j]=matrix[matrix[i].size()-j-1][i];
                matrix[matrix[i].size()-j-1][i]=matrix[matrix[i].size()-i-1][matrix[i].size()-j-1];
                matrix[matrix[i].size()-i-1][matrix[i].size()-j-1]=matrix[j][matrix[i].size()-i-1];
                matrix[j][matrix[i].size()-i-1]=tmp;
            }
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
