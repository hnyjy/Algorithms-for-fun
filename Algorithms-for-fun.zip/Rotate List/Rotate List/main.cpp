//
//  main.cpp
//  Rotate List
//
//  Created by yangjingyi on 12/12/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode(int x):val(x),next(NULL){}
};
class Solution
{
public:
    ListNode* rotateRight(ListNode* head,int k)
    {
        if(head==NULL)
        {
            return NULL;
        }
        ListNode oh(0);
        
        ListNode* curr=&oh;
        curr->next=head;
        curr=curr->next;
        ListNode* front=head;
        ListNode* pre(0);
        for(int i=0;i<k-1;i++)
        {
            
            front=front->next;
            cout<<"i="<<i<<endl;
        }
        while(front->next)
        {
            pre=curr;
            curr=curr->next;
            front=front->next;
        }
        front->next=(&oh)->next;
        pre->next=NULL;
        return curr;
    }
};

int main(int argc, const char * argv[]) {
    
    ListNode he(0);
    ListNode* in=(&he);
    
    for(int i=1;i<6;i++)
    {
        ListNode* newNode=new ListNode(i);
        in->next=newNode;
        in=in->next;
    }
    ListNode* put=(&he);
    while(put)
    {
        cout<<put->val;
        put=put->next;
    }
    
    Solution a;
    ListNode* out=a.rotateRight((&he)->next,2);
    while(out)
    {
        cout<<out->val;
        out=out->next;
    }
    
    return 0;
}
