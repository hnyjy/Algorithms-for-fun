//
//  main.cpp
//  Search Insert Position
//
//  Created by yangjingyi on 12/7/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int searchInsert(vector<int>& nums, int target)
    {
        int low=0, high=nums.size()-1,mid;
        while(low<=high)
        {
            mid =(high+low)/2;
            if(nums[mid]<target)
                low=mid+1;
            else
                high=mid-1;
        }
        return low;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
