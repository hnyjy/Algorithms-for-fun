//
//  main.cpp
//  Search a 2D Matrix
//
//  Created by yangjingyi on 12/13/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    bool searchMatrix(vector<vector<int> >& matrix, int target)
    {
        int n=matrix.size();
        int m=matrix[0].size();
        int l=0,r=m*n-1;
        while(l!=r)
        {
            int mid=l+(r-l)/2;
            if(matrix[mid/m][mid%m]<target)
            {
                l=mid+1;
            }
            else
            {
                r=mid;
            }
        }
        return matrix[r/m][r%m]==target;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
