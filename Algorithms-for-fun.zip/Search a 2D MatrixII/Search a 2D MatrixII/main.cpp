//
//  main.cpp
//  Search a 2D MatrixII
//
//  Created by yangjingyi on 1/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <queue>
using namespace std;
class Solution
{
public:
     bool searchMatrix(vector<vector<int> >& matrix, int target)
    {
        if(matrix.size()==0)
        {
            return false;
        }
        int n=matrix.size();
        int m=matrix[0].size();
        if(target>matrix[n-1][m-1]||target<matrix[0][0])
        {
            return false;
        }
        queue<pair<int,int> > que1;
        
        que1.push(make_pair(0,0));
        while(!que1.empty())
        {
            if(target==matrix[que1.front().first][que1.front().second])
            {
                return true;
            }
            if(target!=matrix[que1.front().first][que1.front().second])
            {
                if(target>matrix[que1.front().first][que1.front().second])
                {
                    if(que1.front().first+1<=n-1)
                    {
                        que1.push(make_pair(que1.front().first+1,que1.front().second));
                    }
                    if(que1.front().second+1<=m-1)
                    {
                        que1.push(make_pair(que1.front().first,que1.front().second+1));
                    }
                    
                }
                que1.pop();
            }
        }
        return false;
        
    }
};

int main(int argc, const char * argv[]) {
    vector<vector<int> >in1={{0,5,9,13,18},{1,8,10,14,19},{1,8,14,18,20},{2,12,15,19,22},{7,15,19,22,25}
        };
    int in2=17;
    Solution a;
    bool out=a.searchMatrix(in1, in2);
    if(out)
    {
        cout<<"true"<<endl;
    }
    else
    {
        cout<<"false"<<endl;
    }
    return 0;
}
