//
//  main.cpp
//  Search in Rotated Sorted Array
//
//  Created by yangjingyi on 12/7/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int search(vector<int>& nums, int target)
    {
        if(nums.size()==0)
        {
            return -1;
            
        }
        int left=0;
        int right=nums.size()-1;
        while(left<=right)
        {
            int mid=(left+right)/2;
            if(target ==nums[mid])
                return mid;
            if((nums[mid]>=nums[left]&&(target>nums[mid]||(target<nums[left])))||(nums[mid]<nums[left]&&target>nums[mid]&&target<=nums[right]))
               left=mid+1;
            else
               right=mid-1;
        }
        return -1;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
