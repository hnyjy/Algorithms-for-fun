//
//  main.cpp
//  Serialize and Deserialize Binary Tree
//
//  Created by yangjingyi on 2/12/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
#include <vector>
#include <sstream>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Codec
{
    vector<TreeNode* > tn;
public:
    string serialize(TreeNode* root)
    {
        string s;
        if(!root)
        {
            s="*";
            return s;
        }
        tn.push_back(root);
        s=to_string(root->val)+" ";
        while(tn.size())
        {
            int n=tn.size();
            for(int i=0;i<n;i++)
            {
                if(tn[0]->left)
                {
                    s+=tn[0]->left->val+" ";
                    tn.push_back(tn[0]->left);
                }
                else if(!tn[0]->left)
                {
                    s+="* ";
                }
                if(tn[0]->right)
                {
                    s+=tn[0]->right->val+" ";
                    tn.push_back(tn[0]->right);
                }
                else if(!tn[0]->right)
                {
                    s+="* ";
                }
                tn.erase(tn.begin());
            }
            
        }
        return s;
    }
    TreeNode* deserialize(string data)
    {
        istringstream words(data);
        TreeNode* root;
        if(data[0]=='*'||data.size()==0)
        {
            return root;
        }
        tn.clear();
        tn.push_back(root);
        int i=0;
        while(data[0]!=' ')
        {
            i++;
        }
        string rootval=data.substr(0,i+1);
        root->val=atoi(rootval.c_str());
        data=data.substr(i+1);
        i=0;
        for(string word;words>>word;i++)
        {
            if(word!="*")
            {
                if(!i&1)
                {
                    tn[0]->left->val=atoi(word.c_str());
                    tn.push_back(tn[0]->left);
                }
                else
                {
                    tn[0]->right->val=atoi(word.c_str());
                    tn.push_back(tn[0]->right);
                }
            }
            if(i&1)
            {
                tn.erase(tn.begin());
            }
        }
        return root;
        
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
