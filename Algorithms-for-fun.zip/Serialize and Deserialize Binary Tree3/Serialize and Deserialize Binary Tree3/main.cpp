//
//  main.cpp
//  Serialize and Deserialize Binary Tree3
//
//  Created by yangjingyi on 2/12/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <queue>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode* left;
    TreeNode* right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Codec
{
public:
    string serialize(TreeNode* root)
    {
        queue<TreeNode* >q;
        q.push(root);
        string str;
        while(!q.empty())
        {
            if(q.front()==nullptr)
            {
                str=str+"#,";
            }
            else
            {
                q.push(q.front()->left);
                q.push(q.front()->right);
                str=str+to_string(q.front()->val)+",";
            }
            q.pop();
        }
        return str;
    }
    TreeNode* deserialize(string data)
    {
        TreeNode* root=nullptr;
        queue<TreeNode**> q;
        q.push(&root);
        string::iterator first=data.begin();
        while(first!=data.end())
        {
            TreeNode** pp=q.front();
            if(*first=='#')
            {
                advance(first,2);
            }
            else
            {
                string::iterator last=find(first,data.end(),',');
                int val=stoi(string(first,last));
                *pp=new TreeNode(val);
                q.push(&((*pp)->left));
                q.push(&((*pp)->right));
                first=next(last);
            }
            q.pop();
        }
        return root;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
