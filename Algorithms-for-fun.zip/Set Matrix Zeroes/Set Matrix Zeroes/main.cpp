//
//  main.cpp
//  Set Matrix Zeroes
//
//  Created by yangjingyi on 12/13/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;

    class Solution {
    public:
        void setZeroes(vector<vector<int>>& matrix) {
            int m = matrix.size();
            int n = matrix[0].size();
            
            if(m==0 || n==0) return;
            int row = -1, col = -1;
            for(int i=0; i<m; i++){
                if(row != -1) break;
                for(int j=0; j<n; j++){
                    if(matrix[i][j] == 0){
                        row = i;
                        col = j;
                        break;
                    }
                }
            }
            if(row == -1) return;
            for(int i=0; i<m; i++){
                for(int j=0; j<n; j++){
                    if(matrix[i][j] == 0){
                        matrix[i][col] = 0;
                        matrix[row][j] = 0;
                    }
                }
            }
            for(int i=0; i<m; i++){
                if(i == row) continue;
                if(matrix[i][col] == 0){
                    for(int j=0; j<n; j++) matrix[i][j] = 0;
                }
            }
            for(int j=0; j<n; j++){
                if(j == col) continue;
                if(matrix[row][j] == 0){
                    for(int i=0; i<m; i++) matrix[i][j] = 0;
                }
            }
            for(int i=0; i<m; i++) matrix[i][col] = 0;
            for(int j=0; j<n; j++) matrix[row][j] = 0;
        }
    };


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
