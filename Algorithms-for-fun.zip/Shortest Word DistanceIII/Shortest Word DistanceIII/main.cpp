//
//  main.cpp
//  Shortest Word DistanceIII
//
//  Created by yangjingyi on 1/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int shortestWordDistance(vector<string>& words, string word1, string word2)
    {
        int res=words.size(),l=words.size(),r=-words.size();
        for(unsigned int i=0;i<words.size();i++)
        {
            if(words[i]==word1)
            {
                l=(word1==word2)?r:i;
            }
            if(words[i]==word2)
            {
                r=i;
            }
            res=min(res,abs(l-r));
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
