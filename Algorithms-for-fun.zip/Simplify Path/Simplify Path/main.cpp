//
//  main.cpp
//  Simplify Path
//
//  Created by yangjingyi on 12/13/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <sstream>
using namespace std;
class Solution
{
public:
    string simplifyPath(string path)
    {
        string res, tmp;
        vector<string> stk;
        stringstream ss(path);
        while(getline(ss,tmp,'/'))
        {
            if(tmp=="" or tmp==".")
            {
                continue;
            }
            if(tmp==".."&&!stk.empty())
            {
                stk.pop_back();
            }
            else if(tmp!="..")
            {
                stk.push_back(tmp);
            }
        }
        for(auto str:stk) res+="/"+str;
        return res.empty()?"/":res;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
