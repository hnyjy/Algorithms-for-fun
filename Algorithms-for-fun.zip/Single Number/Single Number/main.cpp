//
//  main.cpp
//  Single Number
//
//  Created by yangjingyi on 12/23/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int singleNumber(vector<int>& nums)
    {
        int result=nums[0];
        for(int i=0;i<nums.size();i++)
        {
            result=result^nums[i];
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
