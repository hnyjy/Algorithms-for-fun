//
//  main.cpp
//  Single NumberII
//
//  Created by yangjingyi on 12/23/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int singleNumber(vector<int>& nums)
    {
        int ones=0,twos=0;
        for(int i=0;i<nums.size();i++)
        {
            ones=(ones^nums[i])&~twos;
            twos=(twos^nums[i])&~ones;
        }
        return ones;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
