//
//  main.cpp
//  Single NumberIII
//
//  Created by yangjingyi on 1/27/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <numeric>
using namespace std;
class Solution
{
public:
    vector<int> singleNumber(vector<int>& nums)
    {
        int diff=accumulate(nums.begin(),nums.end(),0,bit_xor<int>());
        diff&=-diff;
        vector<int> rets={0,0};
        for(int num:nums)
        {
            if((num&diff)==0)
            {
                rets[0]^=num;
            }
            else
            {
                rets[1]^=num;
            }
        }
        return rets;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
