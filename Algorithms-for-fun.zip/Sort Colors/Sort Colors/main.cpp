//
//  main.cpp
//  Sort Colors
//
//  Created by yangjingyi on 12/13/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>gb
#include <vector>
using namespace std;
class Solution
{
public:
    void sortColors(vector<int>& nums)
    {
        int i;
        int po1=-1;
        for(i=0;i<nums.size()-1;i++)
        {
            if(nums[i]>0)
            {
                int j;
                for(j=i+1;j<nums.size()&&nums[j]!=0;j++)
                {
                    //cout<<"wrong"<<endl;
                    
                }
                
                if(nums[j]==0&&j<nums.size())
                {
                    swap(nums[i],nums[j]);
                    po1=i;
                    //cout<<"wrong"<<endl;
                }
                /*for(int k=0;k<nums.size();k++)
                {
                    cout<<nums[k]<<",";
                }
                cout<<endl;*/
            }
        }
        //cout<<"po1="<<po1<<endl;
        for(i=po1+1;i<nums.size()-1;i++)
        {
            if(nums[i]>1)
            {
                
                int j;
                for(j=i+1;j<nums.size()&&nums[j]!=1;j++)
                {
                    
                }
                //cout<<"j="<<j<<endl;
                
                if(nums[j]==1&&j<nums.size())
                {
                    //cout<<"wrong"<<endl;
                    swap(nums[i],nums[j]);
                }
                /*for(int k=0;k<nums.size();k++)
                {
                    cout<<nums[k]<<".";
                }*/
                //cout<<endl;
            }

        }
            
    }
};

int main(int argc, const char * argv[]) {
    vector<int> in={2,2,2,2,2,0,2,1,0,1,1,0,1,2,1,2,1,1,1,1,2,1,2,1,1,2,1,0,0,0,2,2,1,2,0,0,1,2,1,1,2,0,2,0,0,2,2,1,1,1,0};
    Solution a;
    a.sortColors(in);
    for(int i=0;i<in.size();i++)
    {
        cout<<in[i]<<",";
    }
    //std::cout << "Hello, World!\n";
    return 0;
}
