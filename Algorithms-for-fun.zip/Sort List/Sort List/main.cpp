//
//  main.cpp
//  Sort List
//
//  Created by yangjingyi on 12/24/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode(int x):val(x),next(NULL){}
};
class Solution
{
public:
    ListNode* sortList(ListNode* head)
    {
        if(!head)
        {
            return head;
        }
        if(!head||!head->next)
        {
            return head;
        }
        ListNode* fast=head->next;
        
        ListNode* slow=head;
        //cout<<"right"<<endl;
       
        while(fast&&fast->next)
        {
            //cout<<"right"<<endl;
            slow=slow->next;
            fast=fast->next->next;
        }
        //cout<<"right"<<endl;
        ListNode* head2=sortList(slow->next);
        slow->next=NULL;
        return merge(sortList(head),head2);
    }
    ListNode* merge(ListNode* h1, ListNode* h2)
    {
        ListNode h(0);
        ListNode* cur=&h;
        while(h1&&h2)
        {
            if(h1->val<h2->val)
            {
                cur->next=h1;
                h1=h1->next;
            }
            else
            {
                cur->next=h2;
                h2=h2->next;
            }
            cur=cur->next;
        }
        if(h1)
        {
            cur->next=h1;
        }
        if(h2)
        {
            cur->next=h2;
        }
        return h.next;
    }
};

int main(int argc, const char * argv[]) {
    ListNode* head=new ListNode(2);
    head->next=new ListNode(1);
    Solution a;
    ListNode* out=a.sortList(head);
    while(out)
    {
        cout<<out->val<<endl;
        out=out->next;
    }
    return 0;
}
