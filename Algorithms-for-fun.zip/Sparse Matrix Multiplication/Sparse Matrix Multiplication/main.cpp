//
//  main.cpp
//  Sparse Matrix Multiplication
//
//  Created by yangjingyi on 2/20/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<vector<int> >multiply(vector<vector<int> >& A, vector<vector<int> >& B)
    {
        int m=A.size(),n=A[0].size();
        vector<vector<int> >res(m,vector<int>(B[0].size(),0));
        for(int i=0;i<m;i++)
        {
            for(int k=0;k<n;k++)
            {
                if(A[i][k]!=0)
                {
                    for(int j=0;j<B[0].size();j++)
                    {
                        res[i][j]+=A[i][k]*B[k][j];
                    }
                }
            }
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
