//
//  main.cpp
//  Spiral Matrix II
//
//  Created by yangjingyi on 12/12/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<vector<int> > generateMatrix(int n)
    {
        vector<vector<int> > result(n, vector<int>(n,0));
        //cout<<result.size()<<endl;
        //cout<<result[0].size()<<endl;
        /*for(int i=0;i<result.size();i++)
        {
            for(int j=0;j<result[i].size();j++)
            {
                cout<<result[i][j]<<",";
            }
            cout<<endl;
        }*/
        vector<vector<int> > dirs={{0,1},{1,0},{0,-1},{-1,0}};
        int count=1;
        vector<int> nstep{n,n-1};
        int idir=0;
        int ph=0,pv=-1;
        while(nstep[idir%2])
        {
            for(int i=0;i<nstep[idir%2];i++)
            {
                ph+=dirs[idir][0];
                pv+=dirs[idir][1];
                result[ph][pv]=count;
                count++;
                //cout<<"ph="<<ph<<endl;
                //cout<<"pv="<<pv<<endl;
                //cout<<"count1="<<count<<endl;
            }
            //cout<<"count2="<<count<<endl;
            nstep[idir%2]--;
            idir=(idir+1)%4;
        }
        /*for(int i=0;i<result.size();i++)
        {
            for(int j=0;j<result[i].size();j++)
            {
                cout<<result[i][j]<<",";
            }
            cout<<endl;
        }*/
        
        return result;
        
    }
};

int main(int argc, const char * argv[]) {
    int in=2;
    Solution a;
    vector<vector<int> > out=a.generateMatrix(in);
    for(int i=0;i<out.size();i++)
    {
        for(int j=0;j<out[i].size();j++)
        {
            cout<<out[i][j]<<",";
        }
        cout<<endl;
    }
    return 0;
}
