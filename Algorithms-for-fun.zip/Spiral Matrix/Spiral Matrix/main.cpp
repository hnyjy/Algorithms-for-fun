//
//  main.cpp
//  Spiral Matrix
//
//  Created by yangjingyi on 12/10/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<int> spiralOrder(vector<vector<int> >& matrix)
    {
        vector<int> result;
        if(matrix.empty())
            return {};
        int m=matrix.size();
        int n=matrix[0].size();
        
        if(matrix.size()==1)
            
        {
            for(int i=0;i<matrix[0].size();i++)
            {
                result.push_back(matrix[0][i]);
            }
            return result;
        }
        for(int i=0;i<m-1&&i<n;i++)
        {
            for(int j=i;j<n-i-1;j++)
            {
                result.push_back(matrix[i][j]);
                cout<<i<<"+1"<<endl;
            }
            
            for(int j=i;j<m-1;j++)
            {
                result.push_back(matrix[j][n-1]);
                cout<<i<<"+2"<<endl;
            }
            for(int j=n-1-i;j>0;j--)
            {
                result.push_back(matrix[m-1-i][j]);
                cout<<i<<"+3"<<endl;
            }
            for(int j=m-1-i;j>i;j--)
            {
                result.push_back(matrix[j][i]);
                cout<<i<<"+4"<<endl;
            }
            
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    vector<vector<int> > in={{7},{9},{6}};
    Solution a;
    vector<int> out;
    out=a.spiralOrder(in);
    for(int i=0;i<out.size();i++)
    {
        cout<<out[i]<<", ";
    }
    return 0;
}
