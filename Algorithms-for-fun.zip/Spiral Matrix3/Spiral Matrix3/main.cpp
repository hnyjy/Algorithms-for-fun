//
//  main.cpp
//  Spiral Matrix3
//
//  Created by yangjingyi on 12/12/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<int> spiralOrder(vector<vector<int> >& matrix)
    {
        vector<vector<int> > dirs={{0,1},{1,0},{0,-1},{-1,0}};
        vector<int> result;
        int nh=matrix[0].size();
        if(nh==0)
        {
            return result;
        }
        int nv=matrix.size();
        if(nv==0)
        {
            return result;
        }
        vector<int> nstep{nh,nv-1};
        int idir=0;
        int ph=0,pv=-1;
        while(nstep[idir%2])
        {
            for(int i=0;i<nstep[idir%2];i++)
            {
                ph+=dirs[idir][0];
                pv+=dirs[idir][1];
                result.push_back(matrix[ph][pv]);
            }
            nstep[idir%2]--;
            idir=(idir+1)%4;
        }
        return result;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
