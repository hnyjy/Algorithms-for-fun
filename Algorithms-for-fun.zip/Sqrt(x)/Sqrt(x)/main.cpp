//
//  main.cpp
//  Sqrt(x)
//
//  Created by yangjingyi on 12/13/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <climits>
using namespace std;
class Solution
{
public:
    int mySqrt(int x)
    {
        if(x==0)
        {
            return 0;
        }
        int left=1, right=INT_MAX;
        while(true)
        {
            int mid=left+(right-left)/2;
            if(mid>x/mid)
            {
                right=mid-1;
            }
            else
            {
                if(mid+1>x/(mid+1))
                    return mid;
                left=mid+1;
            }
        }
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
