//
//  main.cpp
//  Strobogrammatic Number
//
//  Created by yangjingyi on 1/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <map>
using namespace std;
class Solution
{
public:
    bool isStrobogrammatic(string num)
    {
        map<char,char> mp{{'0','0'},{'1','1'},{'8','8'},{'6','9'},{'9','6'}};
        for(int i=0;i<num.size();i++)
        {
            if(mp[num[i]]!=num[num.size()-i-1])
            {
                return false;
                
            }
        }
        return true;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
