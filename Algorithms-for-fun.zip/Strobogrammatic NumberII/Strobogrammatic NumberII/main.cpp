//
//  main.cpp
//  Strobogrammatic NumberII
//
//  Created by yangjingyi on 1/25/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <unordered_map>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<string> findStrobogrammatic(int n)
    {
        vector<string> result;
        unordered_map<char,char> hashmap;
        hashmap['0']='0';
        hashmap['1']='1';
        hashmap['6']='9';
        hashmap['8']='8';
        hashmap['9']='6';
        if(n%2==0)
        {
            findStrobogrammatic(result,hashmap,"",n);
            
        }
        else
        {
            findStrobogrammatic(result,hashmap,"0",n);
            findStrobogrammatic(result,hashmap,"1",n);
            findStrobogrammatic(result,hashmap,"8",n);
        }
        if(n==1)
        {
            result.push_back("0");
        }
        return result;
    }
private:
    void findStrobogrammatic(vector<string>& res, unordered_map<char,char>& mp,string tmp,int num)
    {
        if(tmp.size()==num)
        {
            if(tmp[0]!='0')
            {
                res.push_back(tmp);
            }
            return;
        }
        else
        {
            for(auto& it:mp)
            {
                tmp.insert(0,1,it.first);
                tmp.insert(tmp.size(),1,it.second);
                findStrobogrammatic(res,mp,tmp,num);
                tmp=tmp.substr(1,tmp.size()-2);
            }
        }
        return;
            
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
