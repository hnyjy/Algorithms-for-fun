//
//  main.cpp
//  Subsets
//
//  Created by yangjingyi on 12/15/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    void combine(vector<vector<int> >& res, vector<int>& temp, int start, vector<int> num, int n, int k)
    {
        if(n==k)
        {
            res.push_back(temp);
            return;
        }
        else
        {
            for(int i=start;i<num.size();i++)
            {
                temp.push_back(num[i]);
                combine(res,temp,i+1,num,n+1,k);
                temp.pop_back();
            }
        }
    }
    vector<vector<int> > subsets(vector<int>& nums)
    {
        vector<vector<int> >res;
        vector<int> temp;
        res.push_back(temp);
        for(int i=1;i<=nums.size();i++)
        {
            combine(res,temp,0,nums,0,i);
        }
        for(int i=0;i<res.size();i++)
        {
            sort(res[i].begin(),res[i].end());
        }
        return res;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
