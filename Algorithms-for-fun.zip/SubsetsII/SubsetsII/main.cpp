//
//  main.cpp
//  SubsetsII
//
//  Created by yangjingyi on 12/16/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    
    vector<vector<int> > subsetsWithDup(vector<int>& nums)
    {
        vector<vector<int> > totalset={{}};
        sort(nums.begin(),nums.end());
        for(int i=0;i<nums.size();)
        {
            int count=0;
            while(count+i<nums.size()&&nums[i]==nums[i+count])
            {
                count++;
            }
            int previousN=totalset.size();
            for(int k=0;k<previousN;k++)
            {
                vector<int> instance=totalset[k];
                for(int j=0;j<count;j++)
                {
                    instance.push_back(nums[i]);
                    totalset.push_back(instance);
                }
            }
            i=i+count;
            
        }
        return totalset;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
