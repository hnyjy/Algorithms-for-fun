//
//  main.cpp
//  Substring with Concatenation of All Words
//
//  Created by yangjingyi on 10/21/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <map>
#include<unordered_map>
using namespace std;

class Solution
{
public:
    vector<int> findSubstring(string s, vector<string>& words)
    {
        int sLen=s.size(), wSize, wordL, i, j, count, start;
        vector<int> res;
        if(!(wSize=words.size())||!(wordL=words[0].size())||sLen<wSize*wordL)
            return res;
        unordered_map<string, int> dict;
        for(i=0;i<wSize;++i)
            ++dict[words[i]];
        for(j=0;j<wordL;++j)
        {
            for(i=j, start=j, count=0;i<=sLen-wordL;i+=wordL)
            {
                if(dict.count(s.substr(i,wordL))==0)
                {
                    while(start<i)
                    {
                        ++dict[s.substr(start,wordL)];
                        start+=wordL;
                    }
                    start=i+wordL;
                    count=0;
                    continue;
                }
                if(--dict[s.substr(i,wordL)]<0)
                {
                    while(dict[s.substr(i,wordL)]<0)
                    {
                        ++dict[s.substr(start,wordL)];
                        start +=wordL;
                        --count;
                    }
                }
                if(++count==wSize)
                {
                    res.push_back(start);
                    ++dict[s.substr(start,wordL)];
                    start+=wordL;
                    --count;
                }
                            }
            while(start<i)
            {
                ++dict[s.substr(start,wordL)];
                start+=wordL;
            }
        }
        return res;
    }
    
};
int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
