//
//  main.cpp
//  Substring with Concatenation of All Words2
//
//  Created by yangjingyi on 12/5/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include<unordered_map>
using namespace std;
class Solution
{
public:
    vector<int> findSubstring(string s, vector<string>& W)
    {
        vector<int> R;
        if(W.empty()||W[0].empty()||W[0].size()>s.size())
            return R;
        int n=W[0].size();
        unordered_map<string,int> H;
        for(string w:W)
            H[w]++;
        for(int i=0;i+n*W.size()<=s.size();++i)
        {
            string c=s.substr(i,n);
            if(H.count(c)!=0)
            {
                unordered_map<string, int> C;
                for(int j=0;i<W.size();++j)
                {
                    c=s.substr(i+j*n,n);
                    if(H.count(c)!=0)C[c]++;
                    else break;
                }
                bool equals=true;
                for(auto p:H)
                    equals &=(C.count(p.first)!=0)&&(C[p.first]==p.second);
                if(equals)
                    R.push_back(i);
                
                
            }
               
        }
        return R;
    }
    
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
