//
//  main.cpp
//  Sum Root to Leaf Numbers
//
//  Created by yangjingyi on 12/22/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    void path(TreeNode* root, string temp, vector<int>& result)
    {
        if(!root)
        {
            return;
        }
        if(!root->left&&!root->right)
        {
            result.push_back(atoi((temp+to_string(root->val)).c_str()));
            return;
        }
        else
        {
            temp=temp+to_string(root->val);
            if(root->left)
            {
                path(root->left,temp,result);
            }
            if(root->right)
            {
                path(root->right,temp,result);
            }
        }
    }
    int sumNumbers(TreeNode* root)
    {
        string temp="";
        vector<int> result;
        path(root,temp,result);
        int sum=0;
        for(int i=0;i<result.size();i++)
        {
            sum +=result[i];
        }
        return sum;
    }
};

int main(int argc, const char * argv[]) {
    TreeNode* root=new TreeNode (1);
    root->left=new TreeNode (2);
    root->right=new TreeNode (3);
    root->left->left=new TreeNode (4);
    root->left->right=new TreeNode(5);
    root->right->left=new TreeNode (6);
    root->right->right=new TreeNode(7);
    root->left->left->left=new TreeNode(8);
    root->left->right->left=new TreeNode(9);
    Solution a;
    int out=a.sumNumbers(root);
    cout<<out<<endl;
    return 0;
}
