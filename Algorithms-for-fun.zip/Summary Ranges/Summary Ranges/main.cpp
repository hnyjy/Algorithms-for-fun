//
//  main.cpp
//  Summary Ranges
//
//  Created by yangjingyi on 1/16/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    vector<string> summaryRanges(vector<int>& nums)
    {
        
        
        vector<string> res;
        if(nums.size()==0)
        {
            return res;
        }
        if(nums.size()==1)
        {
            res.push_back(to_string(nums[0]));
            return res;
            
        }
        int start=nums[0];
        for(int i=1;i<nums.size();i++)
        {
            if(i==nums.size()-1)
            {
                if(nums[i]!=nums[i-1]+1)
                {
                    if(start!=nums[i-1])
                    {
                        res.push_back(to_string(start)+"->"+to_string(nums[i-1]));
                    }
                    else
                    {
                        res.push_back(to_string(nums[i-1]));
                    }
                    res.push_back(to_string(nums[i]));
                }
                else
                {
                    res.push_back(to_string(start)+"->"+to_string(nums[i]));
                }
            }
            else if(nums[i]!=nums[i-1]+1)
            {
                if(start!=nums[i-1])
                {
                    res.push_back(to_string(start)+"->"+to_string(nums[i-1]));
                }
                else
                {
                    res.push_back(to_string(nums[i-1]));
                }
                start=nums[i];
                
            }
        }
        return res;
        
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
