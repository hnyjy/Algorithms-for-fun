//
//  main.cpp
//  Super Ugly Number
//
//  Created by yangjingyi on 2/21/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
public:
    int nthSuperUglyNumber(int n, vector<int>& primes)
    {
        vector<int> index(primes.size(),0),ugly(n,INT_MAX);
        ugly[0]=1;
        for(int i=1;i<n;i++)
        {
            for(int j=0;j<primes.size();j++)
            {
                ugly[i]=min(ugly[i],ugly[index[j]]*primes[j]);
            }
            for(int j=0;j<primes.size();j++)
            {
                index[j]+=(ugly[i]==ugly[index[j]]*primes[j]);
            }
        }
        return ugly[n-1];
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
