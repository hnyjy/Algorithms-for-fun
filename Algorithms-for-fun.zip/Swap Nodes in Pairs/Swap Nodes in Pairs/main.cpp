//
//  main.cpp
//  Swap Nodes in Pairs
//
//  Created by yangjingyi on 9/10/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
using namespace std;
struct ListNode
{
    int val;
    ListNode *next;
    ListNode(int x):val(x),next(NULL)
    {
        
    }
};
class Solution
{
public:
    ListNode* swapPairs(ListNode* head)
    {
        if(head)
        {
            ListNode * prevNode= NULL;
            ListNode * tmp = NULL;
            ListNode * curr=head;
            while(curr&&curr->next)
            {
                tmp=curr->next;
                curr->next=tmp->next;
                tmp->next=curr;
                if(prevNode)
                {
                    prevNode->next=tmp;
                }
                else
                {
                    head=tmp;
                }
                prevNode=curr;
                curr=curr->next;
            }
            return head;
            
        }
        else
        {
            return head;
        }
    }
};

int main()
{
    ListNode n1(1);
    ListNode n2(2);
    ListNode n3(3);
    ListNode n4(4);
    n1.next=&n2;
    n2.next=&n3;
    n3.next=&n4;
    Solution a;
    ListNode* result;
    result=a.swapPairs(&n1);
    while(result)
    {
        cout<<result->val<<endl;
        result=result->next;
    }
}
