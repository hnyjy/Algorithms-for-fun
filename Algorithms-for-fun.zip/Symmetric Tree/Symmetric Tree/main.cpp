//
//  main.cpp
//  Symmetric Tree
//
//  Created by yangjingyi on 12/18/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
struct TreeNode
{
    int val;
    TreeNode *left;
    TreeNode *right;
    TreeNode(int x):val(x),left(NULL),right(NULL){}
};
class Solution
{
public:
    bool isSymmetric(TreeNode* root)
    {
        if(!root)
        {
            return true;
        }
        return dfs(root->left, root->right);
    }
    bool dfs(TreeNode *treel, TreeNode *treer)
    {
        if(!(treel&&treer))
        {
            return treel==treer;
        }
        if(!(treel->val==treer->val))
        {
            return false;
        }
        return dfs(treel->left,treer->right)&&dfs(treel->right,treer->left);
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
