//
//  main.cpp
//  Triangle
//
//  Created by yangjingyi on 12/20/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Solution
{
public:
    int minimumTotal(vector<vector<int> >& triangle)
    {
        vector<int> mini=triangle[triangle.size()-1];
        for(int i=triangle.size()-2;i>=0;i--)
        {
            for(int j=0;j<triangle[i].size();j++)
            {
                mini[j]=triangle[i][j]+min(mini[j],mini[j+1]);
            }
        }
        return mini[0];
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
