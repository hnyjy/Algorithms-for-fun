//
//  main.cpp
//  Two Sum
//
//  Created by yangjingyi on 4/8/15.
//  Copyright (c) 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;
void print(pair<char,int> p)
{
    cout<<p.first<<endl;
}

class Solution
{
public:
    int lengthOfLongestSubstring(string s)
    {
        int len=0;
        int curr=0;
        map<char, int> umap;
        const char *inchar=s.c_str();
        int i,j,k,loc;
        loc=0;
        char x,y;
        map<char,int>::iterator be;
        for(i=0;i<s.length();i++)
        {
            x=*(inchar+i);
            if(umap.find(x)==umap.end())
            {
                //cout<<"i="<<i<<endl;
                umap.insert(pair<char, int> (x, i));
                curr++;
                if(curr>len)
                {
                    len=curr;
                }
            }
            else
            {
                //cout<<"i'="<<i<<endl;
                if(curr>len)
                {
                    len=curr;
                }
                k=umap.find(x)->second;
                for(j=loc;j<k+1;j++)
                {
                    y=*(inchar+j);
                    be=umap.find(y);
                    if(be==umap.end())
                        continue;
                    else
                        umap.erase(be);
                }
                
                curr=i-(umap.find(x)->second);
                loc=(umap.find(x)->second)+1;
                umap.insert(pair<char,int> (x,i));
                
                
            }
            
        }
        return len;
    }
};
int main()
{
    Solution re;
    string inp="aaaa";
    int outp;
    outp=re.lengthOfLongestSubstring(inp);
    cout<<outp<<endl;
}
