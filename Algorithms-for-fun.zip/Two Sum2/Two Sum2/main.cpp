//
//  main.cpp
//  Two Sum2
//
//  Created by yangjingyi on 3/13/16.
//  Copyright © 2016 yangjingyi. All rights reserved.
//

#include <iostream>
#include <set>
#include <vector>
#include <unordered_map>
using namespace std;
class Solution
{
public:
    vector<int> twoSum(vector<int>& numbers, int target)
    {
        unordered_map<int, int> map;
        vector<int> result;
        for(int i=0;i<numbers.size();i++)
        {
            map[numbers[i]]=i;
        }
        for(int i=0;i<numbers.size();i++)
        {
            if(map.find(target-numbers[i])!=map.end()&&i!=map[target-numbers[i]])
            {
                result.push_back(i);
                result.push_back(map[target-numbers[i]]);
                return result;
                
            }
        }
        return result;
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
