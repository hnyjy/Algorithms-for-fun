//
//  main.cpp
//  Two SumII-input array is sorted
//
//  Created by yangjingyi on 12/28/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
using namespace std;
class Solution
{
    vector<int> twoSum(vector<int>& numbers, int target)
    {
        int l=0;
        int r=numbers.size()-1;
        while(l<r)
        {
            if(numbers[l]+numbers[r]==target)
            {
                vector<int> res{l+1,r+1};
                return res;
            }
            else if(numbers[l]+numbers[r]>target)
            {
                r--;
            }
            else
            {
                l++;
            }
        }
    }
};

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
