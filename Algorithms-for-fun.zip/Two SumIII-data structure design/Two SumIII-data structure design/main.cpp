//
//  main.cpp
//  Two SumIII-data structure design
//
//  Created by yangjingyi on 12/28/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_set>
using namespace std;
class TwoSum
{
    unordered_multiset<int> nums;
public:
    void add(int number)
    {
        nums.insert(number);
    }
    bool find(int value)
    {
        for(int i:nums)
        {
            int count=i==value-i?1:0;
            if(nums.count(value-i)>count)
            {
                return true;
            }
        }
        return false;
    }
    
};


int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
