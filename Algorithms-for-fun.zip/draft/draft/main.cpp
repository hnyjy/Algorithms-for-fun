//
//  main.cpp
//  draft
//
//  Created by yangjingyi on 12/4/15.
//  Copyright © 2015 yangjingyi. All rights reserved.
//

#include <iostream>
#include <vector>
#include <unordered_map>
#include <cmath>
using namespace std;
class A
{
public:
    A()
    {
        cout<<"1"<<endl;
    }
   virtual ~A()
    {
        cout<<"2"<<endl;
    }
    virtual void foo()=0;
//    {
//        cout<<"7"<<endl;
//    }
    
};
class C
{
public:
    C()
    {
        cout<<"5"<<endl;
    }
    virtual ~C()
    {
        cout<<"6"<<endl;
    }
    virtual void foo()
    {
        cout<<"8"<<endl;
    }
};
class B:public A
{public:
    B()
    {
        cout<<"3"<<endl;
    }
    ~B()
    {
        cout<<"4"<<endl;
    }
    void foo()
    {
        cout<<"9"<<endl;
    }
};
class LRUCache
{
private:
    unordered_map<int,int> hash;
    vector<unordered_map<int,int> ::iterator> v;
    int _capacity;
public:
    LRUCache(int capacity):_capacity(capacity){}
    int get(int key)
    {
        auto it=hash.find(key);
        if(it==hash.end())
        {
            return -1;
        }
        touch(it);
        return it->second;
    }
    void set(int key, int value)
    {
        auto it=hash.find(key);
        if(it!=hash.end())
        {
            touch(it);
            hash[key]=value;
        }
        else
        {
            if(v.size()==_capacity)
            {
                hash.erase(*(v.begin()));
                v.erase(v.begin());
                hash[key]=value;
                auto tmp=hash.find(key);
                v.push_back(tmp);
            }
            else
            {
                hash[key]=value;
                auto tmp=hash.find(key);
                v.push_back(tmp);
            }
        }
    }
    void touch(unordered_map<int,int>::iterator it)
    {
        auto tmp=find(v.begin(),v.end(),it);
        v.erase(tmp);
        v.push_back(it);
    }
};
int main()

{
    B b;
    b.foo();
    //A a;
    
    return 0;
    
}
